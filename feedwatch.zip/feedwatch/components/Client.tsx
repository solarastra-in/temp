'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

async function call(url: string, method: string, body?: any) {
  const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Failed');
  return d;
}

export function Star({ id, on }: { id: string; on: boolean }) {
  const [s, setS] = useState(on);
  return <button className={`star ${s ? 'on' : ''}`} aria-label={s ? 'Unstar' : 'Star'} aria-pressed={s} onClick={() => { setS(!s); call(`/api/items/${id}`, 'PATCH', { starred: !s }); }}>★</button>;
}

export function LiveEmbed({ videoId, title }: { videoId: string; title: string }) {
  const [open, setOpen] = useState(false);
  if (!open) return <button className="btn sm" onClick={() => setOpen(true)}>Watch here</button>;
  return <iframe className="embed" src={`https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1`} title={title} allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen />;
}

export function AddSource() {
  const [f, setF] = useState({ url: '', label: '', tag: '', asRss: false });
  const [msg, setMsg] = useState<{ k: string; t: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  return (
    <form className="stack" onSubmit={async (e) => {
      e.preventDefault(); setBusy(true); setMsg(null);
      try { const d = await call('/api/sources', 'POST', f); setMsg({ k: 'ok', t: `Added ${d.platform} ${d.handle}. It will be checked on the next run.` }); setF({ url: '', label: '', tag: f.tag, asRss: false }); router.refresh(); }
      catch (err: any) { setMsg({ k: 'err', t: err.message }); }
      setBusy(false);
    }}>
      <div className="row wr">
        <input className="field grow" style={{ minWidth: 260 }} required placeholder="Paste a URL: YouTube channel, X, Instagram, Threads, Facebook, TikTok, LinkedIn, RSS or any page" value={f.url} onChange={(e) => setF({ ...f, url: e.target.value })} aria-label="Source URL" />
        <input className="field" style={{ width: 160 }} placeholder="Label (optional)" value={f.label} onChange={(e) => setF({ ...f, label: e.target.value })} aria-label="Label" />
        <input className="field" style={{ width: 140 }} placeholder="Tag, e.g. Cricket" value={f.tag} onChange={(e) => setF({ ...f, tag: e.target.value })} aria-label="Tag" />
        <button className="btn" disabled={busy}>Add source</button>
      </div>
      <label className="row xs muted"><input type="checkbox" checked={f.asRss} onChange={(e) => setF({ ...f, asRss: e.target.checked })} /> Treat this URL as an RSS/Atom feed</label>
      {msg && <div className={`alert ${msg.k}`} role="status">{msg.t}</div>}
    </form>
  );
}

export function SourceControls({ id, alert, enabled }: { id: string; alert: string; enabled: boolean }) {
  const router = useRouter();
  return (
    <div className="row wr">
      <select className="field" aria-label="Alerts" defaultValue={alert} onChange={async (e) => { await call(`/api/sources/${id}`, 'PATCH', { alert: e.target.value }); router.refresh(); }}>
        <option value="all">Alert: every post</option><option value="live">Alert: lives only</option><option value="keywords">Alert: keywords only</option><option value="none">No alerts</option>
      </select>
      <button className="btn ghost sm" onClick={async () => { await call(`/api/sources/${id}`, 'PATCH', { enabled: !enabled }); router.refresh(); }}>{enabled ? 'Pause' : 'Resume'}</button>
      <button className="btn ghost sm" onClick={async () => { if (confirm('Remove this source and its saved posts?')) { await call(`/api/sources/${id}`, 'DELETE'); router.refresh(); } }}>Remove</button>
    </div>
  );
}

export function TokenField({ k, label, set }: { k: string; label: string; set: boolean }) {
  const [v, setV] = useState('');
  const [msg, setMsg] = useState('');
  const router = useRouter();
  return (
    <form className="row wr" onSubmit={async (e) => { e.preventDefault(); try { await call('/api/settings', 'POST', { key: k, value: v }); setV(''); setMsg('Saved'); router.refresh(); } catch (err: any) { setMsg(err.message); } }}>
      <span className="grow small" style={{ minWidth: 220 }}><b>{label}</b><br /><span className="xs muted">{k} · {set ? 'set' : 'not set'}</span></span>
      <input className="field" style={{ width: 280 }} type="password" autoComplete="off" placeholder={set ? '•••••• (paste to replace)' : 'Paste value'} value={v} onChange={(e) => setV(e.target.value)} aria-label={label} />
      <button className="btn ghost sm" disabled={!v}>Save</button>
      {msg && <span className="xs muted">{msg}</span>}
    </form>
  );
}

export function TestAlert() {
  const [msg, setMsg] = useState('');
  return <span className="row"><button className="btn ghost sm" onClick={async () => { try { await call('/api/settings', 'POST', { test: true }); setMsg('Sent. Check Telegram.'); } catch (e: any) { setMsg(e.message); } }}>Send test alert</button><span className="xs muted" role="status">{msg}</span></span>;
}

export function Rules({ rules }: { rules: any[] }) {
  const [f, setF] = useState({ kind: 'highlight', pattern: '' });
  const router = useRouter();
  return (
    <div className="stack">
      <div className="row wr">{rules.map((r) => (
        <span key={r.id} className={`pill ${r.kind === 'mute' ? 'warn' : 'good'}`}>{r.kind === 'mute' ? 'Mute' : 'Highlight'}: {r.pattern}
          <button className="star" style={{ fontSize: 13, minHeight: 20, minWidth: 20 }} aria-label={`Remove ${r.pattern}`} onClick={async () => { await call(`/api/rules/${r.id}`, 'DELETE'); router.refresh(); }}>×</button></span>
      ))}</div>
      <form className="row wr" onSubmit={async (e) => { e.preventDefault(); await call('/api/rules', 'POST', f); setF({ ...f, pattern: '' }); router.refresh(); }}>
        <select className="field" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })} aria-label="Rule type"><option value="highlight">Highlight + alert</option><option value="mute">Mute</option></select>
        <input className="field" style={{ width: 220 }} placeholder="Word or phrase" value={f.pattern} onChange={(e) => setF({ ...f, pattern: e.target.value })} aria-label="Word or phrase" />
        <button className="btn ghost sm" disabled={!f.pattern}>Add rule</button>
      </form>
    </div>
  );
}

export function LoginForm() {
  const [p, setP] = useState('');
  const [err, setErr] = useState('');
  return (
    <form className="stack" onSubmit={async (e) => { e.preventDefault(); try { await call('/api/login', 'POST', { password: p }); window.location.href = '/'; } catch (x: any) { setErr(x.message); } }}>
      <input className="field" type="password" autoFocus placeholder="Password" value={p} onChange={(e) => setP(e.target.value)} aria-label="Password" />
      <button className="btn">Sign in</button>
      {err && <div className="alert err">{err}</div>}
    </form>
  );
}
