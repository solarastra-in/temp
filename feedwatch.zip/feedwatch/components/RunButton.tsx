'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function RunButton({ sourceId, label = 'Check now' }: { sourceId?: string; label?: string }) {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const router = useRouter();
  async function go() {
    setBusy(true); setMsg('');
    const r = await fetch('/api/run', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sourceId }) }).then((r) => r.json());
    setBusy(false);
    setMsg(r.error ? r.error : r.skipped ? 'Already running' : `${r.newItems} new`);
    router.refresh();
  }
  return <span className="row"><button className={sourceId ? 'btn ghost sm' : 'btn sm'} onClick={go} disabled={busy}>{busy ? 'Checking…' : label}</button>{msg && <span className="xs muted" role="status">{msg}</span>}</span>;
}
