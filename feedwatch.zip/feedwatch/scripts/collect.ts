// Run one collection pass from the command line (for a server cron): npm run collect
import { runOnce } from '../lib/run';
runOnce().then((r) => { console.log(JSON.stringify(r, null, 2)); process.exit(0); });
