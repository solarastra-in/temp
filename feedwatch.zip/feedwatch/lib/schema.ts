import { detect } from './detect';

export const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS sources (
  id text PRIMARY KEY,
  url text UNIQUE NOT NULL,
  platform text NOT NULL,
  handle text NOT NULL,
  label text,
  tag text NOT NULL DEFAULT 'General',
  alert text NOT NULL DEFAULT 'all',
  enabled boolean NOT NULL DEFAULT true,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  last_checked timestamptz,
  last_ok timestamptz,
  last_error text,
  method text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS items (
  id text PRIMARY KEY,
  source_id text NOT NULL,
  platform text NOT NULL,
  kind text NOT NULL DEFAULT 'post',
  title text,
  body text,
  url text NOT NULL,
  image text,
  live_state text,
  published_at timestamptz NOT NULL,
  seen_at timestamptz NOT NULL DEFAULT now(),
  starred boolean NOT NULL DEFAULT false,
  alerted boolean NOT NULL DEFAULT false
);
CREATE INDEX IF NOT EXISTS items_pub_idx ON items(published_at DESC);
CREATE TABLE IF NOT EXISTS rules (
  id text PRIMARY KEY,
  kind text NOT NULL,
  pattern text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS runs (
  id text PRIMARY KEY,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  new_items int NOT NULL DEFAULT 0,
  alerts int NOT NULL DEFAULT 0,
  summary text
);
CREATE TABLE IF NOT EXISTS kv (
  k text PRIMARY KEY,
  v jsonb NOT NULL
)
`;

export const SEED_SOURCES = [
  'https://x.com/arabianacesT10',
  'https://www.linkedin.com/in/arabianaces/',
  'https://www.instagram.com/arabianacesofficial',
  'https://www.threads.com/@arabianacesofficial',
  'https://www.facebook.com/arabianacesofficial/',
  'https://www.tiktok.com/@arabianaces',
];

export async function seed(run: (t: string, p?: any[]) => Promise<any[]>) {
  if ((await run(`SELECT 1 FROM kv WHERE k = 'seed:v1'`)).length) return;
  for (const url of SEED_SOURCES) {
    const d = detect(url);
    if (!d) continue;
    await run(`INSERT INTO sources (id, url, platform, handle, label, tag) VALUES ($1,$2,$3,$4,'Arabian Aces','Arabian Aces') ON CONFLICT (url) DO NOTHING`,
      [crypto.randomUUID(), d.url, d.platform, d.handle]);
  }
  await run(`INSERT INTO rules (id, kind, pattern) VALUES ($1,'highlight','Moeen'), ($2,'highlight','live') ON CONFLICT DO NOTHING`, [crypto.randomUUID(), crypto.randomUUID()]);
  await run(`INSERT INTO kv (k, v) VALUES ('seed:v1', 'true'::jsonb)`);
}
