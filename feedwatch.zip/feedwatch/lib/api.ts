import { NextResponse } from 'next/server';
import { guard } from './auth';

export function route(fn: (req: Request, ctx: any) => Promise<any>, opts: { open?: boolean } = {}) {
  return async (req: Request, ctx: any) => {
    try {
      if (!opts.open) await guard();
      const r = await fn(req, ctx);
      return r instanceof Response ? r : NextResponse.json(r ?? { ok: true });
    } catch (e: any) {
      return NextResponse.json({ error: e.message || 'Error' }, { status: e.status || 400 });
    }
  };
}
