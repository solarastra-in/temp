// Access tokens: pasted in Settings (stored in the database) or set as environment variables.
// Instagram and Threads long-lived tokens (60 days) and TikTok tokens (24h, refresh 1 year)
// are refreshed automatically, so they never lapse while the collector keeps running.
import { kvGet, kvSet } from './db';
import { json } from './util';

export const TOKEN_KEYS = {
  X_BEARER_TOKEN: 'X (Twitter) API bearer token',
  INSTAGRAM_TOKEN: 'Instagram token (Instagram API with Instagram Login, for your own account)',
  THREADS_TOKEN: 'Threads API token (your own account)',
  FB_PAGE_TOKEN: 'Facebook Page access token',
  TIKTOK_CLIENT_KEY: 'TikTok app client key',
  TIKTOK_CLIENT_SECRET: 'TikTok app client secret',
  TIKTOK_REFRESH_TOKEN: 'TikTok user refresh token (from Login Kit, scope video.list)',
  LINKEDIN_TOKEN: 'LinkedIn token (Community Management API, r_organization_social)',
  LINKEDIN_ORG_ID: 'LinkedIn organization id (numbers only, for a Company Page)',
  YOUTUBE_API_KEY: 'YouTube Data API key (for live-stream detection)',
  RSSHUB_BASE: 'RSSHub base URL (optional fallback, e.g. https://rsshub.yourdomain.com)',
  TELEGRAM_BOT_TOKEN: 'Telegram bot token (alerts)',
  TELEGRAM_CHAT_ID: 'Telegram chat id (alerts)',
} as const;
export type TokenKey = keyof typeof TOKEN_KEYS;

export async function tok(k: TokenKey): Promise<string> {
  const stored = await kvGet<string>(`token:${k}`);
  return (stored || process.env[k] || '').trim();
}
export async function setTok(k: TokenKey, v: string) {
  await kvSet(`token:${k}`, v.trim());
}
export async function tokenStatus() {
  const out: Record<string, { set: boolean; source: string }> = {};
  for (const k of Object.keys(TOKEN_KEYS) as TokenKey[]) {
    const stored = await kvGet<string>(`token:${k}`);
    out[k] = { set: !!(stored || process.env[k]), source: stored ? 'settings' : process.env[k] ? 'env' : '' };
  }
  return out;
}

const DAY = 86400_000;
async function refreshLongLived(key: 'INSTAGRAM_TOKEN' | 'THREADS_TOKEN', url: (t: string) => string) {
  const t = await tok(key);
  if (!t) return;
  const last = await kvGet<string>(`refreshed:${key}`);
  if (last && Date.now() - new Date(last).getTime() < 7 * DAY) return;
  try {
    const r = await json<any>(url(t));
    if (r.access_token) { await setTok(key, r.access_token); await kvSet(`refreshed:${key}`, new Date().toISOString()); }
  } catch (e: any) {
    await kvSet(`refreshError:${key}`, String(e.message).slice(0, 200));
  }
}
export async function refreshTokens() {
  await refreshLongLived('INSTAGRAM_TOKEN', (t) => `https://graph.instagram.com/refresh_access_token?grant_type=ig_refresh_token&access_token=${encodeURIComponent(t)}`);
  await refreshLongLived('THREADS_TOKEN', (t) => `https://graph.threads.net/refresh_access_token?grant_type=th_refresh_token&access_token=${encodeURIComponent(t)}`);
}

// TikTok: exchange the refresh token for a short-lived access token (cached until expiry).
export async function tiktokAccessToken(): Promise<string | null> {
  const cached = await kvGet<{ token: string; exp: number }>('tiktok:access');
  if (cached && cached.exp > Date.now() + 60_000) return cached.token;
  const [key, secret, refresh] = [await tok('TIKTOK_CLIENT_KEY'), await tok('TIKTOK_CLIENT_SECRET'), await tok('TIKTOK_REFRESH_TOKEN')];
  if (!key || !secret || !refresh) return null;
  const r = await json<any>('https://open.tiktokapis.com/v2/oauth/token/', {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_key: key, client_secret: secret, grant_type: 'refresh_token', refresh_token: refresh }).toString(),
  });
  if (!r.access_token) throw new Error(`TikTok token refresh failed: ${r.error_description || r.error || 'unknown'}`);
  await kvSet('tiktok:access', { token: r.access_token, exp: Date.now() + (r.expires_in || 86400) * 1000 });
  if (r.refresh_token && r.refresh_token !== refresh) await setTok('TIKTOK_REFRESH_TOKEN', r.refresh_token);
  return r.access_token;
}
