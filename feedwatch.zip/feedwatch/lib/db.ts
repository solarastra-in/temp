// Postgres when DATABASE_URL is set; otherwise an embedded Postgres (PGlite) in ./.data.
import { SCHEMA_SQL, seed } from './schema';

type Row = Record<string, any>;
type Runner = (text: string, params?: any[]) => Promise<Row[]>;
const g = globalThis as any;

async function makeRunner(): Promise<Runner> {
  const url = process.env.DATABASE_URL;
  if (url) {
    const postgres = (await import('postgres')).default;
    const sql = postgres(url, { max: 3, prepare: false, ssl: url.includes('localhost') ? false : 'require' });
    return async (text, params = []) => (await sql.unsafe(text, params as any[])) as unknown as Row[];
  }
  const { PGlite } = await import('@electric-sql/pglite');
  const dir = process.env.PGLITE_DIR || './.data/pglite';
  (await import('node:fs')).mkdirSync(dir, { recursive: true });
  const db = new PGlite(dir);
  await db.waitReady;
  let chain: Promise<any> = Promise.resolve();
  return (text, params = []) => {
    const p = chain.then(() => db.query(text, params)).then((r: any) => r.rows as Row[]);
    chain = p.catch(() => undefined);
    return p;
  };
}

async function init(): Promise<Runner> {
  const run = await makeRunner();
  for (const stmt of SCHEMA_SQL.split(';\n').map((s) => s.trim()).filter(Boolean)) await run(stmt);
  await seed(run);
  return run;
}

export async function q<T = Row>(text: string, params: any[] = []): Promise<T[]> {
  if (!g.__fwdb) g.__fwdb = init().catch((e) => { g.__fwdb = undefined; throw e; });
  return (await (await g.__fwdb)(text, params)) as T[];
}
export async function one<T = Row>(text: string, params: any[] = []): Promise<T | null> {
  return (await q<T>(text, params))[0] ?? null;
}
export async function kvGet<T = any>(k: string): Promise<T | null> {
  const r = await one<any>(`SELECT v FROM kv WHERE k = $1`, [k]);
  return r ? (r.v as T) : null;
}
export async function kvSet(k: string, v: any) {
  await q(`INSERT INTO kv (k, v) VALUES ($1, $2::jsonb) ON CONFLICT (k) DO UPDATE SET v = EXCLUDED.v`, [k, JSON.stringify(v)]);
}
