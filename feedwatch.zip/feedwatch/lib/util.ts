import { createHash } from 'node:crypto';

const UA = 'Mozilla/5.0 (compatible; Feedwatch/1.0; personal feed reader)';

export async function http(url: string, init: RequestInit & { timeoutMs?: number } = {}) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), init.timeoutMs ?? 15000);
  try {
    const res = await fetch(url, { ...init, headers: { 'User-Agent': UA, ...(init.headers || {}) }, signal: ctrl.signal, redirect: 'follow' });
    const text = await res.text();
    if (!res.ok) throw new Error(`${res.status} from ${new URL(url).hostname}: ${text.slice(0, 160).replace(/\s+/g, ' ')}`);
    return text;
  } finally { clearTimeout(t); }
}
export async function json<T = any>(url: string, init: RequestInit & { timeoutMs?: number } = {}): Promise<T> {
  return JSON.parse(await http(url, init));
}
export const hashId = (s: string) => createHash('sha1').update(s).digest('hex').slice(0, 24);

function decode(s: string) {
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&amp;/g, '&').trim();
}
export const stripHtml = (s: string) => decode(s).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();

export type FeedEntry = { title: string; link: string; published?: string; summary?: string; image?: string; id?: string };
export function parseFeed(xml: string): FeedEntry[] {
  const out: FeedEntry[] = [];
  const blocks = xml.match(/<item[\s>][\s\S]*?<\/item>/g) || xml.match(/<entry[\s>][\s\S]*?<\/entry>/g) || [];
  for (const b of blocks) {
    const tag = (n: string) => { const m = b.match(new RegExp(`<${n}[^>]*>([\\s\\S]*?)</${n}>`)); return m ? decode(m[1]) : undefined; };
    let link = tag('link');
    if (!link || link.startsWith('<')) link = b.match(/<link[^>]*href="([^"]+)"/)?.[1];
    const title = tag('title') || '';
    if (!link) continue;
    const img = b.match(/<media:thumbnail[^>]*url="([^"]+)"/)?.[1] || b.match(/<media:content[^>]*url="([^"]+)"/)?.[1] || b.match(/<enclosure[^>]*url="([^"]+)"/)?.[1] || decode(tag('description') || '').match(/<img[^>]+src="([^"]+)"/)?.[1];
    out.push({
      id: tag('yt:videoId') || tag('guid') || tag('id'), title: stripHtml(title), link: link.trim(),
      published: tag('pubDate') || tag('published') || tag('updated') || tag('dc:date'),
      summary: stripHtml(tag('description') || tag('media:description') || tag('summary') || tag('content') || '').slice(0, 600), image: img,
    });
  }
  return out;
}
export const iso = (d?: string | number | null) => {
  if (d == null || d === '') return new Date().toISOString();
  const n = typeof d === 'number' ? new Date(d < 1e12 ? d * 1000 : d) : new Date(d);
  return isNaN(n.getTime()) ? new Date().toISOString() : n.toISOString();
};
