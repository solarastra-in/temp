import { tok } from './tokens';

export async function alertsConfigured() {
  return !!((await tok('TELEGRAM_BOT_TOKEN')) && (await tok('TELEGRAM_CHAT_ID'))) || !!process.env.RESEND_API_KEY;
}

const esc = (s: string) => s.replace(/[<>&]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]!));

export async function sendAlert(msg: { title: string; body?: string; url: string; image?: string | null }) {
  const bot = await tok('TELEGRAM_BOT_TOKEN');
  const chat = await tok('TELEGRAM_CHAT_ID');
  const text = `<b>${esc(msg.title)}</b>\n${esc((msg.body || '').slice(0, 500))}\n${msg.url}`;
  let sent = false;
  if (bot && chat) {
    const res = await fetch(`https://api.telegram.org/bot${bot}/sendMessage`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chat, text, parse_mode: 'HTML', disable_web_page_preview: false }),
    });
    if (!res.ok) throw new Error(`Telegram ${res.status}: ${(await res.text()).slice(0, 120)}`);
    sent = true;
  }
  if (process.env.RESEND_API_KEY && process.env.ALERT_EMAIL) {
    await fetch('https://api.resend.com/emails', {
      method: 'POST', headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: process.env.EMAIL_FROM || 'Feedwatch <no-reply@example.com>', to: process.env.ALERT_EMAIL, subject: msg.title, text: `${msg.body || ''}\n\n${msg.url}` }),
    });
    sent = true;
  }
  if (!sent) console.log(`[alert] ${msg.title} ${msg.url}`);
  return sent;
}
