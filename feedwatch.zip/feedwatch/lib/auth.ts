import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';

const COOKIE = 'fw_session';
const key = () => new TextEncoder().encode(process.env.AUTH_SECRET || 'dev-only-feedwatch-secret-change-me-please');

export function passwordRequired() { return !!process.env.APP_PASSWORD; }

export async function signIn(password: string) {
  if (!process.env.APP_PASSWORD || password !== process.env.APP_PASSWORD) return false;
  const t = await new SignJWT({ ok: true }).setProtectedHeader({ alg: 'HS256' }).setExpirationTime('90d').sign(key());
  (await cookies()).set(COOKIE, t, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: 90 * 86400 });
  return true;
}
export async function signOut() { (await cookies()).delete(COOKIE); }

export async function isAuthed() {
  if (!process.env.APP_PASSWORD) return process.env.NODE_ENV !== 'production';
  const t = (await cookies()).get(COOKIE)?.value;
  if (!t) return false;
  try { await jwtVerify(t, key()); return true; } catch { return false; }
}
export async function guard() {
  if (!(await isAuthed())) throw Object.assign(new Error('Sign in first'), { status: 401 });
}
