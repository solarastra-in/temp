// One collector per platform. Each tries the official API first (you own these accounts,
// so owner tokens give full, reliable access), then an optional self-hosted RSSHub route,
// then explains exactly what to set up.
import { json, http, parseFeed, iso, stripHtml } from '../util';
import { tok, tiktokAccessToken } from '../tokens';

export type Item = { key: string; kind: 'post' | 'video' | 'live' | 'article'; title?: string; body?: string; url: string; image?: string | null; live_state?: string | null; published_at: string };
export type Result = { items: Item[]; method: string };
export class NeedsSetup extends Error {}

type Source = { id: string; url: string; platform: string; handle: string; meta: any };
const bare = (h: string) => h.replace(/^@/, '');

async function viaRsshub(route: string): Promise<Result | null> {
  const base = await tok('RSSHUB_BASE');
  if (!base) return null;
  const items = parseFeed(await http(base.replace(/\/$/, '') + route)).slice(0, 20).map((e) => ({
    key: e.link, kind: 'post' as const, title: e.title, body: e.summary, url: e.link, image: e.image, published_at: iso(e.published),
  }));
  return { items, method: 'RSSHub' };
}

// ---------- X ----------
async function x(s: Source): Promise<Result> {
  const bearer = await tok('X_BEARER_TOKEN');
  if (bearer) {
    const H = { headers: { Authorization: `Bearer ${bearer}` } };
    let uid = s.meta?.xUserId;
    if (!uid) uid = (await json<any>(`https://api.x.com/2/users/by/username/${bare(s.handle)}`, H)).data?.id;
    if (!uid) throw new Error('X user not found');
    s.meta.xUserId = uid;
    const tl = await json<any>(`https://api.x.com/2/users/${uid}/tweets?max_results=10&exclude=replies&tweet.fields=created_at,attachments&expansions=attachments.media_keys&media.fields=url,preview_image_url`, H);
    const media: Record<string, any> = Object.fromEntries((tl.includes?.media || []).map((m: any) => [m.media_key, m]));
    return {
      method: 'X API',
      items: (tl.data || []).map((t: any) => {
        const m = media[t.attachments?.media_keys?.[0]];
        return { key: t.id, kind: 'post', body: t.text, url: `https://x.com/${bare(s.handle)}/status/${t.id}`, image: m?.url || m?.preview_image_url, published_at: iso(t.created_at) };
      }),
    };
  }
  const r = await viaRsshub(`/twitter/user/${bare(s.handle)}`);
  if (r) return r;
  throw new NeedsSetup('Add an X API bearer token (developer.x.com). X has no free public feed.');
}

// ---------- Instagram ----------
async function instagram(s: Source): Promise<Result> {
  const t = await tok('INSTAGRAM_TOKEN');
  if (t) {
    const me = await json<any>(`https://graph.instagram.com/v21.0/me?fields=user_id,username&access_token=${t}`);
    if (String(me.username).toLowerCase() === bare(s.handle).toLowerCase()) {
      const d = await json<any>(`https://graph.instagram.com/v21.0/me/media?fields=id,caption,media_type,media_url,permalink,thumbnail_url,timestamp&limit=20&access_token=${t}`);
      return {
        method: 'Instagram API (owner)',
        items: (d.data || []).map((m: any) => ({ key: m.id, kind: m.media_type === 'VIDEO' ? 'video' : 'post', body: m.caption, url: m.permalink, image: m.thumbnail_url || (m.media_type !== 'VIDEO' ? m.media_url : null), published_at: iso(m.timestamp) })),
      };
    }
    // Another business/creator account: business discovery through your own account.
    const d = await json<any>(`https://graph.instagram.com/v21.0/${me.user_id}?fields=business_discovery.username(${bare(s.handle)}){media.limit(20){id,caption,media_type,media_url,permalink,thumbnail_url,timestamp}}&access_token=${t}`).catch(() => null);
    const media = d?.business_discovery?.media?.data;
    if (media) return { method: 'Instagram business discovery', items: media.map((m: any) => ({ key: m.id, kind: m.media_type === 'VIDEO' ? 'video' : 'post', body: m.caption, url: m.permalink, image: m.thumbnail_url || m.media_url, published_at: iso(m.timestamp) })) };
  }
  const r = await viaRsshub(`/instagram/user/${bare(s.handle)}`);
  if (r) return r;
  throw new NeedsSetup('Add an Instagram token: make the account Business or Creator, then create a Meta app with "Instagram API with Instagram Login".');
}

// ---------- Threads ----------
async function threads(s: Source): Promise<Result> {
  const t = await tok('THREADS_TOKEN');
  if (t) {
    const me = await json<any>(`https://graph.threads.net/v1.0/me?fields=id,username&access_token=${t}`);
    if (String(me.username).toLowerCase() !== bare(s.handle).toLowerCase()) throw new NeedsSetup(`The Threads token belongs to @${me.username}. The Threads API only reads the token owner's posts.`);
    const d = await json<any>(`https://graph.threads.net/v1.0/me/threads?fields=id,text,permalink,timestamp,media_type,media_url,thumbnail_url&limit=20&access_token=${t}`);
    return { method: 'Threads API (owner)', items: (d.data || []).map((p: any) => ({ key: p.id, kind: p.media_type === 'VIDEO' ? 'video' : 'post', body: p.text, url: p.permalink, image: p.thumbnail_url || (p.media_type === 'IMAGE' ? p.media_url : null), published_at: iso(p.timestamp) })) };
  }
  const r = await viaRsshub(`/threads/${bare(s.handle)}`);
  if (r) return r;
  throw new NeedsSetup('Add a Threads token (Meta app with the Threads API, threads_basic scope).');
}

// ---------- Facebook Page ----------
async function facebook(s: Source): Promise<Result> {
  const t = await tok('FB_PAGE_TOKEN');
  if (!t) throw new NeedsSetup('Add a Facebook Page access token (Meta app, pages_read_engagement) for this Page.');
  const d = await json<any>(`https://graph.facebook.com/v21.0/${s.handle}/posts?fields=id,message,permalink_url,created_time,full_picture&limit=20&access_token=${t}`);
  return { method: 'Facebook Graph API', items: (d.data || []).map((p: any) => ({ key: p.id, kind: 'post', body: p.message, url: p.permalink_url, image: p.full_picture, published_at: iso(p.created_time) })) };
}

// ---------- TikTok ----------
async function tiktok(s: Source): Promise<Result> {
  const t = await tiktokAccessToken();
  if (t) {
    const d = await json<any>('https://open.tiktokapis.com/v2/video/list/?fields=id,title,video_description,create_time,cover_image_url,share_url', {
      method: 'POST', headers: { Authorization: `Bearer ${t}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ max_count: 20 }),
    });
    if (d.error?.code && d.error.code !== 'ok') throw new Error(`TikTok: ${d.error.message || d.error.code}`);
    return { method: 'TikTok Display API (owner)', items: (d.data?.videos || []).map((v: any) => ({ key: v.id, kind: 'video', title: v.title, body: v.video_description, url: v.share_url || `https://www.tiktok.com/@${bare(s.handle)}/video/${v.id}`, image: v.cover_image_url, published_at: iso(v.create_time) })) };
  }
  const r = await viaRsshub(`/tiktok/user/@${bare(s.handle)}`);
  if (r) return r;
  throw new NeedsSetup('Connect TikTok: create a TikTok developer app with Login Kit (scope video.list), sign in once as @' + bare(s.handle) + ', and paste the client key, secret and refresh token.');
}

// ---------- LinkedIn ----------
async function linkedin(s: Source): Promise<Result> {
  if (s.platform === 'LinkedIn profile') throw new NeedsSetup('LinkedIn does not let apps read posts from personal profiles (/in/). Create a LinkedIn Company Page for the team, add it here, and connect it with LINKEDIN_TOKEN + LINKEDIN_ORG_ID.');
  const [t, org] = [await tok('LINKEDIN_TOKEN'), await tok('LINKEDIN_ORG_ID')];
  if (!t || !org) throw new NeedsSetup('Add a LinkedIn token (Community Management API) and the organization id.');
  const d = await json<any>(`https://api.linkedin.com/rest/posts?q=author&author=${encodeURIComponent(`urn:li:organization:${org}`)}&count=20`, {
    headers: { Authorization: `Bearer ${t}`, 'LinkedIn-Version': process.env.LINKEDIN_VERSION || '202506', 'X-Restli-Protocol-Version': '2.0.0' },
  });
  return { method: 'LinkedIn Posts API', items: (d.elements || []).map((p: any) => ({ key: p.id, kind: 'post', body: p.commentary, url: `https://www.linkedin.com/feed/update/${p.id}/`, published_at: iso(p.publishedAt || p.createdAt) })) };
}

// ---------- YouTube (uploads + live) ----------
async function youtube(s: Source): Promise<Result> {
  let cid: string | undefined = s.meta?.channelId || s.url.match(/channel\/(UC[\w-]{22})/)?.[1];
  if (!cid) {
    const html = await http(s.url);
    cid = html.match(/"channelId":"(UC[\w-]{22})"/)?.[1] || html.match(/channel\/(UC[\w-]{22})/)?.[1];
    if (!cid) throw new Error('Could not find the channel id');
    s.meta.channelId = cid;
  }
  const entries = parseFeed(await http(`https://www.youtube.com/feeds/videos.xml?channel_id=${cid}`)).slice(0, 15);
  const items: Item[] = entries.map((e) => {
    const vid = e.id?.replace('yt:video:', '') || e.link.match(/v=([\w-]{11})/)?.[1] || e.link;
    return { key: vid, kind: 'video', title: e.title, body: e.summary, url: e.link, image: e.image || `https://i.ytimg.com/vi/${vid}/hqdefault.jpg`, published_at: iso(e.published), live_state: null };
  });
  const key = await tok('YOUTUBE_API_KEY');
  let method = 'YouTube RSS';
  if (key && items.length) {
    const d = await json<any>(`https://www.googleapis.com/youtube/v3/videos?part=snippet,liveStreamingDetails&id=${items.map((i) => i.key).join(',')}&key=${key}`);
    const byId: Record<string, any> = Object.fromEntries((d.items || []).map((v: any) => [v.id, v]));
    for (const i of items) {
      const v = byId[i.key];
      const state = v?.snippet?.liveBroadcastContent; // 'live' | 'upcoming' | 'none'
      if (state === 'live' || state === 'upcoming') { i.kind = 'live'; i.live_state = state; }
      else if (v?.liveStreamingDetails?.actualEndTime) i.live_state = 'ended';
      if (state === 'upcoming' && v.liveStreamingDetails?.scheduledStartTime) i.body = `Scheduled for ${v.liveStreamingDetails.scheduledStartTime}. ${i.body || ''}`;
    }
    method = 'YouTube RSS + Data API (live)';
  } else {
    // No key: check the channel's /live page (best-effort).
    try {
      const html = await http(`https://www.youtube.com/channel/${cid}/live`);
      const vid = html.match(/<link rel="canonical" href="https:\/\/www\.youtube\.com\/watch\?v=([\w-]{11})"/)?.[1];
      if (vid && /"isLiveNow":true/.test(html)) {
        const title = stripHtml(html.match(/<meta name="title" content="([^"]*)"/)?.[1] || 'Live now');
        const existing = items.find((i) => i.key === vid);
        if (existing) { existing.kind = 'live'; existing.live_state = 'live'; }
        else items.unshift({ key: vid, kind: 'live', title, url: `https://www.youtube.com/watch?v=${vid}`, image: `https://i.ytimg.com/vi/${vid}/hqdefault.jpg`, published_at: iso(), live_state: 'live' });
      }
      method = 'YouTube RSS + live page check';
    } catch { /* ignore */ }
  }
  return { items, method };
}

// ---------- RSS / Atom ----------
async function rss(s: Source): Promise<Result> {
  return { method: 'RSS', items: parseFeed(await http(s.url)).slice(0, 30).map((e) => ({ key: e.id || e.link, kind: 'article', title: e.title, body: e.summary, url: e.link, image: e.image, published_at: iso(e.published) })) };
}

// ---------- Any web page: new links that appear ----------
async function webpage(s: Source): Promise<Result> {
  const html = await http(s.url);
  const base = new URL(s.url);
  const items: Item[] = [];
  const seen = new Set<string>();
  for (const m of html.matchAll(/<a[^>]+href="([^"#]+)"[^>]*>([\s\S]{8,300}?)<\/a>/g)) {
    const text = stripHtml(m[2]);
    if (text.length < 20 || /cookie|privacy|terms|sign in|log in|subscribe/i.test(text)) continue;
    let href: string;
    try { href = new URL(m[1], base).toString(); } catch { continue; }
    if (!href.startsWith(base.origin) || href === s.url || seen.has(href)) continue;
    seen.add(href);
    items.push({ key: href, kind: 'article', title: text.slice(0, 200), url: href, published_at: iso() });
    if (items.length >= 30) break;
  }
  return { items, method: 'Page watch (new links)' };
}

export async function collect(s: Source): Promise<Result> {
  switch (s.platform) {
    case 'X': return x(s);
    case 'Instagram': return instagram(s);
    case 'Threads': return threads(s);
    case 'Facebook': return facebook(s);
    case 'TikTok': return tiktok(s);
    case 'LinkedIn profile': case 'LinkedIn page': return linkedin(s);
    case 'YouTube': return youtube(s);
    case 'RSS': return rss(s);
    default: return webpage(s);
  }
}
