// Recognise a source URL and normalise it.
export type Detected = { platform: string; handle: string; url: string };

const RULES: [string, RegExp, (m: RegExpMatchArray) => Detected][] = [
  ['X', /^https?:\/\/(?:www\.)?(?:x|twitter)\.com\/([A-Za-z0-9_]{1,15})\/?$/i, (m) => ({ platform: 'X', handle: '@' + m[1], url: `https://x.com/${m[1]}` })],
  ['Instagram', /^https?:\/\/(?:www\.)?instagram\.com\/([A-Za-z0-9._]{1,30})\/?$/i, (m) => ({ platform: 'Instagram', handle: '@' + m[1], url: `https://www.instagram.com/${m[1]}/` })],
  ['Threads', /^https?:\/\/(?:www\.)?threads\.(?:net|com)\/@([A-Za-z0-9._]{1,30})\/?$/i, (m) => ({ platform: 'Threads', handle: '@' + m[1], url: `https://www.threads.com/@${m[1]}` })],
  ['Facebook', /^https?:\/\/(?:www\.|m\.)?facebook\.com\/([A-Za-z0-9.\-]{2,80})\/?$/i, (m) => ({ platform: 'Facebook', handle: m[1], url: `https://www.facebook.com/${m[1]}/` })],
  ['TikTok', /^https?:\/\/(?:www\.)?tiktok\.com\/@([A-Za-z0-9._]{1,30})\/?$/i, (m) => ({ platform: 'TikTok', handle: '@' + m[1], url: `https://www.tiktok.com/@${m[1]}` })],
  ['LinkedIn', /^https?:\/\/(?:www\.)?linkedin\.com\/(in|company)\/([A-Za-z0-9\-_%]{2,100})\/?$/i, (m) => ({ platform: m[1].toLowerCase() === 'in' ? 'LinkedIn profile' : 'LinkedIn page', handle: m[2], url: `https://www.linkedin.com/${m[1].toLowerCase()}/${m[2]}/` })],
  ['YouTube', /^https?:\/\/(?:www\.)?youtube\.com\/((?:@[A-Za-z0-9._\-]{2,60})|(?:channel\/UC[A-Za-z0-9_\-]{22}))\/?$/i, (m) => ({ platform: 'YouTube', handle: m[1].startsWith('@') ? m[1] : m[1].split('/')[1], url: `https://www.youtube.com/${m[1]}` })],
];

export function detect(raw: string): Detected | null {
  const url = raw.trim().replace(/\?.*$/, '');
  for (const [, re, fn] of RULES) { const m = url.match(re); if (m) return fn(m); }
  if (/^https?:\/\//i.test(url)) return { platform: /rss|feed|atom|\.xml$/i.test(url) ? 'RSS' : 'Web page', handle: new URL(url).hostname.replace(/^www\./, ''), url: raw.trim() };
  return null;
}
