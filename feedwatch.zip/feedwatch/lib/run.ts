// One collection pass over every enabled source.
import { q, one } from './db';
import { collect, NeedsSetup, Item } from './collectors';
import { refreshTokens } from './tokens';
import { sendAlert } from './alerts';
import { hashId } from './util';

const g = globalThis as any;

export async function runOnce(onlySource?: string) {
  if (g.__fwRunning) return { skipped: 'already running' };
  g.__fwRunning = true;
  const runId = crypto.randomUUID();
  await q(`INSERT INTO runs (id) VALUES ($1)`, [runId]);
  let newItems = 0, alerts = 0;
  const notes: string[] = [];
  try {
    await refreshTokens();
    const rules = await q<any>(`SELECT * FROM rules`);
    const mute = rules.filter((r) => r.kind === 'mute').map((r) => r.pattern.toLowerCase());
    const hi = rules.filter((r) => r.kind === 'highlight').map((r) => r.pattern.toLowerCase());
    const sources = await q<any>(`SELECT * FROM sources WHERE enabled = true ${onlySource ? 'AND id = $1' : ''} ORDER BY created_at`, onlySource ? [onlySource] : []);
    for (const s of sources) {
      const baseline = !s.last_ok; // first successful run: store, don't alert
      try {
        const r = await collect(s);
        let added = 0;
        for (const it of r.items) added += await store(s, it, baseline, mute, hi).then((x) => { alerts += x.alerted; return x.added; });
        newItems += added;
        await q(`UPDATE sources SET last_checked = now(), last_ok = now(), last_error = NULL, method = $2, meta = $3::jsonb WHERE id = $1`, [s.id, r.method, JSON.stringify(s.meta || {})]);
        notes.push(`${s.platform} ${s.handle}: +${added}`);
      } catch (e: any) {
        const msg = (e instanceof NeedsSetup ? 'Setup needed: ' : '') + String(e.message).slice(0, 400);
        await q(`UPDATE sources SET last_checked = now(), last_error = $2, meta = $3::jsonb WHERE id = $1`, [s.id, msg, JSON.stringify(s.meta || {})]);
        notes.push(`${s.platform} ${s.handle}: ${e instanceof NeedsSetup ? 'setup needed' : 'error'}`);
      }
    }
    // Retry alerts that failed to send in the last day.
    for (const it of await q<any>(`SELECT i.*, s.label, s.handle FROM items i JOIN sources s ON s.id = i.source_id WHERE i.alerted = false AND i.seen_at > now() - interval '1 day' LIMIT 10`)) {
      try { await sendAlert({ title: `New on ${it.platform}: ${it.label || it.handle}`, body: it.title || it.body, url: it.url }); await q(`UPDATE items SET alerted = true WHERE id = $1`, [it.id]); alerts++; } catch { break; }
    }
  } finally {
    await q(`UPDATE runs SET finished_at = now(), new_items = $2, alerts = $3, summary = $4 WHERE id = $1`, [runId, newItems, alerts, notes.join(' · ')]);
    g.__fwRunning = false;
  }
  await q(`DELETE FROM runs WHERE started_at < now() - interval '14 days'`);
  return { newItems, alerts, notes };
}

async function store(s: any, it: Item, baseline: boolean, mute: string[], hi: string[]) {
  const id = hashId(`${s.id}:${it.key}`);
  const text = `${it.title || ''} ${it.body || ''}`.toLowerCase();
  if (mute.some((m) => text.includes(m))) return { added: 0, alerted: 0 };
  const prev = await one<any>(`SELECT * FROM items WHERE id = $1`, [id]);
  if (prev) {
    // Live state change on a known video (upcoming -> live) is its own alert.
    if (it.live_state && it.live_state !== prev.live_state) {
      await q(`UPDATE items SET live_state = $2, kind = $3, body = COALESCE($4, body) WHERE id = $1`, [id, it.live_state, it.kind, it.body?.slice(0, 2000) ?? null]);
      if (it.live_state === 'live' && s.alert !== 'none') {
        await sendAlert({ title: `LIVE NOW: ${s.label || s.handle} on YouTube`, body: it.title, url: it.url }).catch(() => {});
        return { added: 0, alerted: 1 };
      }
    }
    return { added: 0, alerted: 0 };
  }
  const highlighted = hi.some((h) => text.includes(h));
  const want = !baseline && (s.alert === 'all' || (s.alert === 'live' && it.live_state === 'live') || (s.alert === 'keywords' && highlighted));
  await q(
    `INSERT INTO items (id, source_id, platform, kind, title, body, url, image, live_state, published_at, starred, alerted) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) ON CONFLICT (id) DO NOTHING`,
    [id, s.id, s.platform, it.kind, it.title?.slice(0, 300) || null, it.body?.slice(0, 2000) || null, it.url, it.image || null, it.live_state || null, it.published_at, highlighted, !want]
  );
  let alerted = 0;
  if (want) {
    const title = it.live_state === 'live' ? `LIVE NOW: ${s.label || s.handle}` : it.live_state === 'upcoming' ? `Scheduled live: ${s.label || s.handle}` : `New on ${s.platform}: ${s.label || s.handle}`;
    try { await sendAlert({ title, body: it.title || it.body, url: it.url, image: it.image }); await q(`UPDATE items SET alerted = true WHERE id = $1`, [id]); alerted = 1; } catch { /* retried next run */ }
  }
  return { added: 1, alerted };
}
