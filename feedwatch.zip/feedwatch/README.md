# Feedwatch

Feedwatch is a private feed reader for the sources you choose. It checks them every 10 minutes, saves new posts, spots YouTube lives, and sends you a Telegram alert. It comes pre-loaded with Arabian Aces on X, LinkedIn, Instagram, Threads, Facebook and TikTok. You can add any YouTube channel, RSS feed or web page from the Sources page.

## How each source is read

| Source | Method | Reliability |
|---|---|---|
| Instagram @arabianacesofficial | Instagram API, as the account owner | Official. Token renews itself. |
| Threads @arabianacesofficial | Threads API, as the account owner | Official. Token renews itself. |
| Facebook /arabianacesofficial | Graph API with a Page token | Official |
| TikTok @arabianaces | TikTok Display API (video.list), as the account owner | Official. Token rotates itself. |
| X @arabianacesT10 | X API v2 (paid read access) | Official |
| LinkedIn /in/arabianaces | **Not readable.** LinkedIn blocks apps from reading personal profiles. | Create a Company Page and add that instead. |
| YouTube channels | Public RSS for uploads, plus a Data API key for live and upcoming detection (or a best-effort /live page check without one) | Official, near-free |
| RSS / Atom | Direct | — |
| Any web page | Watches for new links | Best-effort |
| Optional fallback | Your own RSSHub instance for sources without a token | Personal use only |

Instagram business discovery also lets you follow **other** public business or creator accounts, such as rival teams or sponsors, through your own token.

## Alerts

Each source has its own alert setting: every post, lives only (the default for YouTube), keywords only, or none. **Highlight** words star matching posts and alert on them. **Mute** words hide matching posts. On a source's first check its existing posts are saved without alerts, so you don't get a flood. A stream going from upcoming to live sends its own "LIVE NOW" alert. Alerts that fail are retried on the next run.

## Run locally

```bash
npm install
cp .env.example .env.local     # set APP_PASSWORD
npm run dev                     # http://localhost:3100
```

Paste tokens on the **Settings** page (or set them as environment variables). **Check now** runs a pass immediately. `npm test` runs every collector offline against mocked APIs.

## Host it (free tier is enough)

1. Push to GitHub and import into Vercel. Add `APP_PASSWORD`, `AUTH_SECRET`, `CRON_SECRET`, `APP_URL` and `DATABASE_URL` (a free Supabase or Neon Postgres).
2. Add repository secrets `APP_URL` and `CRON_SECRET`. `.github/workflows/collect.yml` then checks every 10 minutes.
3. Alternatively, run it on any small VPS with `npm run build && npm start`, plus a crontab line: `*/10 * * * * cd /app && npm run collect`.

## One-time connections (about an hour in total)

- **Telegram:** message @BotFather to create a bot and copy its token. Send the bot "hi", then open `https://api.telegram.org/bot<TOKEN>/getUpdates` to find your chat id.
- **Meta (Instagram, Threads, Facebook):** make @arabianacesofficial a Business or Creator account linked to the Facebook Page. Create one app at developers.facebook.com and add *Instagram API with Instagram Login*, *Threads API* and Pages permissions. Generate the three tokens while logged in as the team. The app can stay in development mode, since only your own accounts use it.
- **TikTok:** create an app at developers.tiktok.com with Login Kit and the `video.list` scope. Authorise once as @arabianaces and paste the client key, secret and refresh token.
- **X:** get a project and bearer token at developer.x.com. Read access is paid.
- **YouTube:** create a free API key in Google Cloud with YouTube Data API v3 enabled.
- **LinkedIn:** create an Arabian Aces Company Page, then apply for the Community Management API.
