import { redirect } from 'next/navigation';
import { q } from '@/lib/db';
import { isAuthed } from '@/lib/auth';
import { ago } from '@/lib/format';
import { AddSource, SourceControls } from '@/components/Client';
import RunButton from '@/components/RunButton';

export default async function Sources() {
  if (!(await isAuthed())) redirect('/login');
  const ss = await q<any>(`SELECT s.*, (SELECT count(*) FROM items i WHERE i.source_id = s.id)::int AS n FROM sources s ORDER BY s.tag, s.created_at`);
  return (
    <div className="stack" style={{ gap: 18 }}>
      <div><h1>Sources</h1><div className="small muted">Paste any profile, channel, feed or page. Feedwatch picks the best way to read it.</div></div>
      <section className="card"><AddSource /></section>
      <section className="card scroll">
        <table>
          <thead><tr><th>Source</th><th>Status</th><th>Posts</th><th>Controls</th></tr></thead>
          <tbody>{ss.map((s) => (
            <tr key={s.id} style={{ opacity: s.enabled ? 1 : 0.55 }}>
              <td style={{ minWidth: 220 }}>
                <div className="row"><span className="pill">{s.platform}</span><b>{s.label || s.handle}</b></div>
                <a href={s.url} target="_blank" rel="noopener noreferrer" className="xs">{s.url}</a>
                <div className="xs muted">Tag: {s.tag}</div>
              </td>
              <td style={{ minWidth: 260 }}>
                {!s.last_checked ? <span className="pill">Not checked yet</span>
                  : s.last_error ? <div className="stack" style={{ gap: 4 }}><span className={`pill ${s.last_error.startsWith('Setup') ? 'warn' : ''}`} style={{ alignSelf: 'flex-start', color: s.last_error.startsWith('Setup') ? undefined : 'var(--live)' }}>{s.last_error.startsWith('Setup') ? 'Setup needed' : 'Error'}</span><span className="xs soft">{s.last_error.replace(/^Setup needed: /, '')}</span></div>
                  : <div className="stack" style={{ gap: 4 }}><span className="pill good" style={{ alignSelf: 'flex-start' }}>Working</span><span className="xs muted">{s.method} · checked {ago(s.last_checked)}</span></div>}
              </td>
              <td>{s.n}</td>
              <td><div className="stack"><SourceControls id={s.id} alert={s.alert} enabled={s.enabled} /><RunButton sourceId={s.id} label="Check this one" /></div></td>
            </tr>
          ))}</tbody>
        </table>
      </section>
    </div>
  );
}
