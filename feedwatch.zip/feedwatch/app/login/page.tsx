import { redirect } from 'next/navigation';
import { isAuthed, passwordRequired } from '@/lib/auth';
import { LoginForm } from '@/components/Client';
export default async function Login() {
  if (await isAuthed()) redirect('/');
  return (
    <div className="card stack" style={{ maxWidth: 380, margin: '60px auto' }}>
      <h1>Feedwatch</h1>
      {passwordRequired() ? <LoginForm /> : <div className="alert err">Set APP_PASSWORD to protect this app.</div>}
    </div>
  );
}
