import Link from 'next/link';
import { redirect } from 'next/navigation';
import { q } from '@/lib/db';
import { isAuthed } from '@/lib/auth';
import { ago, ytId } from '@/lib/format';
import { Star, LiveEmbed } from '@/components/Client';

type SP = { tag?: string; platform?: string; only?: string; q?: string };

export default async function Feed({ searchParams }: { searchParams: Promise<SP> }) {
  if (!(await isAuthed())) redirect('/login');
  const sp = await searchParams;
  const where = ['1=1'];
  const params: any[] = [];
  if (sp.tag) { params.push(sp.tag); where.push(`s.tag = $${params.length}`); }
  if (sp.platform) { params.push(sp.platform); where.push(`i.platform = $${params.length}`); }
  if (sp.only === 'live') where.push(`i.live_state IN ('live','upcoming')`);
  if (sp.only === 'starred') where.push(`i.starred = true`);
  if (sp.q) { params.push(`%${sp.q}%`); where.push(`(i.title ILIKE $${params.length} OR i.body ILIKE $${params.length})`); }
  const [items, live, tags, platforms, counts] = await Promise.all([
    q<any>(`SELECT i.*, s.handle, s.label, s.tag FROM items i JOIN sources s ON s.id = i.source_id WHERE ${where.join(' AND ')} ORDER BY i.published_at DESC LIMIT 120`, params),
    q<any>(`SELECT i.*, s.handle, s.label FROM items i JOIN sources s ON s.id = i.source_id WHERE i.live_state = 'live' ORDER BY i.published_at DESC LIMIT 6`),
    q<any>(`SELECT DISTINCT tag FROM sources ORDER BY tag`),
    q<any>(`SELECT DISTINCT platform FROM items ORDER BY platform`),
    q<any>(`SELECT (SELECT count(*) FROM sources WHERE enabled)::int AS sources, (SELECT count(*) FROM sources WHERE last_error IS NOT NULL AND enabled)::int AS issues, (SELECT count(*) FROM items WHERE seen_at > now() - interval '24 hours')::int AS today`),
  ]);
  const link = (patch: Partial<SP>) => { const u = new URLSearchParams({ ...sp, ...patch } as any); for (const [k, v] of [...u]) if (!v) u.delete(k); return `/?${u}`; };
  const c = counts[0];
  return (
    <div className="stack" style={{ gap: 18 }}>
      <div className="row wr">
        <div className="grow"><h1>Your feed</h1><div className="small muted">{c.today} new in the last 24h · {c.sources} sources{c.issues ? <> · <Link href="/sources">{c.issues} need attention</Link></> : null}</div></div>
        <form className="row" action="/"><input className="field" name="q" defaultValue={sp.q} placeholder="Search posts" style={{ width: 220 }} aria-label="Search" /></form>
      </div>

      {live.length ? (
        <section className="card stack" style={{ borderColor: 'var(--live)' }}>
          <div className="row"><span className="pill live">LIVE NOW</span><span className="small muted">{live.length} stream{live.length > 1 ? 's' : ''}</span></div>
          <div className="grid">{live.map((i) => { const v = ytId(i.url); return (
            <div key={i.id} className="stack"><b className="small">{i.label || i.handle}: {i.title}</b>{v ? <LiveEmbed videoId={v} title={i.title || 'Live'} /> : <a href={i.url} target="_blank" rel="noopener noreferrer">Open</a>}</div>
          ); })}</div>
        </section>
      ) : null}

      <div className="row wr">
        <Link href={link({ only: '', tag: '', platform: '' })} className={`pill ${!sp.only && !sp.tag && !sp.platform ? 'on' : ''}`}>Everything</Link>
        <Link href={link({ only: sp.only === 'live' ? '' : 'live' })} className={`pill ${sp.only === 'live' ? 'on' : ''}`}>Live &amp; upcoming</Link>
        <Link href={link({ only: sp.only === 'starred' ? '' : 'starred' })} className={`pill ${sp.only === 'starred' ? 'on' : ''}`}>Starred</Link>
        <span className="muted xs">|</span>
        {tags.map((t) => <Link key={t.tag} href={link({ tag: sp.tag === t.tag ? '' : t.tag })} className={`pill ${sp.tag === t.tag ? 'on' : ''}`}>{t.tag}</Link>)}
        <span className="muted xs">|</span>
        {platforms.map((p) => <Link key={p.platform} href={link({ platform: sp.platform === p.platform ? '' : p.platform })} className={`pill ${sp.platform === p.platform ? 'on' : ''}`}>{p.platform}</Link>)}
      </div>

      {items.length ? (
        <div className="grid">{items.map((i) => (
          <article key={i.id} className="card stack">
            <div className="row">
              <span className="pill">{i.platform}</span>
              {i.live_state === 'live' && <span className="pill live">LIVE</span>}
              {i.live_state === 'upcoming' && <span className="pill warn">Upcoming live</span>}
              <span className="xs muted grow">{i.label || i.handle} · {ago(i.published_at)}</span>
              <Star id={i.id} on={i.starred} />
            </div>
            {i.image ? <a href={i.url} target="_blank" rel="noopener noreferrer"><img className="thumb" src={i.image} alt="" loading="lazy" /></a> : null}
            {i.title ? <b style={{ lineHeight: 1.35 }}>{i.title}</b> : null}
            {i.body ? <div className="body soft">{i.body}</div> : null}
            <a href={i.url} target="_blank" rel="noopener noreferrer" className="small" style={{ fontWeight: 700 }}>Open on {i.platform} &rarr;</a>
          </article>
        ))}</div>
      ) : (
        <div className="card soft">Nothing here yet. New posts appear after each check. Sources that need a token are listed on <Link href="/sources">Sources</Link>.</div>
      )}
    </div>
  );
}
