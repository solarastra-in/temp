import { route } from '@/lib/api';
import { q } from '@/lib/db';
export const POST = route(async (req) => {
  const b = await req.json();
  if (!['mute', 'highlight'].includes(b.kind) || !String(b.pattern || '').trim()) throw new Error('Enter a word or phrase');
  await q(`INSERT INTO rules (id, kind, pattern) VALUES ($1,$2,$3)`, [crypto.randomUUID(), b.kind, String(b.pattern).trim()]);
  return { ok: true };
});
