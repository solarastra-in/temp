import { route } from '@/lib/api';
import { q } from '@/lib/db';
export const DELETE = route(async (_req, { params }) => { const { id } = await params; await q(`DELETE FROM rules WHERE id = $1`, [id]); return { ok: true }; });
