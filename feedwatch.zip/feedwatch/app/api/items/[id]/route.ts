import { route } from '@/lib/api';
import { q } from '@/lib/db';
export const PATCH = route(async (req, { params }) => {
  const { id } = await params;
  const b = await req.json();
  await q(`UPDATE items SET starred = $2 WHERE id = $1`, [id, !!b.starred]);
  return { ok: true };
});
