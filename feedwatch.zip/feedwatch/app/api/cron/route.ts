// Scheduler entry point: GET with "Authorization: Bearer $CRON_SECRET".
import { NextResponse } from 'next/server';
import { runOnce } from '@/lib/run';
export const maxDuration = 300;
export const dynamic = 'force-dynamic';
export async function GET(req: Request) {
  if (!process.env.CRON_SECRET || req.headers.get('authorization') !== `Bearer ${process.env.CRON_SECRET}`) return NextResponse.json({ error: 'unauthorised' }, { status: 401 });
  return NextResponse.json(await runOnce());
}
