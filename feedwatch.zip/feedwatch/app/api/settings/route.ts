import { route } from '@/lib/api';
import { setTok, TOKEN_KEYS, TokenKey } from '@/lib/tokens';
import { sendAlert } from '@/lib/alerts';
import { kvSet } from '@/lib/db';
export const POST = route(async (req) => {
  const b = await req.json();
  if (b.test) { const sent = await sendAlert({ title: 'Feedwatch test alert', body: 'Alerts are working.', url: process.env.APP_URL || 'http://localhost:3100' }); if (!sent) throw new Error('No alert channel set up yet'); return { ok: true }; }
  if (!(b.key in TOKEN_KEYS)) throw new Error('Unknown setting');
  await setTok(b.key as TokenKey, String(b.value || ''));
  if (b.key === 'TIKTOK_REFRESH_TOKEN') await kvSet('tiktok:access', { token: '', exp: 0 });
  return { ok: true };
});
