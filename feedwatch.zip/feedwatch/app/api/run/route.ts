import { route } from '@/lib/api';
import { runOnce } from '@/lib/run';
export const maxDuration = 300;
export const POST = route(async (req) => {
  const b = await req.json().catch(() => ({}));
  return runOnce(b.sourceId);
});
