import { route } from '@/lib/api';
import { signIn } from '@/lib/auth';
export const POST = route(async (req) => {
  const { password } = await req.json();
  if (!(await signIn(String(password || '')))) throw Object.assign(new Error('Wrong password'), { status: 401 });
  return { ok: true };
}, { open: true });
