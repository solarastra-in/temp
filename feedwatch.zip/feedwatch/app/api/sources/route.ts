import { route } from '@/lib/api';
import { q } from '@/lib/db';
import { detect } from '@/lib/detect';
export const POST = route(async (req) => {
  const b = await req.json();
  const d = detect(String(b.url || ''));
  if (!d) throw new Error('Paste a full URL, e.g. https://www.youtube.com/@channel');
  if (b.asRss) d.platform = 'RSS';
  const r = await q(`INSERT INTO sources (id, url, platform, handle, label, tag, alert) VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (url) DO NOTHING RETURNING id`,
    [crypto.randomUUID(), d.url, d.platform, d.handle, b.label || null, b.tag || 'General', b.alert || (d.platform === 'YouTube' ? 'live' : 'all')]);
  if (!r.length) throw new Error('That source is already on your list');
  return { ok: true, id: r[0].id, ...d };
});
