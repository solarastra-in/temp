import { route } from '@/lib/api';
import { q } from '@/lib/db';
export const PATCH = route(async (req, { params }) => {
  const { id } = await params;
  const b = await req.json();
  if (b.alert && !['all', 'live', 'keywords', 'none'].includes(b.alert)) throw new Error('Bad alert mode');
  await q(`UPDATE sources SET alert = COALESCE($2, alert), enabled = COALESCE($3, enabled), tag = COALESCE($4, tag), label = COALESCE($5, label) WHERE id = $1`,
    [id, b.alert ?? null, typeof b.enabled === 'boolean' ? b.enabled : null, b.tag ?? null, b.label ?? null]);
  return { ok: true };
});
export const DELETE = route(async (_req, { params }) => {
  const { id } = await params;
  await q(`DELETE FROM items WHERE source_id = $1`, [id]);
  await q(`DELETE FROM sources WHERE id = $1`, [id]);
  return { ok: true };
});
