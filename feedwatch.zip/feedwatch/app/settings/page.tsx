import { redirect } from 'next/navigation';
import { q } from '@/lib/db';
import { isAuthed } from '@/lib/auth';
import { TOKEN_KEYS, tokenStatus, TokenKey } from '@/lib/tokens';
import { ago } from '@/lib/format';
import { TokenField, TestAlert, Rules } from '@/components/Client';

const GROUPS: [string, TokenKey[], string][] = [
  ['Alerts', ['TELEGRAM_BOT_TOKEN', 'TELEGRAM_CHAT_ID'], 'Create a bot with @BotFather, send it a message, then get your chat id from https://api.telegram.org/bot<TOKEN>/getUpdates.'],
  ['YouTube', ['YOUTUBE_API_KEY'], 'Uploads work without a key. A free Google Cloud API key (YouTube Data API v3) adds reliable live and scheduled-live detection.'],
  ['X', ['X_BEARER_TOKEN'], 'developer.x.com, create a project and copy the app bearer token. X charges for read access.'],
  ['Instagram', ['INSTAGRAM_TOKEN'], 'Switch @arabianacesofficial to a Business or Creator account. In developers.facebook.com create an app, add "Instagram API with Instagram Login", generate a token for the account. Refreshed automatically.'],
  ['Threads', ['THREADS_TOKEN'], 'Same Meta app: add the Threads use case (threads_basic), generate a long-lived token as @arabianacesofficial. Refreshed automatically.'],
  ['Facebook', ['FB_PAGE_TOKEN'], 'Same Meta app: Graph API Explorer, pick the Arabian Aces Page, permission pages_read_engagement, exchange for a long-lived Page token.'],
  ['TikTok', ['TIKTOK_CLIENT_KEY', 'TIKTOK_CLIENT_SECRET', 'TIKTOK_REFRESH_TOKEN'], 'developers.tiktok.com, create an app with Login Kit and scope video.list, sign in once as @arabianaces and keep the refresh token (valid a year, rotated automatically).'],
  ['LinkedIn', ['LINKEDIN_TOKEN', 'LINKEDIN_ORG_ID'], 'LinkedIn only allows reading Company Page posts. Create an Arabian Aces Company Page, request the Community Management API, then add the token and the page’s organization id.'],
  ['Fallback', ['RSSHUB_BASE'], 'Optional self-hosted RSSHub for sources without an API token. Personal use only; it relies on the sites’ public pages.'],
];

export default async function Settings() {
  if (!(await isAuthed())) redirect('/login');
  const [st, rules, runs] = await Promise.all([tokenStatus(), q<any>(`SELECT * FROM rules ORDER BY created_at`), q<any>(`SELECT * FROM runs ORDER BY started_at DESC LIMIT 12`)]);
  return (
    <div className="stack" style={{ gap: 18 }}>
      <div><h1>Settings</h1><div className="small muted">Tokens pasted here are stored in your database; environment variables work too. Instagram, Threads and TikTok tokens renew themselves.</div></div>
      {GROUPS.map(([name, keys, help]) => (
        <section key={name} className="card stack">
          <div className="row"><h2 className="grow">{name}</h2>{keys.every((k) => st[k].set) ? <span className="pill good">Connected</span> : <span className="pill">Not connected</span>}{name === 'Alerts' && <TestAlert />}</div>
          <div className="xs muted">{help}</div>
          {keys.map((k) => <TokenField key={k} k={k} label={TOKEN_KEYS[k]} set={st[k].set} />)}
        </section>
      ))}
      <section className="card stack"><h2>Keyword rules</h2><div className="xs muted">Highlight: stars the post and alerts sources set to &ldquo;keywords only&rdquo;. Mute: hides matching posts.</div><Rules rules={rules} /></section>
      <section className="card stack"><h2>Recent checks</h2>
        {runs.map((r) => <div key={r.id} className="row xs" style={{ alignItems: 'flex-start' }}><span className="muted" style={{ width: 70 }}>{ago(r.started_at)}</span><b style={{ width: 90 }}>{r.new_items} new, {r.alerts} alerts</b><span className="soft grow">{r.summary}</span></div>)}
        {!runs.length && <div className="xs muted">No checks yet.</div>}
      </section>
    </div>
  );
}
