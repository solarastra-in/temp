import './globals.css';
import Link from 'next/link';
import type { Metadata } from 'next';
import { isAuthed } from '@/lib/auth';
import RunButton from '@/components/RunButton';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: 'Feedwatch', description: 'New posts and live streams from the sources you follow.' };

export default async function Layout({ children }: { children: React.ReactNode }) {
  const authed = await isAuthed();
  return (
    <html lang="en">
      <body>
        <header className="top">
          <div className="wrap">
            <Link href="/" className="brand">Feed<span>watch</span></Link>
            {authed && <nav className="nav"><Link href="/">Feed</Link><Link href="/sources">Sources</Link><Link href="/settings">Settings</Link></nav>}
            <span className="grow" />
            {authed && <RunButton />}
            {authed && process.env.APP_PASSWORD && <form action="/api/logout" method="post"><button className="btn ghost sm">Sign out</button></form>}
          </div>
        </header>
        <main><div className="wrap">{children}</div></main>
      </body>
    </html>
  );
}
