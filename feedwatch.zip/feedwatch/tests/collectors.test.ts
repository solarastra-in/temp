// Offline tests: every collector against mocked official APIs, plus baseline, alerts, live transitions and token refresh.
process.env.PGLITE_DIR = './.data/test-' + Date.now();
Object.assign(process.env, {
  X_BEARER_TOKEN: 'x', INSTAGRAM_TOKEN: 'ig-old', THREADS_TOKEN: 'th', FB_PAGE_TOKEN: 'fb', TIKTOK_CLIENT_KEY: 'ck', TIKTOK_CLIENT_SECRET: 'cs', TIKTOK_REFRESH_TOKEN: 'rt',
  YOUTUBE_API_KEY: 'yt', TELEGRAM_BOT_TOKEN: 'bot', TELEGRAM_CHAT_ID: '42',
});
import assert from 'node:assert/strict';

const state = { round: 1, ytLive: 'upcoming' as string };
const telegram: string[] = [];
const hits: string[] = [];

(globalThis as any).fetch = async (url: string, init?: any) => {
  const u = String(url);
  hits.push(u.split('?')[0]);
  const J = (o: any) => new Response(JSON.stringify(o), { status: 200 });
  if (u.includes('api.telegram.org')) { telegram.push(JSON.parse(init.body).text); return J({ ok: true }); }
  if (u.includes('api.x.com/2/users/by/username/arabianacesT10')) return J({ data: { id: '99' } });
  if (u.includes('api.x.com/2/users/99/tweets')) return J({ data: [{ id: '1', text: 'Welcome Moeen Ali!', created_at: '2026-09-20T10:00:00Z' }, ...(state.round > 1 ? [{ id: '2', text: 'Draft day is here', created_at: '2026-09-24T10:00:00Z' }, { id: '3', text: 'Buy followers cheap spam', created_at: '2026-09-24T11:00:00Z' }] : [])] });
  if (u.includes('graph.instagram.com/refresh_access_token')) return J({ access_token: 'ig-new', expires_in: 5184000 });
  if (u.includes('graph.instagram.com/v21.0/me?')) { assert.ok(u.includes('ig-new'), 'uses refreshed token'); return J({ user_id: '7', username: 'arabianacesofficial' }); }
  if (u.includes('graph.instagram.com/v21.0/me/media')) return J({ data: [{ id: 'm1', caption: 'Kit reveal', media_type: 'IMAGE', media_url: 'https://img/1.jpg', permalink: 'https://www.instagram.com/p/m1/', timestamp: '2026-09-21T10:00:00+0000' }] });
  if (u.includes('graph.threads.net/refresh_access_token')) return J({ access_token: 'th2' });
  if (u.includes('graph.threads.net/v1.0/me?')) return J({ id: '5', username: 'arabianacesofficial' });
  if (u.includes('graph.threads.net/v1.0/me/threads')) return J({ data: [{ id: 't1', text: 'Threads is live for the Aces', permalink: 'https://www.threads.com/@arabianacesofficial/post/t1', timestamp: '2026-09-22T10:00:00+0000', media_type: 'TEXT_POST' }] });
  if (u.includes('graph.facebook.com/v21.0/arabianacesofficial/posts')) return J({ data: [{ id: 'f1', message: 'Our first Facebook post', permalink_url: 'https://www.facebook.com/arabianacesofficial/posts/f1', created_time: '2026-09-22T09:00:00+0000' }] });
  if (u.includes('open.tiktokapis.com/v2/oauth/token')) return J({ access_token: 'tt-access', expires_in: 86400, refresh_token: 'rt2' });
  if (u.includes('open.tiktokapis.com/v2/video/list')) { assert.equal(init.headers.Authorization, 'Bearer tt-access'); return J({ data: { videos: [{ id: 'v1', title: 'Nets session', create_time: 1758700000, share_url: 'https://www.tiktok.com/@arabianaces/video/v1', cover_image_url: 'https://img/tt.jpg' }] }, error: { code: 'ok' } }); }
  if (u.includes('youtube.com/@AcesTV')) return new Response('<html>"channelId":"UCaaaaaaaaaaaaaaaaaaaaaa"</html>');
  if (u.includes('youtube.com/feeds/videos.xml')) return new Response(`<feed><entry><yt:videoId>LIVE0000001</yt:videoId><title>Aces vs Gladiators LIVE</title><link rel="alternate" href="https://www.youtube.com/watch?v=LIVE0000001"/><published>2026-09-24T10:00:00Z</published></entry></feed>`);
  if (u.includes('googleapis.com/youtube/v3/videos')) return J({ items: [{ id: 'LIVE0000001', snippet: { liveBroadcastContent: state.ytLive }, liveStreamingDetails: { scheduledStartTime: '2026-09-25T14:00:00Z' } }] });
  if (u.includes('example.com/feed.xml')) return new Response(`<rss><item><title>Blog post one</title><link>https://example.com/1</link></item>${state.round > 1 ? '<item><title>Blog post two</title><link>https://example.com/2</link></item>' : ''}</rss>`);
  return new Response('nope', { status: 404 });
};

(async () => {
  const { q } = await import('../lib/db');
  const { runOnce } = await import('../lib/run');
  const { detect } = await import('../lib/detect');

  // URL detection for the seeded sources
  assert.equal(detect('https://www.threads.com/@arabianacesofficial')?.platform, 'Threads');
  assert.equal(detect('https://www.linkedin.com/in/arabianaces/')?.platform, 'LinkedIn profile');
  assert.equal(detect('https://www.tiktok.com/@arabianaces')?.handle, '@arabianaces');
  const seeded = await q<any>(`SELECT platform FROM sources ORDER BY platform`);
  assert.deepEqual(seeded.map((s) => s.platform), ['Facebook', 'Instagram', 'LinkedIn profile', 'Threads', 'TikTok', 'X']);
  await q(`INSERT INTO sources (id, url, platform, handle, label, tag, alert) VALUES ('yt','https://www.youtube.com/@AcesTV','YouTube','@AcesTV','Aces TV','Arabian Aces','live'), ('rss','https://example.com/feed.xml','RSS','example.com','Blog','General','all')`);
  await q(`INSERT INTO rules (id, kind, pattern) VALUES ('m1','mute','spam')`);

  // Round 1: baseline, no alerts
  let r: any = await runOnce();
  const bad = await q<any>(`SELECT platform, last_error FROM sources WHERE last_error IS NOT NULL`);
  assert.deepEqual(bad.map((b) => b.platform), ['LinkedIn profile'], JSON.stringify(bad));
  assert.match(bad[0].last_error, /Company Page/);
  const methods = await q<any>(`SELECT platform, method FROM sources WHERE method IS NOT NULL ORDER BY platform`);
  console.log('methods:', methods.map((m) => `${m.platform}=${m.method}`).join(', '));
  assert.equal(telegram.length, 0, 'baseline sends no alerts');
  const n1 = (await q<any>(`SELECT count(*)::int n FROM items`))[0].n;
  assert.equal(n1, 7); // X1, IG1, Threads1, FB1, TikTok1, YT1, RSS1
  const yt = (await q<any>(`SELECT * FROM items WHERE platform = 'YouTube'`))[0];
  assert.equal(yt.live_state, 'upcoming');
  const starred = (await q<any>(`SELECT starred FROM items WHERE body LIKE 'Welcome Moeen%'`))[0];
  assert.equal(starred.starred, true, 'highlight rule stars matching post');
  console.log('✓ round 1 baseline:', r.newItems, 'items, no alerts');

  // Round 2: new posts + stream goes live
  state.round = 2; state.ytLive = 'live';
  r = await runOnce();
  assert.equal(r.newItems, 2, JSON.stringify(r)); // X "Draft day" + RSS post two (spam muted)
  assert.ok(telegram.some((t) => t.includes('LIVE NOW') && t.includes('watch?v=LIVE0000001')), 'live alert');
  assert.ok(telegram.some((t) => t.includes('Draft day')), 'new X post alert');
  assert.ok(telegram.some((t) => t.includes('Blog post two')), 'new RSS alert');
  assert.ok(!telegram.some((t) => /spam/i.test(t)), 'muted post not alerted');
  assert.equal(telegram.length, 3);
  console.log('✓ round 2 alerts:', telegram.map((t) => t.split('\n')[0]).join(' | '));

  // Round 3: nothing new, no duplicate alerts
  r = await runOnce();
  assert.equal(r.newItems, 0); assert.equal(telegram.length, 3);
  console.log('✓ round 3: no duplicates');

  const tt = (await q<any>(`SELECT v FROM kv WHERE k = 'token:TIKTOK_REFRESH_TOKEN'`))[0];
  assert.equal(tt.v, 'rt2', 'rotated TikTok refresh token saved');
  assert.equal(hits.filter((h) => h.includes('graph.instagram.com/refresh_access_token')).length, 1, 'IG refreshed once per week');
  console.log('✓ token refresh');
  console.log('ALL FEEDWATCH TESTS PASSED');
  process.exit(0);
})().catch((e) => { console.error('FAILED', e); process.exit(1); });
