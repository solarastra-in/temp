'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

type Q = { id: string; prompt: string; options: string[]; points: number; answer: string | null; explain: string | null };

export default function ContestForm({ contestId, questions, mine, locked, instant, signedIn, needsTeam }:
  { contestId: string; questions: Q[]; mine: Record<string, string>; locked: boolean; instant: boolean; signedIn: boolean; needsTeam: boolean }) {
  const [picks, setPicks] = useState<Record<string, string>>(mine);
  const [revealed, setRevealed] = useState<Record<string, { answer: string; explain?: string }>>(
    Object.fromEntries(questions.filter((q) => q.answer).map((q) => [q.id, { answer: q.answer!, explain: q.explain || undefined }]))
  );
  const [msg, setMsg] = useState<{ kind: string; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(only?: string) {
    setBusy(true); setMsg(null);
    const answers = only ? { [only]: picks[only] } : picks;
    const r = await fetch(`/api/contests/${contestId}/enter`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ answers }) });
    const d = await r.json();
    setBusy(false);
    if (!r.ok) return setMsg({ kind: 'err', text: d.error });
    if (instant) {
      const add: typeof revealed = {};
      for (const [qid, res] of Object.entries<any>(d.results || {})) add[qid] = { answer: res.answer, explain: res.explain };
      setRevealed((p) => ({ ...p, ...add }));
    } else {
      setMsg({ kind: 'ok', text: 'Picks locked in. +5 points for entering. You can change them until the contest locks.' });
    }
    router.refresh();
  }

  const answeredAll = questions.every((q) => picks[q.id]);
  return (
    <div className="stack" style={{ gap: 18 }}>
      {!signedIn && (
        <div className="card gate row wrap-row">
          <div className="grow"><div style={{ fontWeight: 800 }}>Sign in to play</div><div className="small soft">Browse the questions freely. Picks need a free account.</div></div>
          <Link href={`/login?next=/play/${contestId}`} className="btn">Sign in</Link>
        </div>
      )}
      {needsTeam && <div className="alert info">Tip: <Link href="/me#team">choose your team</Link> so your points count in Fan Wars.</div>}
      {questions.map((q, i) => {
        const rev = revealed[q.id];
        const done = instant && !!rev;
        return (
          <section key={q.id} className="card stack">
            <div className="row"><span style={{ fontWeight: 800 }} className="grow">{i + 1}. {q.prompt}</span><span className="pill">+{q.points}</span></div>
            <div className="grid g2" style={{ gap: 10 }}>
              {q.options.map((o) => {
                const on = picks[q.id] === o;
                let cls = on ? 'choice on' : 'choice';
                if (rev) cls = o === rev.answer ? 'choice right' : on ? 'choice wrong' : 'choice';
                return (
                  <button key={o} className={cls} disabled={!signedIn || locked || done || busy} aria-pressed={on}
                    onClick={() => setPicks((p) => ({ ...p, [q.id]: o }))}>{o}</button>
                );
              })}
            </div>
            {rev && <div className={`alert ${picks[q.id] === rev.answer ? 'ok' : 'info'}`}>{picks[q.id] === rev.answer ? 'Correct! ' : `Answer: ${rev.answer}. `}{rev.explain || ''}</div>}
            {instant && !done && signedIn && !locked && (
              <button className="btn" disabled={!picks[q.id] || busy} onClick={() => submit(q.id)}>Lock in answer</button>
            )}
          </section>
        );
      })}
      {!instant && signedIn && !locked && (
        <div className="row wrap-row">
          <button className="btn" disabled={!answeredAll || busy} onClick={() => submit()}>{Object.keys(mine).length ? 'Update my picks' : 'Lock my picks'}</button>
          <span className="small muted">{Object.keys(picks).length} of {questions.length} picked</span>
        </div>
      )}
      {msg && <div className={`alert ${msg.kind}`} role="status">{msg.text}</div>}
    </div>
  );
}
