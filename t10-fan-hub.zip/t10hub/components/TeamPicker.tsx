'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function TeamPicker({ teamId, label, changing }: { teamId: string; label: string; changing?: boolean }) {
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  async function pick() {
    if (changing && !confirm('You can switch teams only once per season. Points you already earned stay with your old team. Continue?')) return;
    setBusy(true); setErr('');
    const r = await fetch('/api/me/team', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ teamId }) });
    const d = await r.json();
    setBusy(false);
    if (!r.ok) return setErr(d.error);
    router.refresh();
  }
  return (
    <div className="stack" style={{ gap: 6 }}>
      <button className="btn" onClick={pick} disabled={busy}>{label}</button>
      {err && <span className="xs" style={{ color: '#FFB29E' }}>{err}</span>}
    </div>
  );
}
