'use client';
import { useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

type P = { id: string; team_id: string; name: string; credits: number; is_icon: boolean };

export default function FantasyBuilder({ matchId, teams, players, initial, open, signedIn, rules }:
  { matchId: string; teams: { id: string; name: string; color: string }[]; players: P[]; initial: { players: string[]; captain: string } | null; open: boolean; signedIn: boolean; rules: { size: number; budget: number; maxPerTeam: number } }) {
  const [sel, setSel] = useState<string[]>(initial?.players || []);
  const [cap, setCap] = useState<string>(initial?.captain || '');
  const [msg, setMsg] = useState<{ kind: string; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const byId = useMemo(() => Object.fromEntries(players.map((p) => [p.id, p])), [players]);
  const spent = sel.reduce((t, id) => t + (byId[id]?.credits || 0), 0);
  const count = (tid: string) => sel.filter((id) => byId[id]?.team_id === tid).length;

  function toggle(p: P) {
    setMsg(null);
    if (sel.includes(p.id)) { setSel(sel.filter((x) => x !== p.id)); if (cap === p.id) setCap(''); return; }
    if (sel.length >= rules.size) return setMsg({ kind: 'err', text: `You already have ${rules.size} players.` });
    if (spent + p.credits > rules.budget) return setMsg({ kind: 'err', text: 'That takes you over budget.' });
    if (count(p.team_id) >= rules.maxPerTeam) return setMsg({ kind: 'err', text: `Max ${rules.maxPerTeam} from one team.` });
    setSel([...sel, p.id]);
  }
  async function save() {
    setBusy(true);
    const r = await fetch(`/api/fantasy/${matchId}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ players: sel, captain: cap }) });
    const d = await r.json();
    setBusy(false);
    setMsg(r.ok ? { kind: 'ok', text: 'Team saved. You can edit it until the first ball.' } : { kind: 'err', text: d.error });
    if (r.ok) router.refresh();
  }
  const ready = sel.length === rules.size && cap && spent <= rules.budget;

  return (
    <div className="grid g3">
      <div className="span2 grid g2">
        {teams.map((t) => (
          <section key={t.id} className="card stack">
            <div className="row"><span className="dot" style={{ background: t.color }} /><h2 className="grow">{t.name}</h2><span className="pill">{count(t.id)}/{rules.maxPerTeam}</span></div>
            {players.filter((p) => p.team_id === t.id).map((p) => {
              const on = sel.includes(p.id);
              return (
                <button key={p.id} className={on ? 'choice on' : 'choice'} disabled={!open || !signedIn} onClick={() => toggle(p)} aria-pressed={on}
                  style={{ display: 'flex', alignItems: 'center', gap: 10, minHeight: 46 }}>
                  <span className="grow">{p.name}{p.is_icon ? ' ★' : ''}</span><span className="xs" style={{ opacity: .8 }}>{p.credits} cr</span>
                </button>
              );
            })}
            {players.filter((p) => p.team_id === t.id).length === 0 && <div className="small muted">Squad to be announced.</div>}
          </section>
        ))}
      </div>
      <aside className="card stack" style={{ alignSelf: 'start', position: 'sticky', top: 90 }}>
        <h2>Your Fantasy 10</h2>
        <div className="row small"><span className="grow">Players</span><b>{sel.length}/{rules.size}</b></div>
        <div className="row small"><span className="grow">Credits</span><b style={{ color: spent > rules.budget ? 'var(--live)' : undefined }}>{spent.toFixed(1)}/{rules.budget}</b></div>
        <div className="probbar"><div style={{ width: `${Math.min(100, (spent / rules.budget) * 100)}%`, background: 'var(--lime)' }} /></div>
        {sel.length ? <div className="stack" style={{ gap: 8 }}>
          <div className="xs muted">Tap C to choose your captain (2x points)</div>
          {sel.map((id) => (
            <div key={id} className="row tile" style={{ padding: '8px 10px' }}>
              <span className="grow small" style={{ fontWeight: 700 }}>{byId[id]?.name}</span>
              <button className={cap === id ? 'btn small' : 'btn ghost small'} style={{ minHeight: 34, padding: '0 10px' }} onClick={() => setCap(id)} disabled={!open} aria-label={`Make ${byId[id]?.name} captain`} aria-pressed={cap === id}>C</button>
            </div>
          ))}
        </div> : <div className="small muted">Tap players to add them.</div>}
        {signedIn ? (
          <button className="btn full" disabled={!ready || busy || !open} onClick={save}>{initial ? 'Update team' : 'Save team'}</button>
        ) : (
          <Link href={`/login?next=/fantasy/${matchId}`} className="btn full">Sign in to build a team</Link>
        )}
        {msg && <div className={`alert ${msg.kind}`} role="status">{msg.text}</div>}
      </aside>
    </div>
  );
}
