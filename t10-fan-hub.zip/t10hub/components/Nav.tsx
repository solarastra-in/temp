'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const LINKS = [
  ['/', 'Home'], ['/matches', 'Matches'], ['/play', 'Play'], ['/draws', 'Draws'], ['/leaderboard', 'Leaderboard'],
  ['/teams', 'Teams'], ['/social', 'Social Hub'], ['/news', 'News'],
] as const;

export default function Nav({ admin }: { admin: boolean }) {
  const path = usePathname();
  const links = admin ? [...LINKS, ['/admin', 'Admin'] as const] : LINKS;
  return (
    <nav className="nav" aria-label="Main">
      {links.map(([href, label]) => {
        const on = href === '/' ? path === '/' : path.startsWith(href);
        return <Link key={href} href={href} className={on ? 'on' : ''} aria-current={on ? 'page' : undefined}>{label}</Link>;
      })}
    </nav>
  );
}
