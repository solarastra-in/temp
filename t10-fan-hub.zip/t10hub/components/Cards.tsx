import Link from 'next/link';
import { when, ago, until, TYPE_LABEL } from '@/lib/format';

export function TeamBadge({ t, size }: { t: { short: string; color: string }; size?: 'lg' }) {
  return <span className={`badge ${size || ''}`} style={{ background: t.color }}>{t.short}</span>;
}

export function MatchCard({ m }: { m: any }) {
  const live = m.status === 'live';
  const done = m.status === 'completed';
  return (
    <Link href={`/matches/${m.id}`} className="card tight stack" style={{ color: 'inherit', textDecoration: 'none' }}>
      <div className="row xs muted">
        {live ? <span className="pill live">LIVE</span> : done ? <span className="pill">Result</span> : <span className="pill">{until(m.starts_at)}</span>}
        <span>{m.stage}{m.match_no ? ` · Match ${m.match_no}` : ''}</span>
        {m.is_demo && <span className="pill dash">demo</span>}
      </div>
      {[['a', m.team_a], ['b', m.team_b]].map(([k, tid]) => (
        <div key={k} className="row">
          <span className="dot" style={{ background: m[`${k}_color`] }} />
          <span className="grow" style={{ fontWeight: m.winner === tid ? 800 : 600 }}>{m[`${k}_name`]}</span>
          <span style={{ fontWeight: 800 }}>{m[`score_${k}`] || ''}</span>
        </div>
      ))}
      <div className="xs muted">{done ? m.result || '' : when(m.starts_at)}</div>
    </Link>
  );
}

export function FeedCard({ f }: { f: any }) {
  const internal = f.url.startsWith('/');
  const inner = (
    <>
      <div className="row">
        {f.team_color ? <span className="dot" style={{ background: f.team_color }} /> : null}
        <span className="xs muted grow">{f.team_name || f.source || 'League'} · {ago(f.published_at)}</span>
        <span className="pill">{f.kind === 'news' ? 'News' : f.platform}</span>
      </div>
      {f.image ? <img className="feed-img" src={f.image} alt="" loading="lazy" /> : null}
      <div style={{ fontWeight: 700, lineHeight: 1.4 }} className="clamp3">{f.title}</div>
      {f.summary ? <div className="small soft clamp3">{f.summary}</div> : null}
      <div className="xs" style={{ color: 'var(--lime)', fontWeight: 700 }}>{internal ? 'Read on the hub' : `Open on ${f.kind === 'news' ? f.source : f.platform}`} &rarr;</div>
    </>
  );
  return internal ? (
    <Link href={f.url} className="card tight stack" style={{ color: 'inherit', textDecoration: 'none' }}>{inner}</Link>
  ) : (
    <a href={f.url} target="_blank" rel="noopener noreferrer" className="card tight stack" style={{ color: 'inherit', textDecoration: 'none' }}>{inner}</a>
  );
}

export function ContestCard({ c }: { c: any }) {
  const locked = c.status !== 'open' || (c.locks_at && new Date(c.locks_at) < new Date());
  return (
    <Link href={`/play/${c.id}`} className="card tight stack" style={{ color: 'inherit', textDecoration: 'none' }}>
      <div className="row">
        <span className="pill lime">{TYPE_LABEL[c.type] || c.type}</span>
        <span className="grow" />
        {c.status === 'settled' ? <span className="pill good">Settled</span> : locked ? <span className="pill">Locked</span> : c.locks_at ? <span className="pill">Locks {until(c.locks_at)}</span> : <span className="pill">Open</span>}
      </div>
      <div style={{ fontWeight: 800, fontSize: 17 }}>{c.title}</div>
      <div className="small soft clamp2">{c.description}</div>
      <div className="row wrap-row xs muted" style={{ gap: 6, whiteSpace: 'nowrap' }}><span>{c.qcount} question{c.qcount === 1 ? '' : 's'}</span><span>·</span><span>{c.players} playing</span>{c.prize ? <><span>·</span><span>{c.prize}</span></> : null}</div>
    </Link>
  );
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="card" style={{ textAlign: 'center', borderStyle: 'dashed', color: 'var(--muted)' }}>{children}</div>;
}
