'use client';
// Embeds the published Curator.io wall. Curator's script renders into the container div.
import { useEffect } from 'react';

export default function CuratorWall({ feedId, containerId }: { feedId: string; containerId: string }) {
  useEffect(() => {
    const src = `https://cdn.curator.io/published/${feedId}.js`;
    if (document.querySelector(`script[src="${src}"]`)) return;
    const s = document.createElement('script');
    s.async = true;
    s.charset = 'UTF-8';
    s.src = src;
    document.body.appendChild(s);
  }, [feedId]);
  return (
    <div className="curator-wrap">
      <div id={containerId}>
        <a href="https://curator.io" target="_blank" rel="noopener noreferrer" className="crt-logo crt-tag">Powered by Curator.io</a>
      </div>
    </div>
  );
}
