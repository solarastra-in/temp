'use client';
import { useState } from 'react';

export default function LoginForm({ next, google }: { next: string; google: boolean }) {
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [step, setStep] = useState<'email' | 'code'>('email');
  const [msg, setMsg] = useState<{ kind: 'err' | 'info' | 'ok'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function requestCode(e?: React.FormEvent) {
    e?.preventDefault();
    setBusy(true); setMsg(null);
    const r = await fetch('/api/auth/otp/request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email }) });
    const d = await r.json();
    setBusy(false);
    if (!r.ok) return setMsg({ kind: 'err', text: d.error });
    setStep('code');
    setMsg({ kind: 'info', text: d.devCode ? `Development mode: your code is ${d.devCode}` : `We sent a 6-digit code to ${email}.` });
  }
  async function verify(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setMsg(null);
    const r = await fetch('/api/auth/otp/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, code }) });
    const d = await r.json();
    setBusy(false);
    if (!r.ok) return setMsg({ kind: 'err', text: d.error });
    window.location.href = next;
  }

  return (
    <div className="stack">
      <a className="btn google full" href={google ? `/api/auth/google/start?next=${encodeURIComponent(next)}` : '/login?error=google_not_configured'} aria-disabled={!google}>
        <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>
        Continue with Google
      </a>
      <div className="row xs muted"><span className="grow" style={{ height: 1, background: 'var(--line)' }} />or use your email<span className="grow" style={{ height: 1, background: 'var(--line)' }} /></div>
      {step === 'email' ? (
        <form onSubmit={requestCode} className="stack">
          <label className="lab">Email address
            <input className="field" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
          </label>
          <button className="btn full" disabled={busy || !email}>{busy ? 'Sending…' : 'Email me a code'}</button>
        </form>
      ) : (
        <form onSubmit={verify} className="stack">
          <label className="lab">6-digit code sent to {email}
            <input className="field otp" inputMode="numeric" autoComplete="one-time-code" maxLength={6} pattern="\d{6}" required value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} autoFocus />
          </label>
          <button className="btn full" disabled={busy || code.length !== 6}>{busy ? 'Checking…' : 'Verify and sign in'}</button>
          <div className="row small">
            <button type="button" className="btn ghost small" onClick={() => { setStep('email'); setCode(''); setMsg(null); }}>Change email</button>
            <button type="button" className="btn ghost small" onClick={() => requestCode()} disabled={busy}>Resend code</button>
          </div>
        </form>
      )}
      {msg && <div className={`alert ${msg.kind}`} role="status">{msg.text}</div>}
    </div>
  );
}
