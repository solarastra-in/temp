'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function DrawEnter({ id, entered }: { id: string; entered: boolean }) {
  const [done, setDone] = useState(entered);
  const [err, setErr] = useState('');
  const router = useRouter();
  async function go() {
    const r = await fetch(`/api/draws/${id}/enter`, { method: 'POST' });
    const d = await r.json();
    if (!r.ok) return setErr(d.error);
    setDone(true); router.refresh();
  }
  return (
    <div className="stack" style={{ gap: 6 }}>
      <button className={done ? 'btn ghost full' : 'btn full'} disabled={done} onClick={go}>{done ? 'You’re in ✓' : 'Enter free'}</button>
      {err && <span className="xs" style={{ color: '#FFB29E' }}>{err}</span>}
    </div>
  );
}
