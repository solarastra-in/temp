'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

function useAction() {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ kind: string; text: string } | null>(null);
  const router = useRouter();
  async function call(url: string, body?: any, okText = 'Done') {
    setBusy(true); setMsg(null);
    try {
      const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
      const d = await r.json();
      if (!r.ok) setMsg({ kind: 'err', text: d.error || 'Failed' });
      else setMsg({ kind: 'ok', text: d.summary || okText });
      router.refresh();
      return d;
    } finally { setBusy(false); }
  }
  const note = msg ? <div className={`alert ${msg.kind}`} style={{ fontSize: 12, padding: '8px 10px' }} role="status">{msg.text}</div> : null;
  return { busy, call, note };
}

export function AgentButton({ name, label, primary }: { name: string; label: string; primary?: boolean }) {
  const { busy, call, note } = useAction();
  return <div className="stack" style={{ gap: 6 }}><button className={primary ? 'btn' : 'btn ghost small'} disabled={busy} onClick={() => call(`/api/admin/agents/${name}`, {}, 'Finished')}>{busy ? 'Running…' : label}</button>{note}</div>;
}

export function ApprovalButtons({ id }: { id: string }) {
  const { busy, call } = useAction();
  return (
    <div className="row">
      <button className="btn ghost small" disabled={busy} onClick={() => call(`/api/admin/approvals/${id}`, { decision: 'reject' })}>Reject</button>
      <button className="btn small" disabled={busy} onClick={() => call(`/api/admin/approvals/${id}`, { decision: 'approve' })}>Approve</button>
    </div>
  );
}

export function MatchForm({ teams }: { teams: any[] }) {
  const { busy, call, note } = useAction();
  const [f, setF] = useState({ team_a: '', team_b: '', starts_at: '', match_no: '', stage: 'League' });
  return (
    <form className="stack" onSubmit={(e) => { e.preventDefault(); call('/api/admin/matches', { ...f, match_no: f.match_no ? Number(f.match_no) : null, starts_at: f.starts_at ? new Date(f.starts_at).toISOString() : '' }, 'Fixture added with its contests'); }}>
      <div className="grid g2" style={{ gap: 10 }}>
        <label className="lab">Team A<select className="field" value={f.team_a} onChange={(e) => setF({ ...f, team_a: e.target.value })} required><option value="">Select</option>{teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></label>
        <label className="lab">Team B<select className="field" value={f.team_b} onChange={(e) => setF({ ...f, team_b: e.target.value })} required><option value="">Select</option>{teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></label>
        <label className="lab">Start (your local time)<input className="field" type="datetime-local" value={f.starts_at} onChange={(e) => setF({ ...f, starts_at: e.target.value })} required /></label>
        <label className="lab">Match no.<input className="field" type="number" value={f.match_no} onChange={(e) => setF({ ...f, match_no: e.target.value })} /></label>
      </div>
      <button className="btn" disabled={busy}>Add fixture</button>{note}
    </form>
  );
}

export function ResultForm({ m }: { m: any }) {
  const { busy, call, note } = useAction();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ winner: '', score_a: '', score_b: '', first_innings: '', top_scorer: '', total_sixes: '', result: '' });
  if (!open) return (
    <div className="row"><button className="btn ghost small" onClick={() => setOpen(true)}>Enter result</button>
      <button className="btn ghost small" disabled={busy} title="Random stats, for testing" onClick={() => call(`/api/admin/matches/${m.id}/result`, { simulate: true }, 'Simulated and settled')}>Simulate</button>{note}</div>
  );
  return (
    <form className="stack" style={{ minWidth: 320 }} onSubmit={(e) => { e.preventDefault(); call(`/api/admin/matches/${m.id}/result`, { ...f, first_innings: f.first_innings ? Number(f.first_innings) : null, total_sixes: f.total_sixes ? Number(f.total_sixes) : null }, 'Result saved and contests settled'); }}>
      <select className="field" required value={f.winner} onChange={(e) => setF({ ...f, winner: e.target.value })}><option value="">Winner</option><option value={m.team_a}>{m.a_name}</option><option value={m.team_b}>{m.b_name}</option></select>
      <div className="grid g2" style={{ gap: 8 }}>
        <input className="field" placeholder={`${m.a_short} score e.g. 132/4 (10)`} value={f.score_a} onChange={(e) => setF({ ...f, score_a: e.target.value })} />
        <input className="field" placeholder={`${m.b_short} score`} value={f.score_b} onChange={(e) => setF({ ...f, score_b: e.target.value })} />
        <input className="field" type="number" placeholder="1st-innings runs" value={f.first_innings} onChange={(e) => setF({ ...f, first_innings: e.target.value })} />
        <input className="field" type="number" placeholder="Total sixes" value={f.total_sixes} onChange={(e) => setF({ ...f, total_sixes: e.target.value })} />
      </div>
      <input className="field" placeholder="Top run-scorer (exact name)" value={f.top_scorer} onChange={(e) => setF({ ...f, top_scorer: e.target.value })} />
      <input className="field" placeholder="Result line, e.g. Won by 6 wickets" value={f.result} onChange={(e) => setF({ ...f, result: e.target.value })} />
      <div className="row"><button className="btn small" disabled={busy}>Save &amp; settle</button><button type="button" className="btn ghost small" onClick={() => setOpen(false)}>Cancel</button></div>{note}
    </form>
  );
}

export function DrawForm({ teams }: { teams: any[] }) {
  const { busy, call, note } = useAction();
  const [f, setF] = useState({ title: '', prize: '', rule: '', closes_at: '', color: '#D8F24A', team_only: '' });
  return (
    <form className="stack" onSubmit={(e) => { e.preventDefault(); call('/api/admin/draws', { ...f, closes_at: f.closes_at ? new Date(f.closes_at).toISOString() : '' }, 'Draw created'); }}>
      <label className="lab">Title<input className="field" required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="Signed match ball" /></label>
      <div className="grid g2" style={{ gap: 10 }}>
        <label className="lab">Prize label<input className="field" required value={f.prize} onChange={(e) => setF({ ...f, prize: e.target.value })} placeholder="SIGNED BALL" /></label>
        <label className="lab">Closes<input className="field" type="datetime-local" required value={f.closes_at} onChange={(e) => setF({ ...f, closes_at: e.target.value })} /></label>
        <label className="lab">Colour<input className="field" type="color" value={f.color} onChange={(e) => setF({ ...f, color: e.target.value })} /></label>
        <label className="lab">Restrict to fans of<select className="field" value={f.team_only} onChange={(e) => setF({ ...f, team_only: e.target.value })}><option value="">Everyone</option>{teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></label>
      </div>
      <label className="lab">Rules<input className="field" value={f.rule} onChange={(e) => setF({ ...f, rule: e.target.value })} placeholder="One free entry per fan." /></label>
      <button className="btn" disabled={busy}>Create draw</button>{note}
    </form>
  );
}

export function RunDraw({ id }: { id: string }) {
  const { busy, call, note } = useAction();
  return <div className="stack" style={{ gap: 4 }}><button className="btn small" disabled={busy} onClick={() => confirm('Draw a winner now? This cannot be undone.') && call(`/api/admin/draws/${id}/run`, {}, 'Winner drawn')}>Draw winner</button>{note}</div>;
}

export function HandleForm({ teams }: { teams: any[] }) {
  const { busy, call, note } = useAction();
  const [f, setF] = useState({ team_id: '', url: '', platform: '' });
  return (
    <form className="stack" onSubmit={(e) => { e.preventDefault(); call('/api/admin/handles', f, 'Handle added'); }}>
      <select className="field" value={f.team_id} onChange={(e) => setF({ ...f, team_id: e.target.value })}><option value="">League account</option>{teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select>
      <input className="field" required value={f.url} onChange={(e) => setF({ ...f, url: e.target.value })} placeholder="https://www.instagram.com/…" />
      <label className="row small"><input type="checkbox" checked={f.platform === 'RSS'} onChange={(e) => setF({ ...f, platform: e.target.checked ? 'RSS' : '' })} /> This is an RSS feed (team blog or news)</label>
      <button className="btn" disabled={busy}>Add handle</button>{note}
    </form>
  );
}

export function DemoButtons() {
  const { busy, call, note } = useAction();
  return <div className="stack"><div className="row"><button className="btn" disabled={busy} onClick={() => call('/api/admin/demo', {}, 'Demo data added')}>Add demo data</button><button className="btn ghost" disabled={busy} onClick={() => call('/api/admin/demo', { clear: true }, 'Demo data removed')}>Remove demo data</button></div>{note}</div>;
}
