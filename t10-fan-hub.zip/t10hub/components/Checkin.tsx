'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function Checkin() {
  const [state, setState] = useState<{ streak?: number; busy?: boolean }>({});
  const router = useRouter();
  async function go() {
    setState({ busy: true });
    const r = await fetch('/api/checkin', { method: 'POST' }).then((r) => r.json());
    setState({ streak: r.streak });
    router.refresh();
  }
  if (state.streak) return <div className="alert ok">Checked in. {state.streak}-day streak. Hit 7 days for a 20-point bonus.</div>;
  return <button className="btn ghost full" onClick={go} disabled={state.busy}>Daily check-in (+2 pts)</button>;
}
