// Content agent: keeps every competition stocked and writes match previews.
// - Creates the standard contests for every upcoming fixture.
// - Locks contests at start time.
// - Writes a preview for each match in the next 72h (Claude if configured, else a factual template).
//   Claude-written copy goes to the approval queue unless AUTO_PUBLISH_STORIES=true.
import { q, one, id } from '../db';
import { ensureMatchContests } from '../game';
import { askClaude, claudeConfigured } from './claude';
import { AgentResult, hashId } from './util';

export async function contentAgent(): Promise<AgentResult> {
  let made = 0, stories = 0;
  const upcoming = await q<any>(`SELECT id FROM matches WHERE status = 'upcoming'`);
  for (const m of upcoming) made += await ensureMatchContests(m.id);
  const locked = await q(`UPDATE contests SET status = 'locked' WHERE status = 'open' AND locks_at IS NOT NULL AND locks_at <= now() RETURNING id`);

  // Season Oracle locks when the first match starts.
  const first = await one<any>(`SELECT min(starts_at) AS s FROM matches WHERE is_demo = false`);
  if (first?.s) await q(`UPDATE contests SET locks_at = $1 WHERE id = 'season-2026' AND locks_at IS NULL`, [first.s]);

  const soon = await q<any>(
    `SELECT m.*, a.name AS a_name, a.icon_player AS a_icon, b.name AS b_name, b.icon_player AS b_icon
     FROM matches m JOIN teams a ON a.id = m.team_a JOIN teams b ON b.id = m.team_b
     WHERE m.status = 'upcoming' AND m.starts_at < now() + interval '72 hours'`
  );
  for (const m of soon) {
    const url = `/matches/${m.id}#preview`;
    if (await one(`SELECT 1 FROM feed_items WHERE id = $1`, [hashId(url)])) continue;
    const form = async (t: string) => {
      const r = await q<any>(`SELECT winner FROM matches WHERE status = 'completed' AND (team_a = $1 OR team_b = $1) ORDER BY starts_at DESC LIMIT 5`, [t]);
      return r.map((x) => (x.winner === t ? 'W' : x.winner ? 'L' : '-')).join('') || 'no games yet';
    };
    const fa = await form(m.team_a), fb = await form(m.team_b);
    let title = `Preview: ${m.a_name} vs ${m.b_name}`;
    let summary = `${m.a_name} (form ${fa}), led by ${m.a_icon}, meet ${m.b_name} (form ${fb}), led by ${m.b_icon}. Predictor, Six Machine and Fantasy 10 are open until the first ball.`;
    let status = 'live';
    if (claudeConfigured()) {
      try {
        const text = await askClaude(
          `Write a punchy 2-sentence match preview (max 55 words) for fans of the Abu Dhabi T10 cricket league. Facts you may use, and nothing else: ` +
          `${m.a_name} (icon player ${m.a_icon}, last results ${fa}) vs ${m.b_name} (icon player ${m.b_icon}, last results ${fb}), ${m.venue}. Do not invent stats. End by inviting fans to play the Match Predictor.`,
          { maxTokens: 200 }
        );
        if (text.trim()) { summary = text.trim().slice(0, 400); status = process.env.AUTO_PUBLISH_STORIES === 'true' ? 'live' : 'pending'; }
      } catch { /* fall back to template */ }
    }
    await q(`INSERT INTO feed_items (id, platform, kind, category, title, url, source, summary, status, published_at) VALUES ($1,'Hub','story','hub',$2,$3,'Content agent',$4,$5,now()) ON CONFLICT (id) DO NOTHING`,
      [hashId(url), title, url, summary, status]);
    if (status === 'pending') {
      await q(`INSERT INTO approvals (id, kind, title, detail, payload, dedupe) VALUES ($1,'story',$2,$3,$4::jsonb,$5) ON CONFLICT (dedupe) DO NOTHING`,
        [id('ap_'), title, summary, JSON.stringify({ feedId: hashId(url) }), `story:${m.id}`]);
    }
    stories++;
  }
  return { items: made + stories, summary: `${made} contests created, ${locked.length} locked, ${stories} previews written.` };
}
