// Ops agent: watches the other agents and the handle list, and emails the admins a digest
// when something needs a human (errors, stale handles, pending approvals). At most every 12h.
import { q, one } from '../db';
import { sendEmail } from '../email';
import { appUrl } from '../auth';
import { AgentResult } from './util';

export async function opsAgent(): Promise<AgentResult> {
  const errors = await q<any>(`SELECT agent, count(*)::int AS n, max(summary) AS last FROM agent_runs WHERE status IN ('error','warn') AND started_at > now() - interval '24 hours' GROUP BY agent`);
  const stuck = await q(`UPDATE agent_runs SET status = 'error', summary = 'Timed out', finished_at = now() WHERE status = 'running' AND started_at < now() - interval '30 minutes' RETURNING id`);
  const broken = await q<any>(`SELECT platform, handle FROM handles WHERE status = 'verified' AND (meta->>'lastErrorAt')::timestamptz > now() - interval '48 hours'`);
  const pending = await one<{ n: number }>(`SELECT count(*)::int AS n FROM approvals WHERE status = 'pending'`);
  const issues = errors.length + broken.length + (pending?.n ? 1 : 0);
  const admins = (process.env.ADMIN_EMAILS || '').split(',').map((s) => s.trim()).filter(Boolean);
  let emailed = false;
  if (issues && admins.length) {
    const last = await one<any>(`SELECT v FROM kv WHERE k = 'ops:lastDigest'`);
    if (!last || Date.now() - new Date(last.v).getTime() > 12 * 3600_000) {
      const lines = [
        ...errors.map((e) => `Agent "${e.agent}" failed ${e.n}x in 24h. Last: ${e.last}`),
        ...broken.map((b) => `Handle not reachable: ${b.platform} ${b.handle}`),
        pending?.n ? `${pending.n} item(s) waiting for your approval` : '',
      ].filter(Boolean);
      await sendEmail(admins, `T10 Fan Hub: ${lines.length} item(s) need attention`, `<p>${lines.join('<br>')}</p><p><a href="${appUrl()}/admin">Open the admin console</a></p>`, lines.join('\n'));
      await q(`INSERT INTO kv (k, v) VALUES ('ops:lastDigest', to_jsonb(now()::text)) ON CONFLICT (k) DO UPDATE SET v = EXCLUDED.v`);
      emailed = true;
    }
  }
  return { items: issues, summary: `${errors.length} failing agent(s), ${broken.length} unreachable handle(s), ${pending?.n ?? 0} pending approval(s), ${stuck.length} stuck run(s) cleared.${emailed ? ' Digest emailed.' : ''}` };
}
