// Social agent: pulls the latest post links from every verified team and league handle.
// - YouTube: public channel RSS (no key needed).
// - X: API v2 user timeline when X_BEARER_TOKEN is set.
// - Instagram: Graph API business discovery when IG_ACCESS_TOKEN + IG_BUSINESS_ID are set.
// - Any handle with platform "RSS" (a team blog, news feed) is read as a feed.
// Without API access for a platform, the hub still shows the verified profile link.
import { q } from '../db';
import { fetchText, parseFeed, hashId, AgentResult } from './util';
import { curatorConfigured, syncCuratorSources, syncCuratorPosts } from '../curator';

async function upsertItem(it: { team_id: string | null; platform: string; kind: string; title: string; url: string; image?: string | null; source?: string; summary?: string; published?: string }) {
  const pub = it.published && !isNaN(Date.parse(it.published)) ? new Date(it.published).toISOString() : new Date().toISOString();
  const r = await q(
    `INSERT INTO feed_items (id, team_id, platform, kind, category, title, url, image, source, summary, published_at)
     VALUES ($1,$2,$3,$4,'social',$5,$6,$7,$8,$9,$10) ON CONFLICT (id) DO NOTHING RETURNING id`,
    [hashId(it.url), it.team_id, it.platform, it.kind, it.title.slice(0, 300), it.url, it.image ?? null, it.source ?? null, (it.summary ?? '').slice(0, 280), pub]
  );
  return r.length;
}

async function youtubeChannelId(h: any): Promise<string | null> {
  if (h.meta?.channelId) return h.meta.channelId;
  const m0 = h.url.match(/channel\/(UC[\w-]{22})/);
  let cid = m0?.[1] || null;
  if (!cid) {
    const html = await fetchText(h.url);
    cid = html.match(/"channelId":"(UC[\w-]{22})"/)?.[1] || html.match(/channel\/(UC[\w-]{22})/)?.[1] || null;
  }
  if (cid) await q(`UPDATE handles SET meta = meta || $2::jsonb WHERE id = $1`, [h.id, JSON.stringify({ channelId: cid })]);
  return cid;
}

export async function socialAgent(): Promise<AgentResult> {
  const handles = await q<any>(`SELECT * FROM handles WHERE status = 'verified'`);
  let added = 0;
  const notes: string[] = [];
  let curatorNote = '';
  if (curatorConfigured()) {
    try {
      const s = await syncCuratorSources();
      const p = await syncCuratorPosts();
      added += p.added;
      curatorNote = ` Curator: ${s.added} source(s) registered, ${p.added} new post(s).${s.notes.length ? ' ' + s.notes.slice(0, 3).join('; ') + '.' : ''}`;
    } catch (e: any) {
      notes.push(`Curator: ${e.message}`);
    }
  }
  for (const h of handles) {
    try {
      if (h.platform === 'YouTube') {
        const cid = await youtubeChannelId(h);
        if (!cid) { notes.push(`${h.handle}: no channel id`); continue; }
        const items = parseFeed(await fetchText(`https://www.youtube.com/feeds/videos.xml?channel_id=${cid}`)).slice(0, 8);
        for (const it of items) {
          const vid = it.link.match(/v=([\w-]{11})/)?.[1];
          added += await upsertItem({ team_id: h.team_id, platform: 'YouTube', kind: 'video', title: it.title, url: it.link, image: it.image || (vid ? `https://i.ytimg.com/vi/${vid}/hqdefault.jpg` : null), source: h.handle, summary: it.summary, published: it.published });
        }
      } else if (h.platform === 'X' && process.env.X_BEARER_TOKEN) {
        const auth = { Authorization: `Bearer ${process.env.X_BEARER_TOKEN}` };
        const uname = h.handle.replace('@', '');
        let uid = h.meta?.xUserId;
        if (!uid) {
          const u = JSON.parse(await fetchText(`https://api.x.com/2/users/by/username/${uname}`, 12000, auth));
          uid = u.data?.id;
          if (uid) await q(`UPDATE handles SET meta = meta || $2::jsonb WHERE id = $1`, [h.id, JSON.stringify({ xUserId: uid })]);
        }
        if (!uid) continue;
        const tl = JSON.parse(await fetchText(`https://api.x.com/2/users/${uid}/tweets?max_results=5&exclude=replies&tweet.fields=created_at`, 12000, auth));
        for (const t of tl.data || []) {
          added += await upsertItem({ team_id: h.team_id, platform: 'X', kind: 'post', title: t.text, url: `https://x.com/${uname}/status/${t.id}`, source: h.handle, published: t.created_at });
        }
      } else if (h.platform === 'Instagram' && process.env.IG_ACCESS_TOKEN && process.env.IG_BUSINESS_ID) {
        const uname = h.handle.replace('@', '');
        const url = `https://graph.facebook.com/v21.0/${process.env.IG_BUSINESS_ID}?fields=business_discovery.username(${uname}){media.limit(6){caption,permalink,media_url,thumbnail_url,timestamp}}&access_token=${process.env.IG_ACCESS_TOKEN}`;
        const d = JSON.parse(await fetchText(url));
        for (const m of d.business_discovery?.media?.data || []) {
          added += await upsertItem({ team_id: h.team_id, platform: 'Instagram', kind: 'post', title: (m.caption || 'New post').split('\n')[0], url: m.permalink, image: m.thumbnail_url || m.media_url, source: h.handle, published: m.timestamp });
        }
      } else if (h.platform === 'RSS') {
        for (const it of parseFeed(await fetchText(h.url)).slice(0, 10)) {
          added += await upsertItem({ team_id: h.team_id, platform: 'Web', kind: 'post', title: it.title, url: it.link, image: it.image, source: h.handle, summary: it.summary, published: it.published });
        }
      }
    } catch (e: any) {
      notes.push(`${h.platform} ${h.handle}: ${e.message}`);
      await q(`UPDATE handles SET meta = meta || $2::jsonb WHERE id = $1`, [h.id, JSON.stringify({ lastError: String(e.message).slice(0, 200), lastErrorAt: new Date().toISOString() })]);
    }
  }
  const skipped = curatorConfigured() ? [] : [!process.env.X_BEARER_TOKEN && 'X (no token)', !process.env.IG_ACCESS_TOKEN && 'Instagram (no token)', 'TikTok/Facebook (add Curator)'].filter(Boolean);
  const pullable = handles.filter((h) => h.platform === 'YouTube' || h.platform === 'RSS' || (h.platform === 'X' && process.env.X_BEARER_TOKEN) || (h.platform === 'Instagram' && process.env.IG_ACCESS_TOKEN)).length + (curatorConfigured() ? 1 : 0);
  return { failed: notes.length, total: pullable, items: added, summary: `${added} new posts from ${handles.length} handles.${curatorNote}${skipped.length ? ' Link-only: ' + skipped.join(', ') + '.' : ''} ${notes.slice(0, 5).join(' · ')}` };
}
