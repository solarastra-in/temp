// Scores agent: syncs fixtures, results and scorecards from CricketData.org (CRICAPI_KEY),
// keeps squads current (new players are added automatically), creates contests for new
// fixtures and settles contests when a match ends.
import { q, one, id } from '../db';
import { fetchText, AgentResult } from './util';
import { ensureMatchContests, settleMatch } from '../game';
import { slug } from '../seed';

const API = 'https://api.cricapi.com/v1';
const norm = (s: string) => s.toLowerCase().replace(/[^a-z]/g, '');

async function api(path: string, params: Record<string, string>) {
  const p = new URLSearchParams({ apikey: process.env.CRICAPI_KEY!, ...params });
  const d = JSON.parse(await fetchText(`${API}/${path}?${p}`));
  if (d.status && d.status !== 'success') throw new Error(`CricketData ${path}: ${d.reason || d.status}`);
  return d.data;
}

function matchTeam(name: string, teams: any[]) {
  const n = norm(name);
  return teams.find((t) => norm(t.name) === n) || teams.find((t) => n.includes(norm(t.name)) || norm(t.name).includes(n)) ||
    teams.find((t) => t.name.split(' ').some((w: string) => w.length > 4 && n.includes(norm(w))));
}

async function playerId(teamId: string, name: string) {
  const all = await q<any>(`SELECT id, name FROM players WHERE team_id = $1`, [teamId]);
  const n = norm(name);
  const hit = all.find((p) => norm(p.name) === n) || all.find((p) => { const last = norm(p.name.split(' ').pop()); return last.length > 3 && n.endsWith(last) && n[0] === norm(p.name)[0]; });
  if (hit) return hit.id;
  const pid = `${teamId}-${slug(name)}`;
  await q(`INSERT INTO players (id, team_id, name, credits) VALUES ($1,$2,$3,8) ON CONFLICT (id) DO NOTHING`, [pid, teamId, name]);
  return pid;
}

export async function scoresAgent(): Promise<AgentResult> {
  if (!process.env.CRICAPI_KEY) return { items: 0, summary: 'Skipped: CRICAPI_KEY not set. Fixtures and results can be entered in Admin.' };
  const teams = await q<any>(`SELECT * FROM teams`);
  let seriesId = process.env.CRICAPI_SERIES_ID || '';
  if (!seriesId) {
    const list = await api('series', { offset: '0', search: 'Abu Dhabi T10' });
    const s = (list || []).sort((a: any, b: any) => String(b.startDate).localeCompare(String(a.startDate)))[0];
    if (!s) return { items: 0, summary: 'No Abu Dhabi T10 series found in the feed yet.' };
    seriesId = s.id;
  }
  const info = await api('series_info', { id: seriesId });
  let created = 0, updated = 0, settled = 0;
  const unknown = new Set<string>();
  for (const m of info.matchList || []) {
    const [ta, tb] = (m.teams || []).map((t: string) => matchTeam(t, teams));
    if (!ta || !tb) { (m.teams || []).forEach((t: string) => !matchTeam(t, teams) && unknown.add(t)); continue; }
    const existing = await one<any>(`SELECT * FROM matches WHERE external_id = $1`, [m.id]);
    const no = Number(String(m.name).match(/(\d+)(?:st|nd|rd|th) Match/)?.[1]) || null;
    const stage = /final/i.test(m.name) ? 'Final' : /qualifier|eliminator/i.test(m.name) ? 'Playoff' : 'League';
    const status = m.matchEnded ? 'completed' : m.matchStarted ? 'live' : 'upcoming';
    const sc = (m.score || []) as any[];
    const fmt = (i: number) => (sc[i] ? `${sc[i].r}/${sc[i].w} (${sc[i].o})` : null);
    const inningTeam = (i: number) => (sc[i] ? matchTeam(String(sc[i].inning).replace(/inning.*$/i, ''), teams)?.id : null);
    const scoreA = [0, 1].map((i) => (inningTeam(i) === ta.id ? fmt(i) : null)).find(Boolean) || null;
    const scoreB = [0, 1].map((i) => (inningTeam(i) === tb.id ? fmt(i) : null)).find(Boolean) || null;
    const matchId = existing?.id || id('m_');
    if (!existing) {
      await q(`INSERT INTO matches (id, match_no, stage, team_a, team_b, starts_at, venue, status, external_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
        [matchId, no, stage, ta.id, tb.id, m.dateTimeGMT ? m.dateTimeGMT + 'Z' : m.date, m.venue || null, status, m.id]);
      created++;
    }
    await q(`UPDATE matches SET status = $2, score_a = COALESCE($3, score_a), score_b = COALESCE($4, score_b), result = $5, first_innings = COALESCE($6, first_innings), updated_at = now() WHERE id = $1`,
      [matchId, status, scoreA, scoreB, m.status || null, sc[0]?.r ?? null]);
    updated++;
    if (existing && m.dateTimeGMT && status === 'upcoming') {
      const ts = new Date(m.dateTimeGMT + 'Z').toISOString();
      await q(`UPDATE matches SET starts_at = $2 WHERE id = $1`, [matchId, ts]);
      await q(`UPDATE contests SET locks_at = $2 WHERE match_id = $1 AND status = 'open'`, [matchId, ts]);
    }
    if (status === 'upcoming') await ensureMatchContests(matchId);
    if (status === 'completed' && (!existing || existing.status !== 'completed' || !existing.winner)) {
      try {
        const card = await api('match_scorecard', { id: m.id });
        const stats: Record<string, any> = {};
        const bump = (pid: string, k: string, v: number) => { stats[pid] = stats[pid] || { runs: 0, balls: 0, fours: 0, sixes: 0, wickets: 0, catches: 0 }; stats[pid][k] += v || 0; };
        for (const inn of card.scorecard || []) {
          const bat = matchTeam(String(inn.inning).replace(/inning.*$/i, ''), teams);
          const bowlTeam = bat?.id === ta.id ? tb : ta;
          if (!bat) continue;
          for (const b of inn.batting || []) { const pid = await playerId(bat.id, b.batsman?.name || b.batsman); bump(pid, 'runs', b.r); bump(pid, 'balls', b.b); bump(pid, 'fours', b['4s']); bump(pid, 'sixes', b['6s']); }
          for (const b of inn.bowling || []) { const pid = await playerId(bowlTeam.id, b.bowler?.name || b.bowler); bump(pid, 'wickets', b.w); }
          for (const c of inn.catching || []) { if (!c.catcher?.name) continue; const pid = await playerId(bowlTeam.id, c.catcher.name); bump(pid, 'catches', c.catch); }
        }
        for (const [pid, s] of Object.entries(stats)) {
          await q(`INSERT INTO player_stats (match_id, player_id, runs, balls, fours, sixes, wickets, catches) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
            ON CONFLICT (match_id, player_id) DO UPDATE SET runs=$3, balls=$4, fours=$5, sixes=$6, wickets=$7, catches=$8`, [matchId, pid, s.runs, s.balls, s.fours, s.sixes, s.wickets, s.catches]);
        }
        const top = Object.entries(stats).sort((a, b) => b[1].runs - a[1].runs)[0];
        const topName = top ? (await one<any>(`SELECT name FROM players WHERE id = $1`, [top[0]]))?.name : null;
        const sixes = Object.values(stats).reduce((t: number, s: any) => t + s.sixes, 0);
        const winner = card.matchWinner ? matchTeam(card.matchWinner, teams)?.id : null;
        await q(`UPDATE matches SET winner = $2, top_scorer = $3, total_sixes = $4, result = COALESCE($5, result) WHERE id = $1`, [matchId, winner, topName, sixes, card.status || null]);
        const r = await settleMatch(matchId);
        settled += r.settled;
      } catch (e: any) {
        console.error(`[scores] scorecard ${m.id}: ${e.message}`);
      }
    }
  }
  for (const name of unknown) {
    await q(`INSERT INTO approvals (id, kind, title, detail, payload, dedupe) VALUES ($1,'team',$2,$3,$4::jsonb,$5) ON CONFLICT (dedupe) DO NOTHING`,
      [id('ap_'), `New team in the live feed: ${name}`, 'Approve to add it to the league with a default colour. Its squad fills in from scorecards.', JSON.stringify({ name }), `team:${norm(name)}`]);
  }
  return { items: created + settled, summary: `Series ${seriesId}: ${created} new fixtures, ${updated} updated, ${settled} questions settled.${unknown.size ? ` ${unknown.size} unknown team(s) sent for approval.` : ''}` };
}
