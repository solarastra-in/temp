// Thin client for the Claude Messages API. Agents degrade gracefully when no key is set.
export function claudeConfigured() {
  return !!process.env.ANTHROPIC_API_KEY;
}

export async function askClaude(prompt: string, opts: { webSearch?: boolean; maxTokens?: number; system?: string } = {}) {
  if (!process.env.ANTHROPIC_API_KEY) throw new Error('ANTHROPIC_API_KEY not set');
  const body: any = {
    model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5',
    max_tokens: opts.maxTokens ?? 1500,
    messages: [{ role: 'user', content: prompt }],
  };
  if (opts.system) body.system = opts.system;
  if (opts.webSearch) body.tools = [{ type: 'web_search_20250305', name: 'web_search', max_uses: 5 }];
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Claude API ${res.status}: ${(await res.text()).slice(0, 200)}`);
  const data = await res.json();
  return (data.content || []).filter((c: any) => c.type === 'text').map((c: any) => c.text).join('\n');
}

export function extractJson<T = any>(text: string): T | null {
  const m = text.match(/```json\s*([\s\S]*?)```/) || text.match(/(\[[\s\S]*\]|\{[\s\S]*\})/);
  if (!m) return null;
  try { return JSON.parse(m[1]); } catch { return null; }
}
