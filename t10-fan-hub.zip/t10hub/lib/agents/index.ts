import { runAgent } from './util';
import { discoveryAgent } from './discovery';
import { socialAgent } from './social';
import { newsAgent } from './news';
import { scoresAgent } from './scores';
import { contentAgent } from './content';
import { opsAgent } from './ops';

export const AGENTS = {
  discovery: { label: 'Discovery', job: 'Finds and verifies every team’s official social handles from team and league sites, plus web search.', fn: discoveryAgent },
  social: { label: 'Social', job: 'Pulls the latest posts and videos from every verified handle, and keeps the Curator.io wall\u2019s sources in sync.', fn: socialAgent },
  news: { label: 'News', job: 'Collects T10 and cricket headlines from the league site and news feeds.', fn: newsAgent },
  scores: { label: 'Scores', job: 'Syncs fixtures, live scores and scorecards; settles contests automatically.', fn: scoresAgent },
  content: { label: 'Content', job: 'Creates contests for every fixture, locks them on time and writes previews.', fn: contentAgent },
  ops: { label: 'Ops', job: 'Watches the other agents and emails you only when something needs a human.', fn: opsAgent },
} as const;

export type AgentName = keyof typeof AGENTS;

export async function runNamed(name: AgentName) {
  return runAgent(name, AGENTS[name].fn);
}

export async function runAll() {
  const out: Record<string, any> = {};
  for (const n of ['discovery', 'scores', 'content', 'social', 'news', 'ops'] as AgentName[]) out[n] = await runNamed(n);
  return out;
}
