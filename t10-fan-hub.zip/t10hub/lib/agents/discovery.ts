// Discovery agent: finds official social handles for the league and every team.
// 1) Crawls the league sites and each team's official website for social links.
//    Links on a team's own site are trusted (auto-verified unless AUTO_VERIFY_OFFICIAL=false).
// 2) Links on league sites are matched to teams by name and sent for approval.
// 3) With ANTHROPIC_API_KEY, asks Claude (with web search) for any platforms still missing;
//    those always go to the approval queue.
import { q, one, id } from '../db';
import { fetchText, extractSocialLinks, AgentResult, Social } from './util';
import { askClaude, claudeConfigured, extractJson } from './claude';

const LEAGUE_SITES = (process.env.LEAGUE_SITES || 'https://abudhabit10.com/,https://ttensports.com/').split(',').map((s) => s.trim()).filter(Boolean);
const CORE = ['Instagram', 'X', 'YouTube', 'Facebook', 'TikTok', 'Threads'];

function guessTeam(s: Social, teams: any[]): string | null {
  const h = (s.handle + ' ' + s.url).toLowerCase().replace(/[^a-z0-9]/g, '');
  for (const t of teams) {
    const words = t.name.toLowerCase().split(/\s+/).filter((w: string) => w.length > 3 && !['team', 'royal', 'arabian'].includes(w));
    if (words.some((w: string) => h.includes(w))) return t.id;
    if (h.includes(t.name.toLowerCase().replace(/[^a-z0-9]/g, ''))) return t.id;
  }
  return null;
}

async function known(url: string) {
  return one<any>(`SELECT * FROM handles WHERE lower(url) = lower($1)`, [url]);
}

async function propose(teamId: string | null, s: Social, source: string, reason: string) {
  if (await known(s.url)) return false;
  const hid = id('h_');
  await q(`INSERT INTO handles (id, team_id, platform, handle, url, status, source) VALUES ($1,$2,$3,$4,$5,'pending',$6) ON CONFLICT (url) DO NOTHING`, [hid, teamId, s.platform, s.handle, s.url, source]);
  const team = teamId ? await one<any>(`SELECT name FROM teams WHERE id = $1`, [teamId]) : null;
  await q(
    `INSERT INTO approvals (id, kind, title, detail, payload, dedupe) VALUES ($1,'handle',$2,$3,$4::jsonb,$5) ON CONFLICT (dedupe) DO NOTHING`,
    [id('ap_'), `${s.platform} handle for ${team?.name ?? 'the league'}: ${s.handle}`, reason, JSON.stringify({ handleId: hid }), `handle:${s.url.toLowerCase()}`]
  );
  return true;
}

async function verifyDirect(teamId: string | null, s: Social, source: string) {
  if (await known(s.url)) return false;
  await q(`INSERT INTO handles (id, team_id, platform, handle, url, status, source, verified_at) VALUES ($1,$2,$3,$4,$5,'verified',$6,now()) ON CONFLICT (url) DO NOTHING`, [id('h_'), teamId, s.platform, s.handle, s.url, source]);
  return true;
}

export async function discoveryAgent(): Promise<AgentResult> {
  const teams = await q<any>(`SELECT * FROM teams ORDER BY sort`);
  const notes: string[] = [];
  let added = 0;
  const autoVerify = process.env.AUTO_VERIFY_OFFICIAL !== 'false';

  for (const site of LEAGUE_SITES) {
    try {
      const html = await fetchText(site);
      const links = extractSocialLinks(html);
      for (const s of links) {
        const teamId = guessTeam(s, teams);
        if (!teamId) {
          // League-level account (same as the site's own) — trust if it matches the league brand.
          if (/t10/i.test(s.handle)) { if (await verifyDirect(null, s, `official-site:${site}`)) added++; }
          continue;
        }
        if (await propose(teamId, s, `league-site:${site}`, `Linked from ${site}. Matched to the team by name.`)) added++;
      }
      notes.push(`${site}: ${links.length} links`);
    } catch (e: any) {
      notes.push(`${site}: ${e.message}`);
    }
  }

  for (const t of teams) {
    if (!t.website) continue;
    try {
      const html = await fetchText(t.website);
      const links = extractSocialLinks(html).filter((s) => CORE.includes(s.platform) || s.platform === 'LinkedIn');
      for (const s of links) {
        const ok = autoVerify ? await verifyDirect(t.id, s, `official-site:${t.website}`) : await propose(t.id, s, `official-site:${t.website}`, `Linked from the team's official site ${t.website}.`);
        if (ok) added++;
      }
      notes.push(`${t.short} site: ${links.length} links`);
    } catch (e: any) {
      notes.push(`${t.short} site: ${e.message}`);
    }
  }

  if (claudeConfigured()) {
    for (const t of teams) {
      const have = await q<any>(`SELECT platform FROM handles WHERE team_id = $1 AND status IN ('verified','pending')`, [t.id]);
      const missing = CORE.filter((p) => !have.some((h) => h.platform === p));
      if (!missing.length) continue;
      try {
        const text = await askClaude(
          `Find the OFFICIAL social media accounts of the cricket franchise "${t.name}", which plays in the Abu Dhabi T10 league (UAE). ` +
          `Platforms needed: ${missing.join(', ')}. Only include accounts you are confident are the team's own official account ` +
          `(linked from the team or league website, or verified). Also return the team's official website if you find it. ` +
          `Reply with JSON only: {"website": "url or null", "accounts": [{"platform": "Instagram|X|YouTube|Facebook|TikTok", "url": "https://...", "evidence": "where you confirmed it"}]}`,
          { webSearch: true, maxTokens: 1200 }
        );
        const data = extractJson<any>(text);
        if (data?.website && !t.website && /^https?:\/\//.test(data.website)) {
          await q(
            `INSERT INTO approvals (id, kind, title, detail, payload, dedupe) VALUES ($1,'website',$2,$3,$4::jsonb,$5) ON CONFLICT (dedupe) DO NOTHING`,
            [id('ap_'), `Official website for ${t.name}: ${data.website}`, 'Found by the Discovery agent via web search.', JSON.stringify({ teamId: t.id, website: data.website }), `site:${t.id}:${data.website}`]
          );
        }
        for (const a of data?.accounts || []) {
          const s = extractSocialLinks(` ${a.url} `)[0];
          if (!s || !missing.includes(s.platform)) continue;
          if (await propose(t.id, s, 'web-search', `Web search: ${String(a.evidence || '').slice(0, 200)}`)) added++;
        }
        notes.push(`${t.short} search: ${(data?.accounts || []).length} candidates`);
      } catch (e: any) {
        notes.push(`${t.short} search: ${e.message}`);
      }
    }
  } else {
    notes.push('web search skipped (no ANTHROPIC_API_KEY)');
  }
  await q(`INSERT INTO kv (k, v) VALUES ('discovery:last', $1::jsonb) ON CONFLICT (k) DO UPDATE SET v = EXCLUDED.v`, [JSON.stringify({ at: new Date().toISOString(), notes })]);
  const failed = notes.filter((n) => /\d{3} |abort|fetch failed|ENOTFOUND|timeout/i.test(n)).length;
  return { items: added, summary: `${added} new handles. ${notes.join(' · ')}`.slice(0, 900), failed, total: notes.filter((n) => !/skipped/.test(n)).length };
}
