import { createHash } from 'node:crypto';
import { q, id } from '../db';

export type AgentResult = { items: number; summary: string; failed?: number; total?: number };

export async function runAgent(name: string, fn: () => Promise<AgentResult>) {
  const runId = id('run_');
  await q(`INSERT INTO agent_runs (id, agent) VALUES ($1,$2)`, [runId, name]);
  try {
    const r = await fn();
    const status = r.total && r.failed === r.total ? 'error' : r.failed ? 'warn' : 'ok';
    await q(`UPDATE agent_runs SET status = $4, finished_at = now(), summary = $2, items = $3 WHERE id = $1`, [runId, r.summary, r.items, status]);
    return { ok: true, ...r };
  } catch (e: any) {
    const msg = String(e?.message || e).slice(0, 500);
    await q(`UPDATE agent_runs SET status = 'error', finished_at = now(), summary = $2 WHERE id = $1`, [runId, msg]);
    return { ok: false, items: 0, summary: msg };
  }
}

const UA = 'Mozilla/5.0 (compatible; T10FanHubBot/1.0; +https://example.com/bot)';

export async function fetchText(url: string, timeoutMs = 12000, headers: Record<string, string> = {}) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { headers: { 'User-Agent': UA, Accept: '*/*', ...headers }, signal: ctrl.signal, redirect: 'follow' });
    if (!res.ok) throw new Error(`${res.status} ${res.statusText} for ${url}`);
    return await res.text();
  } finally {
    clearTimeout(t);
  }
}

export function hashId(s: string) {
  return createHash('sha1').update(s).digest('hex').slice(0, 20);
}

function decode(s: string) {
  return s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&amp;/g, '&')
    .trim();
}
export function stripHtml(s: string) {
  return decode(s).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

export type FeedEntry = { title: string; link: string; published?: string; summary?: string; image?: string; source?: string };

// Minimal RSS 2.0 / Atom parser (enough for news sites, Google News and YouTube feeds).
export function parseFeed(xml: string): FeedEntry[] {
  const out: FeedEntry[] = [];
  const blocks = xml.match(/<item[\s>][\s\S]*?<\/item>/g) || xml.match(/<entry[\s>][\s\S]*?<\/entry>/g) || [];
  for (const b of blocks) {
    const tag = (n: string) => { const m = b.match(new RegExp(`<${n}[^>]*>([\\s\\S]*?)</${n}>`)); return m ? decode(m[1]) : undefined; };
    let link = tag('link');
    if (!link || link.startsWith('<')) {
      const m = b.match(/<link[^>]*href="([^"]+)"/);
      link = m ? m[1] : undefined;
    }
    const title = tag('title');
    if (!title || !link) continue;
    const img = b.match(/<media:thumbnail[^>]*url="([^"]+)"/)?.[1] || b.match(/<media:content[^>]*url="([^"]+)"/)?.[1] || b.match(/<enclosure[^>]*url="([^"]+)"/)?.[1];
    const src = b.match(/<source[^>]*>([\s\S]*?)<\/source>/)?.[1];
    out.push({
      title: stripHtml(title), link: link.trim(),
      published: tag('pubDate') || tag('published') || tag('updated') || tag('dc:date'),
      summary: stripHtml(tag('description') || tag('media:description') || tag('summary') || '').slice(0, 240),
      image: img, source: src ? stripHtml(src) : undefined,
    });
  }
  return out;
}

// ---------- Social link extraction ----------
export type Social = { platform: string; handle: string; url: string };

const RULES: { platform: string; re: RegExp; bad?: RegExp; fmt: (h: string) => [string, string] }[] = [
  { platform: 'Instagram', re: /https?:\/\/(?:www\.)?instagram\.com\/([A-Za-z0-9._]{2,30})\/?(?=["'?#\s<]|$)/g, bad: /^(p|reel|reels|explore|stories|accounts|tv)$/i, fmt: (h) => [`@${h}`, `https://www.instagram.com/${h}/`] },
  { platform: 'X', re: /https?:\/\/(?:www\.)?(?:twitter|x)\.com\/(?:#!\/)?([A-Za-z0-9_]{2,15})\/?(?=["'?#\s<]|$)/g, bad: /^(intent|share|home|search|hashtag|i|widgets)$/i, fmt: (h) => [`@${h}`, `https://x.com/${h}`] },
  { platform: 'Facebook', re: /https?:\/\/(?:www\.|m\.)?facebook\.com\/([A-Za-z0-9.\-]{2,60})\/?(?=["'?#\s<]|$)/g, bad: /^(sharer|share|dialog|plugins|tr|events|groups|watch|photo\.php|profile\.php)$/i, fmt: (h) => [h, `https://www.facebook.com/${h}`] },
  { platform: 'YouTube', re: /https?:\/\/(?:www\.)?youtube\.com\/((?:@[A-Za-z0-9._\-]{2,60})|(?:channel\/UC[A-Za-z0-9_\-]{22})|(?:c\/[A-Za-z0-9._\-]{2,60}))\/?(?=["'?#\s<]|$)/g, fmt: (h) => [h.startsWith('@') ? h : h.split('/').pop()!, `https://www.youtube.com/${h}`] },
  { platform: 'TikTok', re: /https?:\/\/(?:www\.)?tiktok\.com\/(@[A-Za-z0-9._]{2,30})\/?(?=["'?#\s<]|$)/g, fmt: (h) => [h, `https://www.tiktok.com/${h}`] },
  { platform: 'Threads', re: /https?:\/\/(?:www\.)?threads\.(?:net|com)\/(@[A-Za-z0-9._]{2,30})\/?(?=["'?#\s<]|$)/g, fmt: (h) => [h, `https://www.threads.com/${h}`] },
  { platform: 'LinkedIn', re: /https?:\/\/(?:www\.)?linkedin\.com\/company\/([A-Za-z0-9\-]{2,80})\/?(?=["'?#\s<]|$)/g, fmt: (h) => [h, `https://www.linkedin.com/company/${h}`] },
];

export function extractSocialLinks(html: string): Social[] {
  const found = new Map<string, Social>();
  for (const r of RULES) {
    for (const m of html.matchAll(r.re)) {
      const h = m[1];
      if (r.bad && r.bad.test(h)) continue;
      const [handle, url] = r.fmt(h);
      found.set(url.toLowerCase(), { platform: r.platform, handle, url });
    }
  }
  return [...found.values()];
}

export function appendLog(msgs: string[], m: string) { msgs.push(m); }
