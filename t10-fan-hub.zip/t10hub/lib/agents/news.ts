// News agent: collects headlines + links (never full articles) from the league site and cricket news feeds.
// Sources are configurable with NEWS_FEEDS (comma-separated "category|url").
import { q } from '../db';
import { fetchText, parseFeed, hashId, stripHtml, AgentResult } from './util';

const DEFAULT_FEEDS = [
  'league|https://news.google.com/rss/search?q=%22Abu+Dhabi+T10%22&hl=en-AE&gl=AE&ceid=AE:en',
  'league|https://news.google.com/rss/search?q=%22T10+League%22+cricket&hl=en&gl=US&ceid=US:en',
  'cricket|https://www.espncricinfo.com/rss/content/story/feeds/0.xml',
  'cricket|https://feeds.bbci.co.uk/sport/cricket/rss.xml',
];
const LEAGUE_PAGES = (process.env.LEAGUE_NEWS_PAGES || 'https://abudhabit10.com/release').split(',').map((s) => s.trim()).filter(Boolean);
const T10_RE = /\bT10\b|Abu Dhabi T10|Arabian Aces|Deccan Gladiators|Northern Warriors|UAE Bulls|Delhi Bulls|Quetta Qavalry|Royal Champs|Vista Riders|Aspin Stallions|Ajman Titans/i;

async function save(category: string, it: { title: string; link: string; image?: string; summary?: string; published?: string; source?: string }) {
  const pub = it.published && !isNaN(Date.parse(it.published)) ? new Date(it.published).toISOString() : new Date().toISOString();
  const title = it.title.replace(/\s+-\s+[^-]+$/, (m) => (it.source ? '' : m)); // Google News appends " - Source"
  const r = await q(
    `INSERT INTO feed_items (id, platform, kind, category, title, url, image, source, summary, published_at)
     VALUES ($1,'Web','news',$2,$3,$4,$5,$6,$7,$8) ON CONFLICT (id) DO NOTHING RETURNING id`,
    [hashId(it.link), category, title.slice(0, 300), it.link, it.image ?? null, it.source ?? new URL(it.link).hostname.replace('www.', ''), (it.summary ?? '').slice(0, 220), pub]
  );
  return r.length;
}

export async function newsAgent(): Promise<AgentResult> {
  const feeds = (process.env.NEWS_FEEDS ? process.env.NEWS_FEEDS.split(',') : DEFAULT_FEEDS).map((s) => s.trim().split('|'));
  let added = 0;
  const notes: string[] = [];
  for (const [category, url] of feeds) {
    try {
      const items = parseFeed(await fetchText(url)).slice(0, 25);
      let n = 0;
      for (const it of items) {
        if (category === 'league' && !T10_RE.test(it.title + ' ' + (it.summary || ''))) continue;
        const cat = category === 'cricket' && T10_RE.test(it.title) ? 'league' : category;
        n += await save(cat, it);
      }
      added += n;
      notes.push(`${new URL(url).hostname}: +${n}`);
    } catch (e: any) {
      notes.push(`${new URL(url).hostname}: ${e.message}`);
    }
  }
  // Official league press releases: scrape headline links from the listing page.
  for (const page of LEAGUE_PAGES) {
    try {
      const html = await fetchText(page);
      const base = new URL(page);
      let n = 0;
      for (const m of html.matchAll(/<a[^>]+href="([^"#]+)"[^>]*>([\s\S]{12,200}?)<\/a>/g)) {
        const text = stripHtml(m[2]);
        if (text.length < 20 || /cookie|privacy|terms|login|register/i.test(text)) continue;
        const href = new URL(m[1], base).toString();
        if (!href.startsWith(base.origin) || href === page) continue;
        n += await save('league', { title: text, link: href, source: 'abudhabit10.com' });
        if (n >= 15) break;
      }
      added += n;
      notes.push(`${base.hostname}: +${n}`);
    } catch (e: any) {
      notes.push(`${page}: ${e.message}`);
    }
  }
  // Keep the table lean.
  await q(`DELETE FROM feed_items WHERE kind = 'news' AND published_at < now() - interval '120 days'`);
  const failed = notes.filter((n) => /\d{3} |abort|fetch failed|ENOTFOUND|timeout/i.test(n)).length;
  return { items: added, summary: `${added} new headlines. ${notes.join(' · ')}`, failed, total: notes.filter((n) => !/skipped/.test(n)).length };
}
