// Database layer. Uses Postgres when DATABASE_URL is set (Supabase, Neon, RDS...),
// otherwise an embedded Postgres (PGlite) stored in ./.data for local development.
import { SCHEMA_SQL } from './schema';
import { seedBase } from './seed';

type Row = Record<string, any>;
type Runner = (text: string, params?: any[]) => Promise<Row[]>;

const g = globalThis as any;

async function makeRunner(): Promise<Runner> {
  const url = process.env.DATABASE_URL;
  if (url) {
    const postgres = (await import('postgres')).default;
    const sql = postgres(url, { max: 5, prepare: false, ssl: url.includes('localhost') ? false : 'require' });
    return async (text, params = []) => (await sql.unsafe(text, params as any[])) as unknown as Row[];
  }
  if (process.env.NODE_ENV === 'production' && !process.env.PGLITE_DIR && process.env.NEXT_PHASE !== 'phase-production-build') {
    throw new Error('Set DATABASE_URL (Supabase/Neon Postgres) for production, or PGLITE_DIR for a single-server install.');
  }
  const { PGlite } = await import('@electric-sql/pglite');
  const dir = process.env.PGLITE_DIR || './.data/pglite';
  (await import('node:fs')).mkdirSync(dir, { recursive: true });
  const db = new PGlite(dir);
  await db.waitReady;
  // PGlite is single-connection: serialise queries.
  let chain: Promise<any> = Promise.resolve();
  return (text, params = []) => {
    const p = chain.then(() => db.query(text, params)).then((r: any) => r.rows as Row[]);
    chain = p.catch(() => undefined);
    return p;
  };
}

async function init(): Promise<Runner> {
  const run = await makeRunner();
  for (const stmt of SCHEMA_SQL.split(';\n').map((s) => s.trim()).filter(Boolean)) {
    await run(stmt);
  }
  await seedBase(run);
  return run;
}

function runner(): Promise<Runner> {
  if (!g.__t10db) g.__t10db = init().catch((e) => { g.__t10db = undefined; throw e; });
  return g.__t10db;
}

export async function q<T = Row>(text: string, params: any[] = []): Promise<T[]> {
  const run = await runner();
  return (await run(text, params)) as T[];
}

export async function one<T = Row>(text: string, params: any[] = []): Promise<T | null> {
  const rows = await q<T>(text, params);
  return rows[0] ?? null;
}

export function id(prefix = ''): string {
  return prefix + crypto.randomUUID().replace(/-/g, '').slice(0, 16);
}
