// Base seed: real league facts only. Runs once (guarded by kv 'seed:base:v1').
// Squads are the 2025 post-draft squads (Wisden). The admin console or the
// Scores agent updates them for 2026. Arabian Aces is new for 2026.
type Runner = (text: string, params?: any[]) => Promise<any[]>;

export const TEAMS: { id: string; name: string; short: string; color: string; home: string; icon: string; website?: string; note?: string; squad: string[] }[] = [
  { id: 'aces', name: 'Arabian Aces', short: 'AAC', color: '#E8B04A', home: 'Abu Dhabi, UAE', icon: 'Moeen Ali', note: 'New franchise for 2026. Head coach: Lance Klusener. Full squad after the draft.',
    squad: ['Moeen Ali'] },
  { id: 'ajman', name: 'Ajman Titans', short: 'AJT', color: '#8FA3B8', home: 'Ajman, UAE', icon: 'Moeen Ali (2025)', note: '2025 squad shown.',
    squad: ['Rilee Rossouw', 'Piyush Chawla', 'Will Smeed', 'Jason Behrendorff', 'Dan Lawrence', 'Alishan Sharafu', 'Alex Hales', 'Asif Ali', 'Chris Green', 'Akif Javed', 'Zaman Khan', 'Aneurin Donald', 'Haider Ali', 'Wasim Akram', 'Luc Benkenstein', 'Tom Aspinwall', 'Joe Clarke', 'Asif Khan'] },
  { id: 'stallions', name: 'Aspin Stallions', short: 'ASP', color: '#C77DFF', home: 'Abu Dhabi, UAE', icon: 'Sam Billings', note: '2025 squad shown.',
    squad: ['Sam Billings', 'Tymal Mills', 'Harbhajan Singh', 'Andre Fletcher', 'Avishka Fernando', 'Binura Fernando', 'Zohair Iqbal', 'Sherfane Rutherford', 'Saif Hassan', 'Ryan Burl', 'Akhilesh Bodugum', 'Ali Khan', 'Ben Cutting', 'Essam Muti Ur Rab', 'Hafeez Ur Rehman', 'Ashmead Nedd', 'Matthew Hurst', 'Monank Patel', 'Harshit Seth'] },
  { id: 'deccan', name: 'Deccan Gladiators', short: 'DG', color: '#E85A6B', home: 'Hyderabad, India', icon: 'Nicholas Pooran', website: 'https://deccangladiators.com/', note: '2025 squad shown.',
    squad: ['Nicholas Pooran', 'Marcus Stoinis', 'Andre Russell', 'Akeal Hosein', 'Tom Kohler-Cadmore', 'Usman Tariq', 'Ibrar Ahmad', 'Richard Gleeson', 'Lahiru Kumara', 'Jordan Thompson', 'Dilpreet Singh Bajwa', 'Jake Ball', 'Muhammad Jawadullah', 'Ajay Kumar', 'Ali Raza', 'Wafiullah Tarakhil', 'Laurie Evans', 'Mark Chapman'] },
  { id: 'bulls', name: 'UAE Bulls', short: 'UB', color: '#4AA8E8', home: 'UAE', icon: 'Rovman Powell', note: '2025 champions (as UAE Bulls). 2025 squad shown.',
    squad: ['Rovman Powell', 'Phil Salt', 'Kieron Pollard', 'Tim David', 'Sunil Narine', 'Salman Irshad', 'Muhammad Rohid', 'Blessing Muzarabani', 'James Vince', 'Tom Moores', 'Qais Ahmad', 'Mir Hamza', 'James Coles', 'Junaid Siddique', 'Farhan Khan', 'Brian Bennett', 'Arab Gul', 'Romario Shepherd', 'Fazalhaq Farooqi'] },
  { id: 'warriors', name: 'Northern Warriors', short: 'NW', color: '#5CD68A', home: 'UAE', icon: 'Shimron Hetmyer', note: '2025 squad shown.',
    squad: ['Shimron Hetmyer', 'Trent Boult', 'Thisara Perera', 'Johnson Charles', 'Colin Munro', 'Azmatullah Omarzai', 'Tabraiz Shamsi', 'Odean Smith', 'Shahnawaz Dahani', 'Dinesh Chandimal', 'Hazratullah Zazai', 'Asitha Fernando', 'Sagar Kalyan', 'Yayin Kiran Rai', 'Shahid Iqbal Bhutta', 'Bilal Sami', 'Faridoon Dawoodzai', 'Prabath Jayasuriya', 'Kadeem Alleyne'] },
  { id: 'qavalry', name: 'Quetta Qavalry', short: 'QQ', color: '#9B7BE8', home: 'Quetta, Pakistan', icon: 'Liam Livingstone', note: '2025 squad shown.',
    squad: ['Liam Livingstone', 'Jason Holder', 'Mohammad Amir', 'Sikandar Raza', 'Andries Gous', 'Imran Tahir', 'Muhammad Waseem', 'Evin Lewis', 'Fabian Allen', 'Abbas Afridi', 'Irfan Khan Niazi', 'George Scrimshaw', 'Khawaja Nafay', 'Abdul Ghaffar', 'Khuzaima Bin Tanvir', 'Arafat Minhas', 'Umar Lohya', 'Gudakesh Motie', 'Ali Naseer'] },
  { id: 'champs', name: 'Royal Champs', short: 'RC', color: '#F08A3C', home: 'Abu Dhabi, UAE', icon: 'Jason Roy', note: '2025 squad shown.',
    squad: ['Jason Roy', 'Angelo Mathews', 'Shakib Al Hasan', 'Chris Jordan', 'Daniel Sams', 'Niroshan Dickwella', 'Rahul Chopra', 'Mohammad Shehzad', 'Rishi Dhawan', 'Liam Dawson', 'Brandon McMullen', 'Isuru Udana', 'Quentin Sampson', 'Haider Razzaq', 'Zahid Ali', 'Kelvin Pitman', 'Vishen Halambage', 'Ziaur Rahman Sharifi', 'Aaron Jones'] },
  { id: 'riders', name: 'Vista Riders', short: 'VR', color: '#3CC8C8', home: 'UAE', icon: 'Faf du Plessis', note: '2025 squad shown.',
    squad: ['Faf du Plessis', 'Matthew Wade', 'S Sreesanth', 'Dwaine Pretorius', 'Bhanuka Rajapaksa', 'Unmukt Chand', 'Harshit Kaushik', 'Andrew Tye', 'Ben McDermott', 'Dilshan Madushanka', 'Nahid Rana', 'Angelo Perera', 'Sean Dickson', 'Ansh Tandon', 'CP Rizwan', 'Izharulhaq Naveed', 'Ackeem Auguste', 'Murali Vijay', 'Sharafuddin Ashraf'] },
];

// Official handles already confirmed from public sources. Everything else is found by the Discovery agent.
export const SEED_HANDLES: { team: string | null; platform: string; handle: string; url: string }[] = [
  { team: null, platform: 'Instagram', handle: '@t10league', url: 'https://www.instagram.com/t10league/' },
  { team: null, platform: 'X', handle: '@T10League', url: 'https://x.com/T10League' },
  { team: null, platform: 'Facebook', handle: 'T10league', url: 'https://www.facebook.com/T10league' },
  { team: null, platform: 'TikTok', handle: '@abudhabit10', url: 'https://www.tiktok.com/@abudhabit10' },
  { team: null, platform: 'YouTube', handle: '@T10LeagueOfficial', url: 'https://www.youtube.com/@T10LeagueOfficial' },
  { team: 'aces', platform: 'X', handle: '@arabianacesT10', url: 'https://x.com/arabianacesT10' },
  { team: 'aces', platform: 'Instagram', handle: '@arabianacesofficial', url: 'https://www.instagram.com/arabianacesofficial/' },
  { team: 'aces', platform: 'Threads', handle: '@arabianacesofficial', url: 'https://www.threads.com/@arabianacesofficial' },
  { team: 'aces', platform: 'Facebook', handle: 'arabianacesofficial', url: 'https://www.facebook.com/arabianacesofficial/' },
  { team: 'aces', platform: 'TikTok', handle: '@arabianaces', url: 'https://www.tiktok.com/@arabianaces' },
  { team: 'aces', platform: 'LinkedIn', handle: 'arabianaces', url: 'https://www.linkedin.com/in/arabianaces/' },
  { team: 'deccan', platform: 'Instagram', handle: '@deccangladiators', url: 'https://www.instagram.com/deccangladiators/' },
  { team: 'deccan', platform: 'X', handle: '@TeamDGladiators', url: 'https://x.com/TeamDGladiators' },
  { team: 'deccan', platform: 'Facebook', handle: 'deccangladiators', url: 'https://www.facebook.com/deccangladiators/' },
  { team: 'warriors', platform: 'Instagram', handle: '@northernwarriorst10', url: 'https://www.instagram.com/northernwarriorst10/' },
  { team: 'bulls', platform: 'Instagram', handle: '@delhibullst10', url: 'https://www.instagram.com/delhibullst10/' },
  { team: 'bulls', platform: 'X', handle: '@DelhiBullsT10', url: 'https://x.com/DelhiBullsT10' },
];

// Trivia bank built from the league's published history.
export const TRIVIA: { prompt: string; options: string[]; answer: string; explain: string }[] = [
  { prompt: 'Who won the very first T10 League title in 2017?', options: ['Kerala Kings', 'Northern Warriors', 'Maratha Arabians', 'Pakhtoons'], answer: 'Kerala Kings', explain: 'Kerala Kings won the inaugural 2017 edition in Sharjah.' },
  { prompt: 'Which franchise has won the most Abu Dhabi T10 titles?', options: ['Northern Warriors', 'Deccan Gladiators', 'Delhi Bulls', 'Team Abu Dhabi'], answer: 'Deccan Gladiators', explain: 'Deccan Gladiators won in 2021-22, 2022 and 2024.' },
  { prompt: 'Who won the 2023 Abu Dhabi T10?', options: ['New York Strikers', 'Deccan Gladiators', 'Morrisville Samp Army', 'Chennai Braves'], answer: 'New York Strikers', explain: 'New York Strikers lifted the 2023 trophy.' },
  { prompt: 'Which team won the 2025 Abu Dhabi T10?', options: ['Quetta Qavalry', 'UAE Bulls', 'Aspin Stallions', 'Ajman Titans'], answer: 'UAE Bulls', explain: 'UAE Bulls were the 2025 champions.' },
  { prompt: 'How many overs does each side bat in a T10 match?', options: ['6', '8', '10', '12'], answer: '10', explain: 'Ten overs a side, around 90 minutes per match.' },
  { prompt: 'Northern Warriors have won the league how many times?', options: ['Once', 'Twice', 'Three times', 'Never'], answer: 'Twice', explain: 'Northern Warriors won in 2018 and 2021.' },
  { prompt: 'Which team won the 2019 edition?', options: ['Maratha Arabians', 'Deccan Gladiators', 'Northern Warriors', 'Qalandars'], answer: 'Maratha Arabians', explain: 'Maratha Arabians won the 2019 title.' },
];

export async function seedBase(run: Runner) {
  for (const h of SEED_HANDLES) {
    await run(
      `INSERT INTO handles (id, team_id, platform, handle, url, status, source, verified_at) VALUES ($1,$2,$3,$4,$5,'verified','seed',now()) ON CONFLICT (url) DO NOTHING`,
      [crypto.randomUUID(), h.team, h.platform, h.handle, h.url]
    );
  }
  const done = await run(`SELECT 1 FROM kv WHERE k = 'seed:base:v1'`);
  if (done.length) return;
  let sort = 0;
  for (const t of TEAMS) {
    await run(
      `INSERT INTO teams (id, name, short, color, home, icon_player, website, note, sort) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT (id) DO NOTHING`,
      [t.id, t.name, t.short, t.color, t.home, t.icon, t.website ?? null, t.note ?? null, sort++]
    );
    let i = 0;
    for (const p of t.squad) {
      const credits = i === 0 ? 10.5 : i < 5 ? 9.5 : i < 10 ? 8.5 : 7.5;
      await run(
        `INSERT INTO players (id, team_id, name, credits, is_icon) VALUES ($1,$2,$3,$4,$5) ON CONFLICT (id) DO NOTHING`,
        [`${t.id}-${slug(p)}`, t.id, p, credits, i === 0]
      );
      i++;
    }
  }
  for (const h of SEED_HANDLES) {
    await run(
      `INSERT INTO handles (id, team_id, platform, handle, url, status, source, verified_at) VALUES ($1,$2,$3,$4,$5,'verified','seed',now()) ON CONFLICT (url) DO NOTHING`,
      [crypto.randomUUID(), h.team, h.platform, h.handle, h.url]
    );
  }
  // Season-long contest.
  const season = 'season-2026';
  await run(
    `INSERT INTO contests (id, type, title, description, locks_at, status, prize) VALUES ($1,'season','Season Oracle 2026','Call the season before a ball is bowled. Locks at the first match.', NULL, 'open', 'Top 3: signed team jerseys') ON CONFLICT (id) DO NOTHING`,
    [season]
  );
  const teamNames = TEAMS.map((t) => t.name);
  const qs = [
    { p: 'Who will be the 2026 champions?', o: teamNames, pts: 100, key: 'season_champion' },
    { p: 'Who will finish bottom of the table?', o: teamNames, pts: 60, key: 'season_bottom' },
    { p: 'How many sixes will be hit across the whole season?', o: ['Under 400', '400 to 499', '500 to 599', '600+'], pts: 80, key: 'season_sixes' },
    { p: 'Will any team score 150+ in 10 overs this season?', o: ['Yes', 'No'], pts: 40, key: 'season_150' },
  ];
  let s = 0;
  for (const x of qs) {
    await run(
      `INSERT INTO questions (id, contest_id, prompt, kind, options, points, auto_key, sort) VALUES ($1,$2,$3,'choice',$4::jsonb,$5,$6,$7) ON CONFLICT (id) DO NOTHING`,
      [`${season}-q${s}`, season, x.p, JSON.stringify(x.o), x.pts, x.key, s++]
    );
  }
  // Trivia: instant-answer contest from the history bank.
  const triv = 'trivia-history';
  await run(
    `INSERT INTO contests (id, type, title, description, status, instant, prize) VALUES ($1,'trivia','T10 History Quiz','Seven questions on the league''s history. Answers are revealed as soon as you lock in.','open', true, '10 pts per correct answer') ON CONFLICT (id) DO NOTHING`,
    [triv]
  );
  s = 0;
  for (const t of TRIVIA) {
    await run(
      `INSERT INTO questions (id, contest_id, prompt, kind, options, points, answer, explain, sort) VALUES ($1,$2,$3,'choice',$4::jsonb,10,$5,$6,$7) ON CONFLICT (id) DO NOTHING`,
      [`${triv}-q${s}`, triv, t.prompt, JSON.stringify(t.options), t.answer, t.explain, s++]
    );
  }
  await run(`INSERT INTO kv (k, v) VALUES ('seed:base:v1', 'true'::jsonb) ON CONFLICT (k) DO NOTHING`);
}

export function slug(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}
