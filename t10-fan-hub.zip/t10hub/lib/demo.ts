// Demo fixtures for testing before the 2026 schedule is published. All rows are flagged is_demo.
import { q, id } from './db';
import { ensureMatchContests } from './game';

export async function seedDemo() {
  const pairs = [['aces', 'deccan'], ['bulls', 'warriors'], ['qavalry', 'champs'], ['riders', 'stallions'], ['aces', 'bulls'], ['ajman', 'deccan']];
  let n = 0;
  const base = Date.now();
  for (let i = 0; i < pairs.length; i++) {
    const mid = `demo-m${i + 1}`;
    const starts = new Date(base + (i < 2 ? 2 : 24 * Math.ceil(i / 2)) * 3600_000 + i * 2 * 3600_000).toISOString();
    const r = await q(`INSERT INTO matches (id, match_no, team_a, team_b, starts_at, is_demo) VALUES ($1,$2,$3,$4,$5,true) ON CONFLICT (id) DO NOTHING RETURNING id`, [mid, i + 1, pairs[i][0], pairs[i][1], starts]);
    if (r.length) { n++; await ensureMatchContests(mid); }
  }
  await q(`INSERT INTO draws (id, title, prize, rule, color, closes_at) VALUES ('demo-d1','Arabian Aces signed jersey','SIGNED JERSEY','One free entry per fan.','#E8B04A', now() + interval '5 days') ON CONFLICT DO NOTHING`);
  await q(`INSERT INTO draws (id, title, prize, rule, color, closes_at) VALUES ('demo-d2','Family ticket pack for the final','4 TICKETS','Open to all registered fans.','#4AA8E8', now() + interval '9 days') ON CONFLICT DO NOTHING`);
  await q(`INSERT INTO draws (id, title, prize, rule, color, closes_at, team_only) VALUES ('demo-d3','Nets session with the Aces','MEET THE TEAM','Arabian Aces fans only.','#5CD68A', now() + interval '12 days', 'aces') ON CONFLICT DO NOTHING`);
  return { ok: true, matches: n };
}

export async function clearDemo() {
  const ms = await q<any>(`SELECT id FROM matches WHERE is_demo = true`);
  for (const m of ms) {
    await q(`DELETE FROM entries WHERE contest_id IN (SELECT id FROM contests WHERE match_id = $1)`, [m.id]);
    await q(`DELETE FROM questions WHERE contest_id IN (SELECT id FROM contests WHERE match_id = $1)`, [m.id]);
    await q(`DELETE FROM contests WHERE match_id = $1`, [m.id]);
    await q(`DELETE FROM fantasy_teams WHERE match_id = $1`, [m.id]);
    await q(`DELETE FROM player_stats WHERE match_id = $1`, [m.id]);
  }
  await q(`DELETE FROM matches WHERE is_demo = true`);
  await q(`DELETE FROM draw_entries WHERE draw_id LIKE 'demo-%'`);
  await q(`DELETE FROM draws WHERE id LIKE 'demo-%'`);
  return { ok: true, id: id() };
}
