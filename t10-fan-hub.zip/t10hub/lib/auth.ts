import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { createHash, randomInt, timingSafeEqual } from 'node:crypto';
import { q, one, id } from './db';

export const SESSION_COOKIE = 't10_session';
const MAX_AGE = 60 * 60 * 24 * 30;

function secret() {
  const s = process.env.AUTH_SECRET;
  if (!s) {
    if (process.env.NODE_ENV === 'production') throw new Error('AUTH_SECRET is required in production');
    return new TextEncoder().encode('dev-only-secret-change-me-dev-only-secret');
  }
  return new TextEncoder().encode(s);
}

export type User = {
  id: string; email: string; name: string | null; avatar: string | null; provider: string;
  team_id: string | null; team_changes: number; isAdmin: boolean;
};

export function isAdminEmail(email: string) {
  const list = (process.env.ADMIN_EMAILS || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
  return list.includes(email.toLowerCase());
}

export async function createSession(userId: string) {
  const token = await new SignJWT({ uid: userId })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(`${MAX_AGE}s`)
    .sign(secret());
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: MAX_AGE,
  });
}

export async function clearSession() {
  (await cookies()).delete(SESSION_COOKIE);
}

export async function getUser(): Promise<User | null> {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret());
    const u = await one<any>(`SELECT * FROM users WHERE id = $1`, [payload.uid]);
    if (!u) return null;
    return { ...u, isAdmin: isAdminEmail(u.email) };
  } catch {
    return null;
  }
}

export async function upsertUser(email: string, provider: string, name?: string | null, avatar?: string | null) {
  email = email.trim().toLowerCase();
  const existing = await one<any>(`SELECT * FROM users WHERE email = $1`, [email]);
  if (existing) {
    await q(`UPDATE users SET name = COALESCE($2, name), avatar = COALESCE($3, avatar) WHERE id = $1`, [existing.id, name ?? null, avatar ?? null]);
    return existing.id as string;
  }
  const uid = id('u_');
  await q(`INSERT INTO users (id, email, name, avatar, provider) VALUES ($1,$2,$3,$4,$5)`, [uid, email, name ?? email.split('@')[0], avatar ?? null, provider]);
  await q(`INSERT INTO points_ledger (id, user_id, amount, reason, ref) VALUES ($1,$2,25,'Welcome bonus','welcome') ON CONFLICT DO NOTHING`, [id('pl_'), uid]);
  return uid;
}

// ---------- Email OTP ----------
const OTP_TTL_MIN = 10;

function hashCode(email: string, code: string) {
  return createHash('sha256').update(`${email}:${code}:${new TextDecoder().decode(secret())}`).digest('hex');
}

export async function issueOtp(emailRaw: string): Promise<{ ok: true; code: string } | { ok: false; error: string }> {
  const email = emailRaw.trim().toLowerCase();
  const recent = await q<{ n: number }>(`SELECT count(*)::int AS n FROM otp_codes WHERE email = $1 AND created_at > now() - interval '1 hour'`, [email]);
  if ((recent[0]?.n ?? 0) >= 5) return { ok: false, error: 'Too many codes requested. Try again in an hour.' };
  const last = await one<any>(`SELECT created_at FROM otp_codes WHERE email = $1 ORDER BY created_at DESC LIMIT 1`, [email]);
  if (last && Date.now() - new Date(last.created_at).getTime() < 30_000) return { ok: false, error: 'Please wait 30 seconds before requesting another code.' };
  const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
  await q(`UPDATE otp_codes SET used = true WHERE email = $1 AND used = false`, [email]);
  await q(`INSERT INTO otp_codes (id, email, code_hash, expires_at) VALUES ($1,$2,$3, now() + interval '${OTP_TTL_MIN} minutes')`, [id('otp_'), email, hashCode(email, code)]);
  return { ok: true, code };
}

export async function verifyOtp(emailRaw: string, code: string): Promise<{ ok: true } | { ok: false; error: string }> {
  const email = emailRaw.trim().toLowerCase();
  const row = await one<any>(`SELECT * FROM otp_codes WHERE email = $1 AND used = false ORDER BY created_at DESC LIMIT 1`, [email]);
  if (!row) return { ok: false, error: 'No active code. Request a new one.' };
  if (new Date(row.expires_at).getTime() < Date.now()) return { ok: false, error: 'That code has expired. Request a new one.' };
  if (row.attempts >= 5) return { ok: false, error: 'Too many attempts. Request a new code.' };
  const a = Buffer.from(hashCode(email, code.trim()));
  const b = Buffer.from(row.code_hash);
  if (a.length !== b.length || !timingSafeEqual(a, b)) {
    await q(`UPDATE otp_codes SET attempts = attempts + 1 WHERE id = $1`, [row.id]);
    return { ok: false, error: 'Incorrect code.' };
  }
  await q(`UPDATE otp_codes SET used = true WHERE id = $1`, [row.id]);
  return { ok: true };
}

export function appUrl() {
  return (process.env.APP_URL || 'http://localhost:3000').replace(/\/$/, '');
}

export function googleConfigured() {
  return !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
}
