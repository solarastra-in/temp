import { createHash, randomBytes } from 'node:crypto';
import { q, one, id } from './db';

export const ENTRY_BONUS = 5;
export const FANTASY = { size: 6, budget: 55, maxPerTeam: 4, pts: { run: 1, four: 1, six: 2, wicket: 20, catch: 8 } };

export async function award(userId: string, amount: number, reason: string, ref: string) {
  const u = await one<any>(`SELECT team_id FROM users WHERE id = $1`, [userId]);
  await q(
    `INSERT INTO points_ledger (id, user_id, team_id, amount, reason, ref) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (user_id, ref) DO NOTHING`,
    [id('pl_'), userId, u?.team_id ?? null, amount, reason, ref]
  );
}

export async function userPoints(userId: string) {
  const r = await one<{ p: number }>(`SELECT COALESCE(sum(amount),0)::int AS p FROM points_ledger WHERE user_id = $1`, [userId]);
  return r?.p ?? 0;
}

export function contestLocked(c: any) {
  if (c.status !== 'open') return true;
  return !!(c.locks_at && new Date(c.locks_at).getTime() <= Date.now());
}

// Submit answers for a question-based contest.
export async function submitEntries(userId: string, contestId: string, answers: Record<string, string>) {
  const c = await one<any>(`SELECT * FROM contests WHERE id = $1`, [contestId]);
  if (!c) throw new Error('Contest not found');
  if (contestLocked(c)) throw new Error('This contest is locked');
  const qs = await q<any>(`SELECT * FROM questions WHERE contest_id = $1 ORDER BY sort`, [contestId]);
  const results: Record<string, { correct?: boolean; answer?: string; explain?: string }> = {};
  for (const qu of qs) {
    const a = answers[qu.id];
    if (a == null || a === '') continue;
    const opts: string[] = qu.options || [];
    if (qu.kind === 'choice' && !opts.includes(a)) throw new Error('Invalid option');
    if (c.instant) {
      // Instant contests (trivia) cannot be re-answered.
      const prev = await one<any>(`SELECT * FROM entries WHERE user_id = $1 AND question_id = $2`, [userId, qu.id]);
      if (prev) { results[qu.id] = { correct: prev.points > 0, answer: qu.answer, explain: qu.explain }; continue; }
      const correct = a === qu.answer;
      await q(`INSERT INTO entries (user_id, question_id, contest_id, answer, points) VALUES ($1,$2,$3,$4,$5)`, [userId, qu.id, contestId, a, correct ? qu.points : 0]);
      if (correct) await award(userId, qu.points, `Trivia: correct answer`, `q:${qu.id}`);
      results[qu.id] = { correct, answer: qu.answer, explain: qu.explain };
    } else {
      await q(
        `INSERT INTO entries (user_id, question_id, contest_id, answer) VALUES ($1,$2,$3,$4)
         ON CONFLICT (user_id, question_id) DO UPDATE SET answer = EXCLUDED.answer, created_at = now()`,
        [userId, qu.id, contestId, a]
      );
    }
  }
  await award(userId, ENTRY_BONUS, `Entered: ${c.title}`, `c:${contestId}`);
  return results;
}

// Resolve a question and score every entry on it.
export async function resolveQuestion(questionId: string, answer: string) {
  const qu = await one<any>(`SELECT * FROM questions WHERE id = $1`, [questionId]);
  if (!qu) return 0;
  await q(`UPDATE questions SET answer = $2 WHERE id = $1`, [questionId, answer]);
  const es = await q<any>(`SELECT * FROM entries WHERE question_id = $1`, [questionId]);
  for (const e of es) {
    const pts = e.answer === answer ? qu.points : 0;
    await q(`UPDATE entries SET points = $3 WHERE user_id = $1 AND question_id = $2`, [e.user_id, questionId, pts]);
    if (pts) await award(e.user_id, pts, `Correct: ${qu.prompt}`, `q:${questionId}`);
  }
  return es.length;
}

export function bucket(n: number, edges: number[], labels: string[]) {
  for (let i = 0; i < edges.length; i++) if (n < edges[i]) return labels[i];
  return labels[labels.length - 1];
}

export const SIXES_BUCKETS = { edges: [8, 12, 16], labels: ['0 to 7', '8 to 11', '12 to 15', '16+'] };
export const TOTAL_BUCKETS = { edges: [100, 120, 140], labels: ['Under 100', '100 to 119', '120 to 139', '140+'] };

// Create the standard contests for a match (called by the Contest agent when a fixture appears).
export async function ensureMatchContests(matchId: string) {
  const m = await one<any>(`SELECT m.*, a.name AS a_name, b.name AS b_name FROM matches m JOIN teams a ON a.id = m.team_a JOIN teams b ON b.id = m.team_b WHERE m.id = $1`, [matchId]);
  if (!m) return 0;
  const players = await q<any>(`SELECT name FROM players WHERE team_id IN ($1,$2) ORDER BY credits DESC, name LIMIT 8`, [m.team_a, m.team_b]);
  const defs = [
    {
      cid: `pred-${m.id}`, type: 'predictor', title: `${m.a_name} vs ${m.b_name}: Match Predictor`,
      desc: 'Call the winner, the top run-scorer and the first-innings total. Scored automatically from the live feed.',
      qs: [
        { p: 'Who wins?', o: [m.a_name, m.b_name], pts: 20, key: 'winner' },
        { p: 'Top run-scorer of the match', o: players.map((x) => x.name).concat(['Someone else']), pts: 30, key: 'top_scorer' },
        { p: 'First-innings total', o: TOTAL_BUCKETS.labels, pts: 25, key: 'first_innings' },
      ],
    },
    {
      cid: `sixes-${m.id}`, type: 'sixes', title: `Six Machine: ${m.a_name} vs ${m.b_name}`,
      desc: 'How many sixes will fly in this match? Closest bucket wins.',
      qs: [{ p: 'Total sixes in the match (both teams)', o: SIXES_BUCKETS.labels, pts: 30, key: 'total_sixes' }],
    },
    {
      cid: `duel-${m.id}`, type: 'duel', title: `Captain's Duel: ${m.a_name} vs ${m.b_name}`,
      desc: 'Which side will hit more sixes, and will the chase be won?',
      qs: [
        { p: 'Which team hits more sixes?', o: [m.a_name, m.b_name, 'Tied'], pts: 20, key: 'more_sixes' },
        { p: 'Will the chasing team win?', o: ['Yes', 'No'], pts: 15, key: 'chase_won' },
      ],
    },
  ];
  let n = 0;
  for (const d of defs) {
    const ins = await q(
      `INSERT INTO contests (id, type, title, description, match_id, locks_at, status, prize) VALUES ($1,$2,$3,$4,$5,$6,'open',$7) ON CONFLICT (id) DO NOTHING RETURNING id`,
      [d.cid, d.type, d.title, d.desc, m.id, m.starts_at, 'Points toward the weekly prize']
    );
    if (!ins.length) continue;
    n++;
    let s = 0;
    for (const x of d.qs) {
      await q(
        `INSERT INTO questions (id, contest_id, prompt, kind, options, points, auto_key, sort) VALUES ($1,$2,$3,'choice',$4::jsonb,$5,$6,$7) ON CONFLICT (id) DO NOTHING`,
        [`${d.cid}-q${s}`, d.cid, x.p, JSON.stringify(x.o), x.pts, x.key, s++]
      );
    }
  }
  return n;
}

// Settle every contest attached to a completed match using its stored result.
export async function settleMatch(matchId: string) {
  const m = await one<any>(`SELECT m.*, a.name AS a_name, b.name AS b_name FROM matches m JOIN teams a ON a.id = m.team_a JOIN teams b ON b.id = m.team_b WHERE m.id = $1`, [matchId]);
  if (!m || m.status !== 'completed') return { settled: 0 };
  const stats = await q<any>(`SELECT ps.*, p.team_id, p.name FROM player_stats ps JOIN players p ON p.id = ps.player_id WHERE ps.match_id = $1`, [matchId]);
  const sixA = stats.filter((s) => s.team_id === m.team_a).reduce((t, s) => t + s.sixes, 0);
  const sixB = stats.filter((s) => s.team_id === m.team_b).reduce((t, s) => t + s.sixes, 0);
  const winnerName = m.winner === m.team_a ? m.a_name : m.winner === m.team_b ? m.b_name : null;
  const questions = await q<any>(`SELECT q.* FROM questions q JOIN contests c ON c.id = q.contest_id WHERE c.match_id = $1 AND q.answer IS NULL`, [matchId]);
  let settled = 0;
  for (const qu of questions) {
    let ans: string | null = null;
    const opts: string[] = qu.options;
    if (qu.auto_key === 'winner') ans = winnerName;
    if (qu.auto_key === 'top_scorer' && m.top_scorer) ans = opts.includes(m.top_scorer) ? m.top_scorer : 'Someone else';
    if (qu.auto_key === 'first_innings' && m.first_innings != null) ans = bucket(m.first_innings, TOTAL_BUCKETS.edges, TOTAL_BUCKETS.labels);
    if (qu.auto_key === 'total_sixes' && m.total_sixes != null) ans = bucket(m.total_sixes, SIXES_BUCKETS.edges, SIXES_BUCKETS.labels);
    if (qu.auto_key === 'more_sixes' && stats.length) ans = sixA === sixB ? 'Tied' : sixA > sixB ? m.a_name : m.b_name;
    if (qu.auto_key === 'chase_won' && m.winner && m.result) ans = /wicket/i.test(m.result) ? 'Yes' : 'No';
    if (ans) { await resolveQuestion(qu.id, ans); settled++; }
  }
  await q(`UPDATE contests SET status = 'settled' WHERE match_id = $1`, [matchId]);
  // Fantasy
  const byPlayer: Record<string, any> = {};
  for (const s of stats) byPlayer[s.player_id] = s;
  const fts = await q<any>(`SELECT * FROM fantasy_teams WHERE match_id = $1`, [matchId]);
  for (const ft of fts) {
    let total = 0;
    for (const pid of ft.players as string[]) {
      const s = byPlayer[pid];
      if (!s) continue;
      let p = s.runs * FANTASY.pts.run + s.fours * FANTASY.pts.four + s.sixes * FANTASY.pts.six + s.wickets * FANTASY.pts.wicket + s.catches * FANTASY.pts.catch;
      if (pid === ft.captain) p *= 2;
      total += p;
    }
    await q(`UPDATE fantasy_teams SET points = $3 WHERE user_id = $1 AND match_id = $2`, [ft.user_id, matchId, total]);
    if (total > 0) await award(ft.user_id, total, `Fantasy 10: ${m.a_name} vs ${m.b_name}`, `f:${matchId}`);
  }
  return { settled, fantasy: fts.length };
}

export async function saveFantasy(userId: string, matchId: string, players: string[], captain: string) {
  const m = await one<any>(`SELECT * FROM matches WHERE id = $1`, [matchId]);
  if (!m) throw new Error('Match not found');
  if (m.status !== 'upcoming' || new Date(m.starts_at).getTime() <= Date.now()) throw new Error('Team selection has closed for this match');
  const uniq = Array.from(new Set(players));
  if (uniq.length !== FANTASY.size) throw new Error(`Pick exactly ${FANTASY.size} players`);
  if (!uniq.includes(captain)) throw new Error('Captain must be in your team');
  const rows = await q<any>(`SELECT id, team_id, credits FROM players WHERE id = ANY($1::text[])`, [uniq]);
  if (rows.length !== uniq.length) throw new Error('Unknown player');
  if (rows.some((r) => r.team_id !== m.team_a && r.team_id !== m.team_b)) throw new Error('Players must come from the two teams playing');
  const cost = rows.reduce((t, r) => t + Number(r.credits), 0);
  if (cost > FANTASY.budget) throw new Error(`Over budget: ${cost} of ${FANTASY.budget} credits`);
  for (const t of [m.team_a, m.team_b]) if (rows.filter((r) => r.team_id === t).length > FANTASY.maxPerTeam) throw new Error(`Max ${FANTASY.maxPerTeam} players from one team`);
  await q(
    `INSERT INTO fantasy_teams (user_id, match_id, players, captain) VALUES ($1,$2,$3::jsonb,$4)
     ON CONFLICT (user_id, match_id) DO UPDATE SET players = EXCLUDED.players, captain = EXCLUDED.captain, created_at = now()`,
    [userId, matchId, JSON.stringify(uniq), captain]
  );
  await award(userId, ENTRY_BONUS, 'Entered Fantasy 10', `fe:${matchId}`);
}

// Verifiable draw: winner index = sha256(seed + sorted entrant ids) mod N. Seed and entrant hash are published.
export async function runDraw(drawId: string) {
  const d = await one<any>(`SELECT * FROM draws WHERE id = $1`, [drawId]);
  if (!d || d.status !== 'open') throw new Error('Draw is not open');
  const es = await q<any>(`SELECT user_id FROM draw_entries WHERE draw_id = $1 ORDER BY user_id`, [drawId]);
  if (!es.length) throw new Error('No entries yet');
  const ids = es.map((e) => e.user_id);
  const seed = randomBytes(16).toString('hex');
  const entrantsHash = createHash('sha256').update(ids.join(',')).digest('hex');
  const pick = createHash('sha256').update(seed + entrantsHash).digest();
  const idx = pick.readUInt32BE(0) % ids.length;
  const winner = ids[idx];
  await q(`UPDATE draws SET status = 'drawn', winner_user_id = $2, seed = $3, entrants_hash = $4, drawn_at = now() WHERE id = $1`, [drawId, winner, seed, entrantsHash]);
  const w = await one<any>(`SELECT email, name FROM users WHERE id = $1`, [winner]);
  await q(
    `INSERT INTO approvals (id, kind, title, detail, payload, dedupe) VALUES ($1,'payout',$2,$3,$4::jsonb,$5) ON CONFLICT (dedupe) DO NOTHING`,
    [id('ap_'), `Fulfil prize: ${d.prize} to ${w?.name}`, `Draw "${d.title}". Winner email ${w?.email}. Seed ${seed}.`, JSON.stringify({ drawId, winner }), `payout:${drawId}`]
  );
  return { winner, seed, entrantsHash, entrants: ids.length };
}

export async function leaderboard(limit = 20, teamId?: string) {
  return q<any>(
    `SELECT u.id, u.name, u.avatar, u.team_id, t.short AS team_short, t.color AS team_color, COALESCE(sum(l.amount),0)::int AS pts
     FROM users u LEFT JOIN points_ledger l ON l.user_id = u.id LEFT JOIN teams t ON t.id = u.team_id
     ${teamId ? 'WHERE u.team_id = $2' : ''}
     GROUP BY u.id, t.short, t.color ORDER BY pts DESC, u.created_at ASC LIMIT $1`,
    teamId ? [limit, teamId] : [limit]
  );
}

export async function fanWars() {
  return q<any>(
    `SELECT t.id, t.name, t.short, t.color,
       COALESCE((SELECT sum(amount) FROM points_ledger l WHERE l.team_id = t.id),0)::int AS pts,
       (SELECT count(*) FROM users u WHERE u.team_id = t.id)::int AS fans
     FROM teams t ORDER BY pts DESC, fans DESC, t.sort`
  );
}
