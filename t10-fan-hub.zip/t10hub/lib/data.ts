import { q, one } from './db';

export async function teams() {
  return q<any>(`SELECT t.*, (SELECT count(*) FROM users u WHERE u.team_id = t.id)::int AS fans FROM teams t ORDER BY t.sort, t.name`);
}
export async function teamMap() {
  const ts = await teams();
  return Object.fromEntries(ts.map((t) => [t.id, t]));
}

const MATCH_SELECT = `SELECT m.*, a.name AS a_name, a.short AS a_short, a.color AS a_color, b.name AS b_name, b.short AS b_short, b.color AS b_color
  FROM matches m JOIN teams a ON a.id = m.team_a JOIN teams b ON b.id = m.team_b`;

export async function matches(filter: 'upcoming' | 'live' | 'completed' | 'all' = 'all', limit = 50, teamId?: string) {
  const where: string[] = [];
  const params: any[] = [limit];
  if (filter !== 'all') where.push(`m.status = '${filter}'`);
  if (teamId) { params.push(teamId); where.push(`(m.team_a = $2 OR m.team_b = $2)`); }
  const order = filter === 'completed' ? 'm.starts_at DESC' : 'm.starts_at ASC';
  return q<any>(`${MATCH_SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ${order} LIMIT $1`, params);
}
export async function match(id: string) {
  return one<any>(`${MATCH_SELECT} WHERE m.id = $1`, [id]);
}

export async function contests(opts: { status?: string[]; matchId?: string } = {}) {
  const params: any[] = [];
  const where: string[] = [];
  if (opts.status) { params.push(opts.status); where.push(`c.status = ANY($${params.length}::text[])`); }
  if (opts.matchId) { params.push(opts.matchId); where.push(`c.match_id = $${params.length}`); }
  return q<any>(
    `SELECT c.*, (SELECT count(DISTINCT e.user_id) FROM entries e WHERE e.contest_id = c.id)::int AS players,
       (SELECT count(*) FROM questions qq WHERE qq.contest_id = c.id)::int AS qcount, m.starts_at AS match_starts
     FROM contests c LEFT JOIN matches m ON m.id = c.match_id ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
     ORDER BY CASE c.status WHEN 'open' THEN 0 WHEN 'locked' THEN 1 ELSE 2 END, COALESCE(c.locks_at, now() + interval '100 days') ASC, c.created_at DESC`,
    params
  );
}

export async function feed(opts: { kind?: string[]; category?: string; teamId?: string | null; platform?: string; limit?: number } = {}) {
  const params: any[] = [];
  const where = [`f.status = 'live'`];
  if (opts.kind) { params.push(opts.kind); where.push(`f.kind = ANY($${params.length}::text[])`); }
  if (opts.category) { params.push(opts.category); where.push(`f.category = $${params.length}`); }
  if (opts.teamId === null) where.push(`f.team_id IS NULL AND f.kind <> 'news'`);
  else if (opts.teamId) { params.push(opts.teamId); where.push(`f.team_id = $${params.length}`); }
  if (opts.platform) { params.push(opts.platform); where.push(`f.platform = $${params.length}`); }
  params.push(opts.limit ?? 30);
  return q<any>(
    `SELECT f.*, t.name AS team_name, t.color AS team_color, t.short AS team_short FROM feed_items f LEFT JOIN teams t ON t.id = f.team_id
     WHERE ${where.join(' AND ')} ORDER BY f.published_at DESC LIMIT $${params.length}`,
    params
  );
}

export async function handles(status = 'verified') {
  return q<any>(`SELECT * FROM handles WHERE status = $1 ORDER BY team_id NULLS FIRST, platform`, [status]);
}

export async function draws() {
  return q<any>(
    `SELECT d.*, (SELECT count(*) FROM draw_entries e WHERE e.draw_id = d.id)::int AS entries, u.name AS winner_name
     FROM draws d LEFT JOIN users u ON u.id = d.winner_user_id ORDER BY CASE d.status WHEN 'open' THEN 0 ELSE 1 END, d.closes_at`
  );
}

export async function myEntries(userId: string) {
  return q<any>(
    `SELECT c.id, c.title, c.type, c.status, count(e.*)::int AS answered, COALESCE(sum(e.points),0)::int AS pts, max(e.created_at) AS at
     FROM entries e JOIN contests c ON c.id = e.contest_id WHERE e.user_id = $1 GROUP BY c.id ORDER BY at DESC LIMIT 30`,
    [userId]
  );
}
