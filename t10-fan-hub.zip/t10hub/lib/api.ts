import { NextResponse } from 'next/server';
import { getUser, User } from './auth';

export class HttpError extends Error { constructor(public status: number, msg: string) { super(msg); } }

export async function requireUser(): Promise<User> {
  const u = await getUser();
  if (!u) throw new HttpError(401, 'Sign in to continue');
  return u;
}
export async function requireAdmin(): Promise<User> {
  const u = await requireUser();
  if (!u.isAdmin) throw new HttpError(403, 'Admins only');
  return u;
}
export function handle(fn: (req: Request, ctx: any) => Promise<any>) {
  return async (req: Request, ctx: any) => {
    try {
      const r = await fn(req, ctx);
      return r instanceof Response ? r : NextResponse.json(r ?? { ok: true });
    } catch (e: any) {
      const status = e instanceof HttpError ? e.status : 400;
      if (!(e instanceof HttpError)) console.error(e);
      return NextResponse.json({ error: e.message || 'Something went wrong' }, { status });
    }
  };
}
