export const TZ = process.env.NEXT_PUBLIC_TZ || 'Asia/Dubai';

export function when(d: string | Date) {
  const dt = new Date(d);
  return dt.toLocaleString('en-GB', { timeZone: TZ, weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true }) + ' GST';
}
export function ago(d: string | Date) {
  const s = Math.max(1, Math.round((Date.now() - new Date(d).getTime()) / 1000));
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
}
export function until(d: string | Date) {
  const s = Math.round((new Date(d).getTime() - Date.now()) / 1000);
  if (s <= 0) return 'now';
  if (s < 3600) return `in ${Math.round(s / 60)}m`;
  if (s < 86400) return `in ${Math.round(s / 3600)}h`;
  return `in ${Math.round(s / 86400)}d`;
}
export function initials(name?: string | null) {
  return (name || '?').split(/[\s@._]+/).filter(Boolean).slice(0, 2).map((w) => w[0]!.toUpperCase()).join('');
}
export const TYPE_LABEL: Record<string, string> = {
  predictor: 'Match Predictor', sixes: 'Six Machine', duel: "Captain's Duel", season: 'Season Oracle', trivia: 'Quiz', fantasy: 'Fantasy 10',
};
