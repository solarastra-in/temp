// Transactional email via Resend (https://resend.com). Swap for SES/SendGrid if preferred.
export function emailConfigured() {
  return !!process.env.RESEND_API_KEY;
}

export async function sendEmail(to: string | string[], subject: string, html: string, text?: string) {
  if (!process.env.RESEND_API_KEY) {
    console.log(`[email:dev] to=${to} subject="${subject}"\n${text ?? html}`);
    return { ok: true, dev: true };
  }
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: process.env.EMAIL_FROM || 'T10 Fan Hub <no-reply@example.com>', to, subject, html, text }),
  });
  if (!res.ok) throw new Error(`Email send failed: ${res.status} ${await res.text()}`);
  return { ok: true };
}

export function otpEmail(code: string) {
  const text = `Your T10 Fan Hub code is ${code}. It expires in 10 minutes. If you did not ask for it, ignore this email.`;
  const html = `<div style="font-family:Arial,sans-serif;max-width:420px;margin:auto;padding:24px;background:#0E1318;color:#EEF2F5;border-radius:16px">
  <div style="font-size:22px;font-weight:800"><span style="color:#D8F24A">T10</span> FAN HUB</div>
  <p style="color:#C9D2DB">Your sign-in code:</p>
  <div style="font-size:36px;font-weight:800;letter-spacing:8px;color:#D8F24A">${code}</div>
  <p style="color:#9AA7B4;font-size:13px">Expires in 10 minutes. If you didn't ask for this, you can ignore it.</p></div>`;
  return { html, text };
}
