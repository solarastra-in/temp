// Idempotent schema. Statements are separated by ";\n".
export const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS users (
  id text PRIMARY KEY,
  email text UNIQUE NOT NULL,
  name text,
  avatar text,
  provider text NOT NULL DEFAULT 'email',
  team_id text,
  team_changes int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS otp_codes (
  id text PRIMARY KEY,
  email text NOT NULL,
  code_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  attempts int NOT NULL DEFAULT 0,
  used boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS otp_email_idx ON otp_codes(email, created_at);
CREATE TABLE IF NOT EXISTS teams (
  id text PRIMARY KEY,
  name text NOT NULL,
  short text NOT NULL,
  color text NOT NULL,
  home text,
  icon_player text,
  website text,
  note text,
  sort int NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS players (
  id text PRIMARY KEY,
  team_id text NOT NULL,
  name text NOT NULL,
  role text NOT NULL DEFAULT 'player',
  credits numeric NOT NULL DEFAULT 8,
  is_icon boolean NOT NULL DEFAULT false
);
CREATE TABLE IF NOT EXISTS handles (
  id text PRIMARY KEY,
  team_id text,
  platform text NOT NULL,
  handle text NOT NULL,
  url text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  source text NOT NULL DEFAULT 'seed',
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  found_at timestamptz NOT NULL DEFAULT now(),
  verified_at timestamptz,
  UNIQUE (url)
);
CREATE TABLE IF NOT EXISTS feed_items (
  id text PRIMARY KEY,
  team_id text,
  platform text NOT NULL,
  kind text NOT NULL,
  category text NOT NULL DEFAULT 'league',
  title text NOT NULL,
  url text NOT NULL,
  image text,
  source text,
  summary text,
  status text NOT NULL DEFAULT 'live',
  published_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS feed_pub_idx ON feed_items(published_at DESC);
CREATE TABLE IF NOT EXISTS matches (
  id text PRIMARY KEY,
  match_no int,
  stage text NOT NULL DEFAULT 'League',
  team_a text NOT NULL,
  team_b text NOT NULL,
  starts_at timestamptz NOT NULL,
  venue text DEFAULT 'Zayed Cricket Stadium, Abu Dhabi',
  status text NOT NULL DEFAULT 'upcoming',
  score_a text,
  score_b text,
  winner text,
  result text,
  total_sixes int,
  first_innings int,
  top_scorer text,
  top_wicket_taker text,
  external_id text UNIQUE,
  is_demo boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS player_stats (
  match_id text NOT NULL,
  player_id text NOT NULL,
  runs int NOT NULL DEFAULT 0,
  balls int NOT NULL DEFAULT 0,
  fours int NOT NULL DEFAULT 0,
  sixes int NOT NULL DEFAULT 0,
  wickets int NOT NULL DEFAULT 0,
  catches int NOT NULL DEFAULT 0,
  PRIMARY KEY (match_id, player_id)
);
CREATE TABLE IF NOT EXISTS contests (
  id text PRIMARY KEY,
  type text NOT NULL,
  title text NOT NULL,
  description text,
  match_id text,
  locks_at timestamptz,
  status text NOT NULL DEFAULT 'open',
  prize text,
  instant boolean NOT NULL DEFAULT false,
  created_by text NOT NULL DEFAULT 'agent',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS questions (
  id text PRIMARY KEY,
  contest_id text NOT NULL,
  prompt text NOT NULL,
  kind text NOT NULL DEFAULT 'choice',
  options jsonb NOT NULL DEFAULT '[]'::jsonb,
  points int NOT NULL DEFAULT 10,
  answer text,
  auto_key text,
  explain text,
  sort int NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS entries (
  user_id text NOT NULL,
  question_id text NOT NULL,
  contest_id text NOT NULL,
  answer text NOT NULL,
  points int,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, question_id)
);
CREATE TABLE IF NOT EXISTS fantasy_teams (
  user_id text NOT NULL,
  match_id text NOT NULL,
  players jsonb NOT NULL,
  captain text NOT NULL,
  points int,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, match_id)
);
CREATE TABLE IF NOT EXISTS draws (
  id text PRIMARY KEY,
  title text NOT NULL,
  prize text NOT NULL,
  rule text,
  color text NOT NULL DEFAULT '#D8F24A',
  closes_at timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'open',
  team_only text,
  winner_user_id text,
  seed text,
  entrants_hash text,
  drawn_at timestamptz
);
CREATE TABLE IF NOT EXISTS draw_entries (
  draw_id text NOT NULL,
  user_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (draw_id, user_id)
);
CREATE TABLE IF NOT EXISTS points_ledger (
  id text PRIMARY KEY,
  user_id text NOT NULL,
  team_id text,
  amount int NOT NULL,
  reason text NOT NULL,
  ref text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, ref)
);
CREATE TABLE IF NOT EXISTS agent_runs (
  id text PRIMARY KEY,
  agent text NOT NULL,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  status text NOT NULL DEFAULT 'running',
  summary text,
  items int NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS approvals (
  id text PRIMARY KEY,
  kind text NOT NULL,
  title text NOT NULL,
  detail text,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'pending',
  dedupe text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  decided_at timestamptz,
  decided_by text
);
CREATE TABLE IF NOT EXISTS kv (
  k text PRIMARY KEY,
  v jsonb NOT NULL
)
`;
