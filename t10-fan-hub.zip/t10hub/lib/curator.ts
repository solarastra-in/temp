// Curator.io integration (https://curator.io).
// - CURATOR_FEED_ID: the feed's public key. Powers the embedded wall and the posts sync.
// - CURATOR_API_KEY: private API key. Lets the agents register every verified team handle
//   as a Curator source automatically, so new handles start broadcasting without manual setup.
// - CURATOR_HASHTAGS: optional, comma-separated (e.g. "AbuDhabiT10,T10League") to add fan posts.
import { q, one } from './db';
import { fetchText, hashId } from './agents/util';

const API = 'https://api.curator.io/v1';

export function curatorFeedId() { return process.env.CURATOR_FEED_ID || ''; }
export function curatorConfigured() { return !!process.env.CURATOR_FEED_ID; }
export function curatorContainerId() { return process.env.CURATOR_CONTAINER_ID || 'curator-feed-default-feed-layout'; }

// Curator source types (https://curator.io/docs/api/misc)
const SOURCE_TYPE: Record<string, number> = { X: 3, Instagram: 33, Facebook: 5, YouTube: 13 };
const HASHTAG_TYPES = [1, 38, 57]; // Twitter tag, Instagram business tag, TikTok hashtag

function authHeader(): Record<string, string> {
  return { Authorization: 'Basic ' + Buffer.from(`${process.env.CURATOR_API_KEY}:`).toString('base64'), 'Content-Type': 'application/json' };
}

function tagFor(h: any): string | null {
  const u = h.url as string;
  if (h.platform === 'X' || h.platform === 'Instagram') return h.handle.replace(/^@/, '');
  if (h.platform === 'Facebook') return u.replace(/\/+$/, '').split('/').pop() || null;
  if (h.platform === 'YouTube') return h.meta?.channelId || u.match(/channel\/(UC[\w-]{22})/)?.[1] || h.handle.replace(/^@/, '');
  return null;
}

// Register verified handles (and hashtags) as sources on the Curator feed.
export async function syncCuratorSources() {
  const notes: string[] = [];
  if (!process.env.CURATOR_API_KEY || !process.env.CURATOR_FEED_UUID) {
    return { added: 0, notes: ['source sync skipped (set CURATOR_API_KEY and CURATOR_FEED_UUID, or add sources in the Curator dashboard)'] };
  }
  const feed = process.env.CURATOR_FEED_UUID;
  const existing = JSON.parse(await fetchText(`${API}/sources?feed_id=${feed}`, 15000, authHeader()));
  const have = new Set<string>((existing.data || existing.sources || []).map((s: any) => `${s.source_type_id ?? s.source_type}:${String(s.tag ?? s.value ?? '').toLowerCase()}`));
  const want: { type: number; tag: string; handleId?: string }[] = [];
  for (const h of await q<any>(`SELECT * FROM handles WHERE status = 'verified'`)) {
    const type = SOURCE_TYPE[h.platform];
    const tag = tagFor(h);
    if (!type || !tag) { if (h.platform === 'TikTok') notes.push(`TikTok ${h.handle}: add as a source in the Curator dashboard`); continue; }
    want.push({ type, tag, handleId: h.id });
  }
  for (const t of (process.env.CURATOR_HASHTAGS || '').split(',').map((s) => s.trim().replace(/^#/, '')).filter(Boolean)) {
    for (const type of HASHTAG_TYPES) want.push({ type, tag: t });
  }
  let added = 0;
  for (const w of want) {
    if (have.has(`${w.type}:${w.tag.toLowerCase()}`)) continue;
    const res = await fetch(`${API}/sources`, { method: 'POST', headers: authHeader(), body: JSON.stringify({ feed_id: feed, source_type: w.type, tag: w.tag }) });
    const body = await res.json().catch(() => ({}));
    if (!res.ok || body.success === false) { notes.push(`source ${w.tag}: ${body.error || res.status}`); continue; }
    added++;
    const sid = body.source?.id || body.data?.id || body.id;
    if (sid && w.handleId) await q(`UPDATE handles SET meta = meta || $2::jsonb WHERE id = $1`, [w.handleId, JSON.stringify({ curatorSourceId: sid })]);
  }
  return { added, notes };
}

// Pull approved posts from the Curator feed into the hub's own feed, matched to teams.
export async function syncCuratorPosts() {
  const feed = curatorFeedId();
  if (!feed) return { added: 0, notes: ['Curator not configured'] };
  const handles = await q<any>(`SELECT * FROM handles WHERE status = 'verified'`);
  const bySource = new Map<string, any>();
  const byName = new Map<string, any>();
  for (const h of handles) {
    if (h.meta?.curatorSourceId) bySource.set(h.meta.curatorSourceId, h);
    byName.set(`${h.platform}:${h.handle.replace(/^@/, '').toLowerCase()}`, h);
    byName.set(`any:${h.handle.replace(/^@/, '').toLowerCase()}`, h);
  }
  const PLATFORM: Record<string, string> = { Twitter: 'X', X: 'X', Instagram: 'Instagram', Facebook: 'Facebook', YouTube: 'YouTube', TikTok: 'TikTok', RSS: 'Web' };
  let added = 0;
  let offset = 0;
  for (let page = 0; page < 3; page++) {
    const d = JSON.parse(await fetchText(`${API}/feeds/${feed}/posts?limit=100&offset=${offset}`));
    const posts: any[] = d.posts || d.data || [];
    for (const p of posts) {
      if (p.post_status && p.post_status !== 'approved') continue;
      const platform = PLATFORM[p.network_name] || p.network_name || 'Social';
      const screen = String(p.user_screen_name || '').replace(/^@/, '').toLowerCase();
      const h = bySource.get(p.source_id) || byName.get(`${platform}:${screen}`) || byName.get(`any:${screen}`);
      const url = p.url || `https://curator.io/post/${p.id}`;
      const text = String(p.text || '').replace(/\s+/g, ' ').trim();
      const r = await q(
        `INSERT INTO feed_items (id, team_id, platform, kind, category, title, url, image, source, summary, published_at)
         VALUES ($1,$2,$3,$4,'social',$5,$6,$7,$8,$9,$10)
         ON CONFLICT (id) DO UPDATE SET team_id = COALESCE(feed_items.team_id, EXCLUDED.team_id), image = COALESCE(EXCLUDED.image, feed_items.image) RETURNING (xmax::text = '0') AS inserted`,
        [hashId(url), h?.team_id ?? null, platform, p.video || platform === 'YouTube' || platform === 'TikTok' ? 'video' : 'post',
          (text.split(/(?<=[.!?])\s/)[0] || `New post from @${screen}`).slice(0, 200), url, p.image || null,
          p.user_screen_name ? `@${String(p.user_screen_name).replace(/^@/, '')}` : 'Curator', text.slice(0, 280),
          p.source_created_at && !isNaN(Date.parse(p.source_created_at)) ? new Date(p.source_created_at).toISOString() : new Date().toISOString()]
      );
      if (r[0]?.inserted) added++;
    }
    if (posts.length < 100) break;
    offset += 100;
  }
  await q(`INSERT INTO kv (k, v) VALUES ('curator:lastSync', to_jsonb(now()::text)) ON CONFLICT (k) DO UPDATE SET v = EXCLUDED.v`);
  return { added, notes: [] as string[] };
}

export async function curatorLastSync() {
  const r = await one<any>(`SELECT v FROM kv WHERE k = 'curator:lastSync'`);
  return r?.v ? String(r.v) : null;
}
