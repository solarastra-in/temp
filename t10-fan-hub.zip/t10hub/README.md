# T10 Fan Hub

A multi-user fan platform for the Abu Dhabi T10 league that mostly runs itself. Anyone can browse. Signing in (Google, or an emailed 6-digit code) is needed to pick a team, enter competitions and join draws. Six agents keep the content, contests and results up to date. You only step in for items in the approval queue.

## What's in it

| Area | What fans get |
|---|---|
| Browse (no sign-in) | Home, matches, match centre and scorecards, teams and squads, Social Hub, news, leaderboards, draws, rules |
| Sign-in | Google OAuth, or an email one-time code (10-minute expiry, 5 attempts, rate-limited, hashed at rest) |
| Choose your team | Backing a team makes your points count for it in Fan Wars. You can switch once per season. |
| Competitions | Match Predictor, Six Machine, Captain's Duel, Fantasy 10 (6 players, 55 credits, captain 2x), Season Oracle, History Quiz (instant answers), Prize Draws (verifiable seed), Fan Wars, daily check-in streaks, badges |
| Admin (`/admin`) | Agent status and "run now", approval queue, fixtures, manual results, draws, manual handles, connection status, demo data |

## The agents

| Agent | What it does | What it needs |
|---|---|---|
| **Discovery** | Crawls the league sites and each team's official website for social links, and matches them to teams. Links from a team's own site are trusted. Other finds go to your approval queue. With a Claude key it also web-searches for any missing platforms and team websites. | Nothing for crawling. `ANTHROPIC_API_KEY` for web search. |
| **Social** | Pulls the latest post and video links from every verified handle. | YouTube works with no key. X needs `X_BEARER_TOKEN`. Instagram needs `IG_ACCESS_TOKEN` + `IG_BUSINESS_ID`. TikTok and Facebook are shown as profile links. |
| **Curator.io** (inside Social) | Shows one moderated live wall of every team's and the league's posts on `/social`, and on the home page until synced posts arrive. Also copies Curator's approved posts into the hub's own feed, matched to teams, so Instagram, TikTok and Facebook posts appear on team pages and filters too. With the private key it registers every newly verified handle and fan hashtag as a Curator source automatically. | `CURATOR_FEED_ID`, plus optionally `CURATOR_FEED_UUID` and `CURATOR_API_KEY` |
| **News** | Headlines and links (never full articles) from abudhabit10.com press releases, Google News for "Abu Dhabi T10", ESPNcricinfo and BBC cricket. You can change the sources with `NEWS_FEEDS`. | Nothing |
| **Scores** | Syncs fixtures, live scores and scorecards. Adds new players to squads, sends unknown teams for approval, and settles every contest and fantasy team when a match ends. | `CRICAPI_KEY` from cricketdata.org |
| **Content** | Creates the three contests for every new fixture, locks them at the first ball and writes match previews. Claude-written previews wait for approval. | Optional `ANTHROPIC_API_KEY` |
| **Ops** | Watches the other agents and the handles, and emails admins a digest (at most every 12 hours) when something needs a human. | `RESEND_API_KEY` |

If a key is missing, that agent skips the step and says so in the admin console. Nothing breaks.

## Run it locally

```bash
npm install
cp .env.example .env.local        # set ADMIN_EMAILS to your email
npm run dev                        # http://localhost:3000
```

Locally it uses a built-in database in `./.data`, so no setup is needed. Without an email provider, the sign-in code is shown on screen, in development only. Sign in with your admin email, open **Admin → Add demo data** to get sample fixtures, and try every competition. Use **Simulate** to settle a match.

`npm test` runs the agent tests offline with mocked sites. They cover crawl → approve → feed, and fixture → contests → scorecard → auto-settlement.

## Deploy (Vercel + Supabase, about 30 minutes)

1. **Database:** create a Supabase (or Neon) project and copy the Postgres connection string into `DATABASE_URL`. Tables and the base seed are created on first request.
2. **Google sign-in:** Google Cloud Console → APIs & Services → Credentials → OAuth client (Web). Add the authorised redirect URI `https://YOUR_DOMAIN/api/auth/google/callback`. Set `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`.
3. **Email codes:** create a Resend account, verify your domain, and set `RESEND_API_KEY` and `EMAIL_FROM`.
4. **Secrets:** set `AUTH_SECRET` (`openssl rand -base64 32`), `CRON_SECRET`, `APP_URL` and `ADMIN_EMAILS`.
5. **Data:** set `CRICAPI_KEY` (cricketdata.org) for live scores. `ANTHROPIC_API_KEY` is optional; it enables web search for handles and written previews.
6. **Deploy:** push to GitHub, import the repo in Vercel, and add the environment variables.
7. **Schedule:** `vercel.json` runs all agents daily. For every 30 minutes during the season, add the repository secrets `APP_URL` and `CRON_SECRET` on GitHub, and `.github/workflows/agents.yml` does the rest.

## Curator.io setup (about 10 minutes)

1. Sign up at curator.io and create a feed, for example "ADT10 Teams".
2. Connect the social accounts Curator asks for. Instagram business accounts and Facebook pages need a one-time login by each account's owner or admin. X, YouTube and hashtags don't.
3. Click **Publish / Get code**. The embed code contains `cdn.curator.io/published/<FEED_ID>.js` and `<div id="curator-feed-…">`. Set `CURATOR_FEED_ID` to that ID and `CURATOR_CONTAINER_ID` to the div id.
4. Optional, for no manual source upkeep: copy the feed's UUID and your private API key (Curator → Settings → API) into `CURATOR_FEED_UUID` and `CURATOR_API_KEY`. Each Social agent run then adds every verified team handle as a source: X users, Instagram business accounts, Facebook pages, YouTube channels, plus `CURATOR_HASHTAGS`. Curator's API can't add TikTok user accounts, so add those once in the dashboard. The admin log lists which ones.
5. Choose the wall's layout and colours, and turn on moderation or profanity filters, in the Curator dashboard. The hub only copies posts Curator has approved.

Pricing: Curator's free plan is small, with a few sources and a Curator badge. Nine teams across 4–5 networks each needs a paid plan, so check curator.io/pricing.

## Before launch

- **Rights:** get written OK from the league (ASHRA / T10 Sports) to use its marks and taglines, other teams' names and logos, and official data. The hub links to, rather than copies, other sites' articles and posts.
- **Prizes:** all competitions are free to play. If prizes will be offered in the UAE, check whether promotional draws need a permit (for example from the Department of Economic Development) and put the prize terms in `/rules`.
- **2026 data:** squads are seeded from the 2025 post-draft lists, with Arabian Aces added (Moeen Ali, head coach Lance Klusener). Once fixtures are live, the Scores agent updates squads from scorecards.
- **Privacy:** add a privacy policy page before collecting emails at scale.
