// Offline tests for the agents: mocks the network and runs each agent against a fresh database.
process.env.PGLITE_DIR = './.data/test-' + Date.now();
process.env.CRICAPI_KEY = 'test';
process.env.CURATOR_FEED_ID = 'pubkey123'; process.env.CURATOR_FEED_UUID = 'feed-uuid'; process.env.CURATOR_API_KEY = 'priv'; process.env.CURATOR_HASHTAGS = 'AbuDhabiT10';
import assert from 'node:assert/strict';

const YT_ATOM = `<?xml version="1.0"?><feed xmlns:media="http://search.yahoo.com/mrss/"><entry><id>yt:video:abc12345678</id><title>Match 1 highlights | T10</title><link rel="alternate" href="https://www.youtube.com/watch?v=abc12345678"/><published>2026-11-18T10:00:00+00:00</published><media:group><media:thumbnail url="https://i.ytimg.com/vi/abc12345678/hqdefault.jpg"/><media:description>Every six from match 1</media:description></media:group></entry></feed>`;
const GNEWS = `<rss><channel><item><title>Arabian Aces unveil Moeen Ali as icon for Abu Dhabi T10 - Gulf News</title><link>https://news.example.com/aces-moeen</link><pubDate>Wed, 23 Sep 2026 08:00:00 GMT</pubDate><description>&lt;a href="x"&gt;Aces&lt;/a&gt; news</description><source url="https://gulfnews.com">Gulf News</source></item><item><title>Unrelated football story</title><link>https://news.example.com/football</link></item></channel></rss>`;
const CRICINFO = `<rss><channel><item><title><![CDATA[England name squad for Ashes]]></title><link>https://www.espncricinfo.com/story/1</link><pubDate>Wed, 23 Sep 2026 09:00:00 GMT</pubDate><description>Squad news</description></item></channel></rss>`;
const LEAGUE_HTML = `<html><footer><a href="https://www.instagram.com/t10league/">IG</a><a href="https://x.com/T10League">X</a>
  <a href="https://www.instagram.com/arabianaces.t10/">Aces</a><a href="https://twitter.com/intent/tweet?text=hi">share</a><a href="https://www.instagram.com/p/XYZ123/">post</a>
  <a href="https://www.youtube.com/@T10LeagueOfficial">YT</a></footer></html>`;
const TEAM_HTML = `<a href="https://www.facebook.com/deccangladiators/">fb</a><a href="https://www.youtube.com/@DeccanGladiatorsOfficial">yt</a><a href="https://www.tiktok.com/@deccangladiators">tt</a><a href="https://www.facebook.com/sharer/sharer.php?u=x">share</a>`;
const RELEASES = `<a href="/release/aces-join-league">Arabian Aces join the Abu Dhabi T10 for 2026 season</a><a href="/privacy">Privacy policy and cookie notice</a>`;
const CHANNEL_PAGE = `<script>var x = {"channelId":"UCabcdefghijklmnopqrstuv"}</script>`;

const series = { status: 'success', data: [{ id: 'S1', name: 'Abu Dhabi T10 2026', startDate: '2026-11-18' }] };
const seriesInfo = { status: 'success', data: { matchList: [
  { id: 'M1', name: 'Arabian Aces vs Deccan Gladiators, 1st Match', teams: ['Arabian Aces', 'Deccan Gladiators'], dateTimeGMT: '2026-11-18T14:00:00', venue: 'Zayed Cricket Stadium', matchStarted: true, matchEnded: true, status: 'Arabian Aces won by 4 wickets',
    score: [{ r: 121, w: 5, o: 10, inning: 'Deccan Gladiators Inning 1' }, { r: 124, w: 6, o: 9.3, inning: 'Arabian Aces Inning 1' }] },
  { id: 'M2', name: 'UAE Bulls vs Northern Warriors, 2nd Match', teams: ['UAE Bulls', 'Northern Warriors'], dateTimeGMT: '2099-11-19T14:00:00', matchStarted: false, matchEnded: false, status: 'Match not started', score: [] },
  { id: 'M3', name: 'Mystery XI vs UAE Bulls, 3rd Match', teams: ['Mystery XI', 'UAE Bulls'], dateTimeGMT: '2099-11-20T14:00:00', matchStarted: false, matchEnded: false, score: [] },
] } };
const scorecard = { status: 'success', data: { matchWinner: 'Arabian Aces', status: 'Arabian Aces won by 4 wickets', scorecard: [
  { inning: 'Deccan Gladiators Inning 1', batting: [{ batsman: { name: 'Nicholas Pooran' }, r: 48, b: 20, '4s': 2, '6s': 5 }, { batsman: { name: 'Andre Russell' }, r: 30, b: 12, '4s': 1, '6s': 3 }],
    bowling: [{ bowler: { name: 'Moeen Ali' }, w: 2 }], catching: [{ catcher: { name: 'Moeen Ali' }, catch: 1 }] },
  { inning: 'Arabian Aces Inning 1', batting: [{ batsman: { name: 'Moeen Ali' }, r: 61, b: 25, '4s': 4, '6s': 6 }, { batsman: { name: 'Brand New Player' }, r: 20, b: 10, '4s': 1, '6s': 1 }],
    bowling: [{ bowler: { name: 'Andre Russell' }, w: 3 }], catching: [] },
] } };

const curatorPosts = { success: true, posts: [
  { id: 1, text: 'Pooran lighting it up in the nets! Big night ahead.', image: 'https://img.example/ig1.jpg', url: 'https://www.instagram.com/p/AAA111/', network_name: 'Instagram', user_screen_name: 'deccangladiators', source_created_at: '2026-11-17T10:00:00Z', source_id: 'src-x', post_status: 'approved' },
  { id: 2, text: 'Matchday energy', url: 'https://www.tiktok.com/@abudhabit10/video/123', network_name: 'TikTok', user_screen_name: 'abudhabit10', source_created_at: '2026-11-17T11:00:00Z', post_status: 'approved', video: 'x' },
  { id: 3, text: 'spam', url: 'https://x.com/spam/status/1', network_name: 'Twitter', user_screen_name: 'spam', post_status: 'rejected' },
] };
const curatorCalls: any[] = [];
const routes: [RegExp, string | (() => string)][] = [
  [/abudhabit10\.com\/release/, RELEASES], [/abudhabit10\.com\/?$/, LEAGUE_HTML], [/ttensports/, '<html></html>'], [/deccangladiators\.com/, TEAM_HTML],
  [/news\.google\.com/, GNEWS], [/espncricinfo/, CRICINFO], [/bbci/, '<rss></rss>'],
  [/youtube\.com\/feeds/, YT_ATOM], [/youtube\.com\/@/, CHANNEL_PAGE],
  [/cricapi\.com\/v1\/series_info/, () => JSON.stringify(seriesInfo)], [/cricapi\.com\/v1\/series\?/, JSON.stringify(series)], [/cricapi\.com\/v1\/match_scorecard/, JSON.stringify(scorecard)],
];
(globalThis as any).fetch = async (url: string, init?: any) => {
  if (/api\.curator\.io\/v1\/sources/.test(String(url))) {
    if (init?.method === 'POST') { curatorCalls.push(JSON.parse(init.body)); return new Response(JSON.stringify({ success: true, source: { id: 'src-' + curatorCalls.length } }), { status: 200 }); }
    return new Response(JSON.stringify({ success: true, data: [{ source_type_id: 3, tag: 'T10League' }] }), { status: 200 });
  }
  if (/api\.curator\.io\/v1\/feeds\/pubkey123\/posts/.test(String(url))) return new Response(JSON.stringify(curatorPosts), { status: 200 });
  const hit = routes.find(([re]) => re.test(String(url)));
  if (!hit) return new Response('not found', { status: 404, statusText: 'Not Found' });
  return new Response(typeof hit[1] === 'function' ? hit[1]() : hit[1], { status: 200 });
};

(async () => {
  const { q } = await import('../lib/db');
  const { runNamed } = await import('../lib/agents');
  const { extractSocialLinks, parseFeed } = await import('../lib/agents/util');

  // Parsers
  const links = extractSocialLinks(LEAGUE_HTML);
  assert.deepEqual(links.map((l) => l.url).sort(), ['https://www.instagram.com/arabianaces.t10/', 'https://www.instagram.com/t10league/', 'https://www.youtube.com/@T10LeagueOfficial', 'https://x.com/T10League'].sort());
  assert.equal(parseFeed(YT_ATOM)[0].link, 'https://www.youtube.com/watch?v=abc12345678');
  assert.equal(parseFeed(CRICINFO)[0].title, 'England name squad for Ashes');
  console.log('✓ parsers');

  // Discovery
  let r: any = await runNamed('discovery');
  assert.ok(r.ok, r.summary);
  const aces = await q<any>(`SELECT * FROM handles WHERE url = 'https://www.instagram.com/arabianaces.t10/'`);
  assert.equal(aces[0].status, 'pending'); assert.equal(aces[0].team_id, 'aces');
  const dg = await q<any>(`SELECT platform, status FROM handles WHERE team_id = 'deccan' ORDER BY platform`);
  assert.ok(dg.some((h) => h.platform === 'TikTok' && h.status === 'verified'), 'team-site links auto-verified');
  assert.ok(!dg.some((h) => /sharer/.test(h.platform)));
  const ap = await q<any>(`SELECT * FROM approvals WHERE kind = 'handle'`);
  assert.equal(ap.length, 1);
  console.log('✓ discovery:', r.summary.slice(0, 120));

  // Social
  r = await runNamed('social');
  const vids = await q<any>(`SELECT * FROM feed_items WHERE kind = 'video'`);
  assert.ok(vids.length >= 1, r.summary);
  console.log('✓ social:', r.summary.slice(0, 200));
  assert.ok(curatorCalls.some((c) => c.source_type === 33 && c.tag === 'deccangladiators'), 'IG business source registered');
  assert.ok(!curatorCalls.some((c) => c.source_type === 3 && c.tag === 'T10League'), 'existing source not duplicated');
  assert.ok(curatorCalls.some((c) => c.source_type === 57 && c.tag === 'AbuDhabiT10'), 'hashtag registered');
  const cp = await q<any>(`SELECT platform, team_id, kind FROM feed_items WHERE url LIKE '%instagram.com/p/AAA111%' OR url LIKE '%tiktok%' OR url LIKE '%spam%' ORDER BY platform`);
  assert.deepEqual(cp, [{ platform: 'Instagram', team_id: 'deccan', kind: 'post' }, { platform: 'TikTok', team_id: null, kind: 'video' }]);
  console.log('✓ curator: sources registered', curatorCalls.length, '· posts mapped to teams');

  // News
  r = await runNamed('news');
  const news = await q<any>(`SELECT title, category, source FROM feed_items WHERE kind = 'news' ORDER BY title`);
  assert.ok(news.find((n) => n.title.startsWith('Arabian Aces unveil') && n.category === 'league' && n.source === 'Gulf News'), JSON.stringify(news));
  assert.ok(!news.find((n) => /football/i.test(n.title)));
  assert.ok(news.find((n) => n.category === 'cricket'));
  assert.ok(news.find((n) => n.title.startsWith('Arabian Aces join')));
  assert.ok(!news.find((n) => /Privacy/.test(n.title)));
  console.log('✓ news:', r.summary.slice(0, 160));

  // Scores: a user predicts M1 before it is imported as complete. Import once as upcoming first.
  seriesInfo.data.matchList[0].matchEnded = false; seriesInfo.data.matchList[0].matchStarted = false; seriesInfo.data.matchList[0].dateTimeGMT = '2099-01-01T00:00:00';
  r = await runNamed('scores');
  assert.ok(r.ok, r.summary);
  const m1 = (await q<any>(`SELECT * FROM matches WHERE external_id = 'M1'`))[0];
  const cs = await q<any>(`SELECT id FROM contests WHERE match_id = $1`, [m1.id]);
  if (cs.length !== 3) console.log("DEBUG", r.summary, await q(`SELECT id, status, starts_at, team_a, team_b FROM matches`), await q(`SELECT id, match_id FROM contests`));
  assert.equal(cs.length, 3);
  await q(`INSERT INTO users (id, email, team_id) VALUES ('u1','u1@test','aces')`);
  const { submitEntries } = await import('../lib/game');
  await submitEntries('u1', `pred-${m1.id}`, { [`pred-${m1.id}-q0`]: 'Arabian Aces', [`pred-${m1.id}-q1`]: 'Moeen Ali', [`pred-${m1.id}-q2`]: '120 to 139' });
  await submitEntries('u1', `sixes-${m1.id}`, { [`sixes-${m1.id}-q0`]: '12 to 15' });
  await submitEntries('u1', `duel-${m1.id}`, { [`duel-${m1.id}-q0`]: 'Arabian Aces', [`duel-${m1.id}-q1`]: 'Yes' });
  // Now the match finishes.
  Object.assign(seriesInfo.data.matchList[0], { matchEnded: true, matchStarted: true });
  r = await runNamed('scores');
  assert.ok(r.ok, r.summary);
  const done = (await q<any>(`SELECT * FROM matches WHERE external_id = 'M1'`))[0];
  assert.equal(done.status, 'completed'); assert.equal(done.winner, 'aces'); assert.equal(done.top_scorer, 'Moeen Ali'); assert.equal(done.total_sixes, 15);
  assert.equal(done.score_a, '124/6 (9.3)'); assert.equal(done.score_b, '121/5 (10)');
  const newbie = await q<any>(`SELECT * FROM players WHERE name = 'Brand New Player'`);
  assert.equal(newbie[0].team_id, 'aces');
  const pts = await q<any>(`SELECT reason, amount FROM points_ledger WHERE user_id = 'u1' ORDER BY reason`);
  const total = pts.reduce((t, p) => t + p.amount, 0);
  // entry bonuses 3x5 + winner 20 + top scorer 30 + total 121 -> '120 to 139' 25 + sixes 15 -> '12 to 15' 30 + more sixes (Aces 7 vs DG 8 -> DG) 0 + chase won 'Yes' 15
  assert.equal(total, 15 + 20 + 30 + 25 + 30 + 15, JSON.stringify(pts));
  const unknown = await q<any>(`SELECT * FROM approvals WHERE kind = 'team'`);
  assert.equal(unknown.length, 1);
  console.log('✓ scores + auto-settlement:', r.summary, `user scored ${total}`);

  r = await runNamed('content');
  console.log('✓ content:', r.summary);
  r = await runNamed('ops');
  console.log('✓ ops:', r.summary);
  console.log('ALL AGENT TESTS PASSED');
  process.exit(0);
})().catch((e) => { console.error('FAILED', e); process.exit(1); });
