import { matches } from '@/lib/data';
import { MatchCard, Empty } from '@/components/Cards';

export default async function Matches() {
  const [live, up, done] = await Promise.all([matches('live'), matches('upcoming'), matches('completed')]);
  return (
    <>
      <h1 className="display" style={{ fontSize: 52 }}>MATCHES</h1>
      {live.length ? <><div className="section-title"><h2>Live</h2></div><div className="grid g4">{live.map((m) => <MatchCard key={m.id} m={m} />)}</div></> : null}
      <div className="section-title"><h2>Upcoming</h2></div>
      {up.length ? <div className="grid g4">{up.map((m) => <MatchCard key={m.id} m={m} />)}</div> : <Empty>Fixtures appear here as soon as they are published.</Empty>}
      <div className="section-title"><h2>Results</h2></div>
      {done.length ? <div className="grid g4">{done.map((m) => <MatchCard key={m.id} m={m} />)}</div> : <Empty>No results yet.</Empty>}
    </>
  );
}
