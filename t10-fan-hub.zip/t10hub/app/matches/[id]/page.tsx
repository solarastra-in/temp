import Link from 'next/link';
import { notFound } from 'next/navigation';
import { q, one } from '@/lib/db';
import { match, contests } from '@/lib/data';
import { ContestCard } from '@/components/Cards';
import { when } from '@/lib/format';
import { hashId } from '@/lib/agents/util';

export default async function MatchPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const m = await match(id);
  if (!m) notFound();
  const [cs, stats, preview] = await Promise.all([
    contests({ matchId: id }),
    q<any>(`SELECT ps.*, p.name, p.team_id FROM player_stats ps JOIN players p ON p.id = ps.player_id WHERE ps.match_id = $1 ORDER BY ps.runs DESC, ps.wickets DESC`, [id]),
    one<any>(`SELECT * FROM feed_items WHERE id = $1 AND status = 'live'`, [hashId(`/matches/${id}#preview`)]),
  ]);
  return (
    <div className="stack" style={{ gap: 20 }}>
      <Link href="/matches" className="small">&larr; All matches</Link>
      <section className="card stack">
        <div className="row wrap-row small muted">
          {m.status === 'live' ? <span className="pill live">LIVE</span> : <span className="pill">{m.status === 'completed' ? 'Result' : 'Upcoming'}</span>}
          <span>{m.stage}{m.match_no ? ` · Match ${m.match_no}` : ''} · {m.venue}</span>
          {m.is_demo && <span className="pill dash">demo fixture</span>}
        </div>
        <div className="grid g2">
          {(['a', 'b'] as const).map((k) => (
            <div key={k} className="stack" style={{ gap: 4, alignItems: k === 'b' ? 'flex-end' : 'flex-start' }}>
              <div className="row"><span className="dot" style={{ background: m[`${k}_color`] }} /><Link href={`/teams/${m[`team_${k}`]}`} style={{ color: 'var(--text)', fontWeight: 800, fontSize: 18 }}>{m[`${k}_name`]}</Link></div>
              <div className="score" style={{ color: m.winner === m[`team_${k}`] ? 'var(--lime)' : undefined }}>{m[`score_${k}`] || '—'}</div>
            </div>
          ))}
        </div>
        <div className="small soft">{m.status === 'completed' ? m.result : when(m.starts_at)}</div>
        {m.status === 'upcoming' && <div className="row wrap-row"><Link className="btn" href={`/fantasy/${m.id}`}>Build your Fantasy 10</Link><Link className="btn ghost" href={`/play/pred-${m.id}`}>Match Predictor</Link></div>}
      </section>
      {preview && <section className="card stack"><span className="pill" style={{ alignSelf: 'flex-start' }}>Preview</span><div className="soft">{preview.summary}</div></section>}
      <div className="grid g3">{cs.map((c) => <ContestCard key={c.id} c={c} />)}</div>
      {stats.length ? (
        <section className="card stack scroll-x">
          <h2>Scorecard</h2>
          <table className="t">
            <thead><tr><th>Player</th><th>R</th><th>B</th><th>4s</th><th>6s</th><th>W</th><th>Ct</th></tr></thead>
            <tbody>{stats.map((s) => (
              <tr key={s.player_id}><td><span className="dot" style={{ background: s.team_id === m.team_a ? m.a_color : m.b_color, marginRight: 8 }} />{s.name}</td><td><b>{s.runs}</b></td><td>{s.balls}</td><td>{s.fours}</td><td>{s.sixes}</td><td>{s.wickets}</td><td>{s.catches}</td></tr>
            ))}</tbody>
          </table>
        </section>
      ) : null}
    </div>
  );
}
