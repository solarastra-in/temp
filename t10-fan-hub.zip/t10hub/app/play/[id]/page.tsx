import Link from 'next/link';
import { notFound } from 'next/navigation';
import { q, one } from '@/lib/db';
import { getUser } from '@/lib/auth';
import { contestLocked } from '@/lib/game';
import { TYPE_LABEL, when } from '@/lib/format';
import ContestForm from '@/components/ContestForm';

export default async function ContestPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const c = await one<any>(`SELECT * FROM contests WHERE id = $1`, [id]);
  if (!c) notFound();
  const user = await getUser();
  const qs = await q<any>(`SELECT id, prompt, kind, options, points, answer, explain FROM questions WHERE contest_id = $1 ORDER BY sort`, [id]);
  const mine = user ? await q<any>(`SELECT question_id, answer, points FROM entries WHERE user_id = $1 AND contest_id = $2`, [user.id, id]) : [];
  const players = await one<any>(`SELECT count(DISTINCT user_id)::int AS n FROM entries WHERE contest_id = $1`, [id]);
  const locked = contestLocked(c);
  const mineMap = Object.fromEntries(mine.map((m) => [m.question_id, m]));
  // Only reveal answers that are settled, or instant answers the user has already given.
  const safe = qs.map((x) => {
    const reveal = c.status === 'settled' || (c.instant && mineMap[x.id]) || (!c.instant && x.answer);
    return { id: x.id, prompt: x.prompt, options: x.options, points: x.points, answer: reveal ? x.answer : null, explain: reveal ? x.explain : null };
  });
  const total = mine.reduce((t, m) => t + (m.points || 0), 0);
  return (
    <div style={{ maxWidth: 820, margin: '0 auto' }} className="stack">
      <Link href="/play" className="small">&larr; All competitions</Link>
      <div className="row wrap-row"><span className="pill lime">{TYPE_LABEL[c.type] || c.type}</span>{c.prize && <span className="pill">{c.prize}</span>}<span className="pill">{players?.n ?? 0} playing</span></div>
      <h1 className="display" style={{ fontSize: 44, lineHeight: 1 }}>{c.title.toUpperCase()}</h1>
      <p className="soft" style={{ margin: 0 }}>{c.description}</p>
      <div className="small muted">
        {c.status === 'settled' ? `Settled. You scored ${total} points.` : locked ? 'Locked. Waiting for the result.' : c.locks_at ? `Locks ${when(c.locks_at)}. You can change picks until then.` : c.instant ? 'Answers are revealed as soon as you lock each one in.' : 'Open.'}
      </div>
      <ContestForm contestId={c.id} questions={safe} mine={Object.fromEntries(mine.map((m) => [m.question_id, m.answer]))} locked={locked} instant={c.instant} signedIn={!!user} needsTeam={!!user && !user.team_id} />
    </div>
  );
}
