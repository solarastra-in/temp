import Link from 'next/link';
import { contests, matches } from '@/lib/data';
import { ContestCard, Empty } from '@/components/Cards';
import { until } from '@/lib/format';

const FORMATS = [
  ['Match Predictor', 'Winner, top run-scorer and first-innings total for every match.', '75 pts'],
  ['Six Machine', 'Guess how many sixes fly in a match.', '30 pts'],
  ["Captain's Duel", 'Which side hits more sixes, and does the chase get home?', '35 pts'],
  ['Fantasy 10', 'Pick 6 players inside 55 credits. Your captain scores double.', 'Uncapped'],
  ['Season Oracle', 'Champion, wooden spoon, total sixes and a 150+ total. Locks at the first ball of the season.', '280 pts'],
  ['History Quiz', 'Instant-answer trivia on the league’s history.', '10 pts each'],
  ['Prize Draws', 'Free entries for signed kit, tickets and meet-the-team days.', 'Prizes'],
  ['Fan Wars & streaks', 'Every point also counts for your team. Daily check-ins build streak bonuses.', '+2 a day'],
];

export default async function Play() {
  const [all, upcoming] = await Promise.all([contests({ status: ['open', 'locked', 'settled'] }), matches('upcoming', 6)]);
  const open = all.filter((c) => c.status === 'open');
  const closed = all.filter((c) => c.status !== 'open').slice(0, 9);
  return (
    <>
      <h1 className="display" style={{ fontSize: 52 }}>PLAY</h1>
      <p className="soft" style={{ marginTop: 6 }}>Eight ways to play, all free. Points from every format count toward the season leaderboard and Fan Wars.</p>
      <div className="grid g4" style={{ marginTop: 18 }}>
        {FORMATS.map(([t, d, p]) => (
          <div key={t} className="card tight stack" style={{ gap: 6 }}>
            <div className="row"><span style={{ fontWeight: 800 }} className="grow">{t}</span><span className="pill">{p}</span></div>
            <div className="small soft">{d}</div>
          </div>
        ))}
      </div>

      <div className="section-title"><h2>Fantasy 10</h2></div>
      {upcoming.length ? (
        <div className="grid g3">
          {upcoming.map((m) => (
            <Link key={m.id} href={`/fantasy/${m.id}`} className="card tight stack" style={{ color: 'inherit', textDecoration: 'none' }}>
              <div className="row"><span className="pill lime">Fantasy 10</span><span className="grow" /><span className="pill">Locks {until(m.starts_at)}</span></div>
              <div style={{ fontWeight: 800, fontSize: 17 }}>{m.a_name} vs {m.b_name}</div>
              <div className="small soft">Pick 6 from both squads. Captain scores 2x.</div>
            </Link>
          ))}
        </div>
      ) : <Empty>Fantasy teams open as soon as fixtures are published.</Empty>}

      <div className="section-title"><h2>Open now</h2><Link href="/draws">Prize draws</Link></div>
      {open.length ? <div className="grid g3">{open.map((c) => <ContestCard key={c.id} c={c} />)}</div> : <Empty>No open competitions.</Empty>}

      {closed.length ? (<>
        <div className="section-title"><h2>Locked &amp; settled</h2></div>
        <div className="grid g3">{closed.map((c) => <ContestCard key={c.id} c={c} />)}</div>
      </>) : null}
    </>
  );
}
