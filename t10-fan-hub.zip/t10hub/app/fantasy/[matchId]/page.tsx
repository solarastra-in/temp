import Link from 'next/link';
import { notFound } from 'next/navigation';
import { q, one } from '@/lib/db';
import { getUser } from '@/lib/auth';
import { match } from '@/lib/data';
import { FANTASY } from '@/lib/game';
import { when } from '@/lib/format';
import FantasyBuilder from '@/components/FantasyBuilder';

export default async function Fantasy({ params }: { params: Promise<{ matchId: string }> }) {
  const { matchId } = await params;
  const m = await match(matchId);
  if (!m) notFound();
  const user = await getUser();
  const players = await q<any>(`SELECT id, team_id, name, credits::float AS credits, is_icon FROM players WHERE team_id IN ($1,$2) ORDER BY team_id, credits DESC, name`, [m.team_a, m.team_b]);
  const mine = user ? await one<any>(`SELECT * FROM fantasy_teams WHERE user_id = $1 AND match_id = $2`, [user.id, matchId]) : null;
  const top = await q<any>(`SELECT f.points, u.name FROM fantasy_teams f JOIN users u ON u.id = f.user_id WHERE f.match_id = $1 AND f.points IS NOT NULL ORDER BY f.points DESC LIMIT 10`, [matchId]);
  const open = m.status === 'upcoming' && new Date(m.starts_at) > new Date();
  return (
    <div className="stack">
      <Link href={`/matches/${m.id}`} className="small">&larr; Match centre</Link>
      <h1 className="display" style={{ fontSize: 44 }}>FANTASY 10: {m.a_short} v {m.b_short}</h1>
      <p className="soft" style={{ margin: 0 }}>
        Pick {FANTASY.size} players within {FANTASY.budget} credits, max {FANTASY.maxPerTeam} from one team. Runs 1, four +1, six +2, wicket 20, catch 8. Captain scores double.
        {open ? ` Locks ${when(m.starts_at)}.` : ' Selection closed.'}
      </p>
      {mine?.points != null && <div className="alert ok">Your team scored {mine.points} points.</div>}
      <FantasyBuilder matchId={m.id} teams={[{ id: m.team_a, name: m.a_name, color: m.a_color }, { id: m.team_b, name: m.b_name, color: m.b_color }]}
        players={players} initial={mine ? { players: mine.players, captain: mine.captain } : null} open={open} signedIn={!!user} rules={FANTASY} />
      {top.length ? (
        <section className="card stack"><h2>Top fantasy scores</h2>
          <table className="t"><tbody>{top.map((t, i) => <tr key={i}><td style={{ width: 30 }}>{i + 1}</td><td>{t.name}</td><td style={{ textAlign: 'right', fontWeight: 800 }}>{t.points}</td></tr>)}</tbody></table>
        </section>
      ) : null}
    </div>
  );
}
