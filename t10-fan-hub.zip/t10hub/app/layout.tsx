import './globals.css';
import Link from 'next/link';
import type { Metadata, Viewport } from 'next';
import Nav from '@/components/Nav';
import { getUser } from '@/lib/auth';
import { userPoints } from '@/lib/game';
import { initials } from '@/lib/format';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = {
  title: 'T10 Fan Hub · Abu Dhabi T10',
  description: 'Play, predict and follow every team in the Abu Dhabi T10 — cricket’s fastest format.',
};
export const viewport: Viewport = { themeColor: '#0E1318', width: 'device-width', initialScale: 1 };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const user = await getUser();
  const pts = user ? await userPoints(user.id) : 0;
  return (
    <html lang="en">
      <body>
        <header className="top">
          <div className="wrap">
            <Link href="/" className="brand"><b>T10</b> FAN HUB</Link>
            <Nav admin={!!user?.isAdmin} />
            <div className="me">
              {user ? (
                <>
                  <span className="pts">{pts.toLocaleString()} pts</span>
                  <Link href="/me" className="avatar" aria-label="My profile">
                    {user.avatar ? <img src={user.avatar} alt="" width={32} height={32} /> : initials(user.name || user.email)}
                  </Link>
                </>
              ) : (
                <Link href="/login" className="btn small">Sign in</Link>
              )}
            </div>
          </div>
        </header>
        <main><div className="wrap">{children}</div></main>
        <footer className="foot">
          <div className="wrap row wrap-row">
            <span>T10 Fan Hub · Free to play. No purchase necessary.</span>
            <span className="grow" />
            <Link href="/rules">Rules &amp; scoring</Link>
            <Link href="/social">All team channels</Link>
          </div>
        </footer>
      </body>
    </html>
  );
}
