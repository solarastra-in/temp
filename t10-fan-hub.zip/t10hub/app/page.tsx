import Link from 'next/link';
import { getUser } from '@/lib/auth';
import { matches, contests, feed, teams } from '@/lib/data';
import { fanWars } from '@/lib/game';
import { MatchCard, ContestCard, FeedCard, Empty } from '@/components/Cards';
import Checkin from '@/components/Checkin';
import CuratorWall from '@/components/CuratorWall';
import { curatorConfigured, curatorFeedId, curatorContainerId } from '@/lib/curator';

export default async function Home() {
  const user = await getUser();
  const [live, upcoming, recent, open, social, news, wars, ts] = await Promise.all([
    matches('live', 4), matches('upcoming', 4), matches('completed', 2),
    contests({ status: ['open'] }), feed({ kind: ['video', 'post'], limit: 6 }), feed({ kind: ['news', 'story'], limit: 6 }), fanWars(), teams(),
  ]);
  const shown = [...live, ...upcoming, ...recent].slice(0, 4);
  const maxPts = Math.max(1, ...wars.map((w) => w.pts));
  const tagline = process.env.HERO_TAGLINE || 'The next innings';
  const myTeam = user?.team_id ? ts.find((t) => t.id === user.team_id) : null;

  return (
    <>
      <section className="hero grid g3" style={{ alignItems: 'end' }}>
        <div className="span2 stack" style={{ gap: 16 }}>
          <span className="pill dash" style={{ alignSelf: 'flex-start' }}>Abu Dhabi T10 · Cricket&rsquo;s fastest format</span>
          <h1>{tagline.toUpperCase()}.<br /><em>PLAY EVERY BALL.</em></h1>
          <p className="soft" style={{ fontSize: 17, maxWidth: 620, margin: 0 }}>
            Predict results, build a Fantasy 10, enter free prize draws and follow every team&rsquo;s channels in one place. Browse freely. Sign in to play.
          </p>
          <div className="row wrap-row">
            {user ? (
              myTeam ? <Link href="/play" className="btn">Play now</Link> : <Link href="/me#team" className="btn">Choose your team</Link>
            ) : (
              <Link href="/login?next=/me%23team" className="btn">Sign in to play</Link>
            )}
            <Link href="/social" className="btn ghost">All team channels</Link>
          </div>
        </div>
        <div className="card stack">
          {user ? (
            <>
              <div className="row"><span className="grow" style={{ fontWeight: 800 }}>Welcome back{user.name ? `, ${user.name.split(' ')[0]}` : ''}</span>{myTeam ? <span className="pill" style={{ background: myTeam.color, color: '#0E1318' }}>{myTeam.short}</span> : null}</div>
              <Checkin />
              <div className="small muted">{open.length} competitions open right now.</div>
            </>
          ) : (
            <>
              <div style={{ fontWeight: 800 }}>New here?</div>
              <div className="small soft">Sign in with Google or your email. You get 25 welcome points, and every contest you enter adds more.</div>
              <Link href="/login" className="btn full">Sign in</Link>
            </>
          )}
        </div>
      </section>

      <div className="section-title"><h2>Matches</h2><Link href="/matches">Full schedule</Link></div>
      {shown.length ? <div className="grid g4">{shown.map((m) => <MatchCard key={m.id} m={m} />)}</div> : <Empty>The 2026 schedule appears here as soon as the Scores agent picks it up, or when an admin adds fixtures.</Empty>}

      <div className="section-title"><h2>Open competitions</h2><Link href="/play">See all</Link></div>
      {open.length ? <div className="grid g3">{open.slice(0, 6).map((c) => <ContestCard key={c.id} c={c} />)}</div> : <Empty>No open competitions right now.</Empty>}

      <div className="grid g3" style={{ marginTop: 34 }}>
        <section className="card stack span2">
          <div className="row"><h2 className="grow">Fan Wars</h2><Link href="/leaderboard?view=teams" className="small">Standings</Link></div>
          <div className="small muted">Every point you earn also counts for your team&rsquo;s fanbase.</div>
          {wars.map((w) => (
            <div key={w.id} className="row">
              <span style={{ width: 150 }} className="small">{w.name}</span>
              <div className="grow probbar" style={{ height: 12 }}><div style={{ width: `${Math.max(2, (w.pts / maxPts) * 100)}%`, background: w.color }} /></div>
              <span className="small" style={{ width: 70, textAlign: 'right', fontWeight: 800 }}>{w.pts.toLocaleString()}</span>
            </div>
          ))}
        </section>
        <section className="card stack">
          <h2>Follow the teams</h2>
          <div className="small muted">Every official channel, found and checked by our Discovery agent.</div>
          <div className="row wrap-row">{ts.map((t) => <Link key={t.id} href={`/teams/${t.id}`} className="pill"><span className="dot" style={{ background: t.color }} />{t.name}</Link>)}</div>
          <Link href="/social" className="btn ghost small">Open the Social Hub</Link>
        </section>
      </div>

      <div className="section-title"><h2>From the teams</h2><Link href="/social">Social Hub</Link></div>
      {curatorConfigured() && !social.length ? <section className="card"><CuratorWall feedId={curatorFeedId()} containerId={curatorContainerId()} /></section> : social.length ? <div className="grid g3">{social.map((f) => <FeedCard key={f.id} f={f} />)}</div> : <Empty>Latest videos and posts from team channels show here after the Social agent runs.</Empty>}

      <div className="section-title"><h2>League &amp; cricket news</h2><Link href="/news">All news</Link></div>
      {news.length ? <div className="grid g3">{news.map((f) => <FeedCard key={f.id} f={f} />)}</div> : <Empty>Headlines appear here after the News agent runs.</Empty>}
    </>
  );
}
