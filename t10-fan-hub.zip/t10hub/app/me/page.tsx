import Link from 'next/link';
import { redirect } from 'next/navigation';
import { q } from '@/lib/db';
import { getUser } from '@/lib/auth';
import { teams, myEntries } from '@/lib/data';
import { userPoints } from '@/lib/game';
import { ago, TYPE_LABEL } from '@/lib/format';
import TeamPicker from '@/components/TeamPicker';
import Checkin from '@/components/Checkin';

export default async function Me() {
  const user = await getUser();
  if (!user) redirect('/login?next=/me');
  const [ts, entries, pts, ledger, rank] = await Promise.all([
    teams(), myEntries(user.id), userPoints(user.id),
    q<any>(`SELECT * FROM points_ledger WHERE user_id = $1 ORDER BY created_at DESC LIMIT 15`, [user.id]),
    q<any>(`SELECT count(*)::int + 1 AS r FROM (SELECT user_id, sum(amount) s FROM points_ledger GROUP BY user_id) x WHERE x.s > (SELECT COALESCE(sum(amount),0) FROM points_ledger WHERE user_id = $1)`, [user.id]),
  ]);
  const myTeam = ts.find((t) => t.id === user.team_id);
  const badges = [
    entries.length >= 1 && 'First entry', entries.length >= 5 && 'Regular', entries.length >= 15 && 'Superfan',
    ledger.some((l) => l.ref.startsWith('streak:')) && '7-day streak', ledger.some((l) => l.ref.startsWith('f:')) && 'Fantasy scorer',
  ].filter(Boolean) as string[];
  return (
    <div className="stack" style={{ gap: 22 }}>
      <section className="card row wrap-row" style={{ gap: 18 }}>
        <span className="avatar" style={{ width: 64, height: 64, fontSize: 22 }}>{user.avatar ? <img src={user.avatar} alt="" /> : (user.name || '?')[0].toUpperCase()}</span>
        <div className="grow">
          <h1 className="display" style={{ fontSize: 36 }}>{(user.name || user.email).toUpperCase()}</h1>
          <div className="small muted">{user.email} · signed in with {user.provider === 'google' ? 'Google' : 'email code'}</div>
        </div>
        <div className="stack" style={{ gap: 4, textAlign: 'right' }}><div className="score" style={{ color: 'var(--lime)' }}>{pts.toLocaleString()}</div><div className="xs muted">points · rank #{rank[0]?.r}</div></div>
        <form action="/api/auth/logout" method="post"><button className="btn ghost small">Sign out</button></form>
      </section>

      <section id="team" className="card stack">
        <h2>{myTeam ? `You back ${myTeam.name}` : 'Choose your team'}</h2>
        <div className="small soft">{myTeam ? 'Your points also count for your team in Fan Wars. You can switch once per season.' : 'Pick the team you support. Every point you earn also counts for your team in Fan Wars.'}</div>
        <div className="grid g3">
          {ts.map((t) => (
            <div key={t.id} className="tile row" style={{ border: t.id === user.team_id ? '2px solid var(--lime)' : '2px solid transparent' }}>
              <span className="badge" style={{ background: t.color }}>{t.short}</span>
              <div className="grow"><div style={{ fontWeight: 800 }}>{t.name}</div><div className="xs muted">{t.fans} fans</div></div>
              {t.id === user.team_id ? <span className="pill lime">Yours</span> : (!user.team_id || user.team_changes < 1) ? <TeamPicker teamId={t.id} label="Pick" changing={!!user.team_id} /> : null}
            </div>
          ))}
        </div>
      </section>

      <div className="grid g3">
        <section className="card stack"><h2>Daily</h2><Checkin />
          <div className="row wrap-row">{badges.length ? badges.map((b) => <span key={b} className="pill lime">{b}</span>) : <span className="small muted">Badges unlock as you play.</span>}</div>
        </section>
        <section className="card stack span2">
          <h2>My competitions</h2>
          {entries.length ? entries.map((e) => (
            <Link key={e.id} href={`/play/${e.id}`} className="row tile" style={{ color: 'var(--text)' }}>
              <span className="pill">{TYPE_LABEL[e.type] || e.type}</span><span className="grow small" style={{ fontWeight: 700 }}>{e.title}</span>
              <span className="xs muted">{e.status === 'settled' ? `${e.pts} pts` : e.status}</span>
            </Link>
          )) : <div className="small muted">Nothing yet. <Link href="/play">Find a competition</Link>.</div>}
        </section>
      </div>
      <section className="card stack">
        <h2>Points history</h2>
        {ledger.map((l) => <div key={l.id} className="row small"><span className="grow">{l.reason}</span><span className="muted xs">{ago(l.created_at)}</span><b style={{ width: 50, textAlign: 'right' }}>+{l.amount}</b></div>)}
      </section>
    </div>
  );
}
