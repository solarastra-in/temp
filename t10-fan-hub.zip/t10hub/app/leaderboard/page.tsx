import Link from 'next/link';
import { getUser } from '@/lib/auth';
import { leaderboard, fanWars } from '@/lib/game';
import { teams } from '@/lib/data';
import { initials } from '@/lib/format';
import { Empty } from '@/components/Cards';

export default async function Leaderboard({ searchParams }: { searchParams: Promise<{ view?: string; team?: string }> }) {
  const { view = 'fans', team } = await searchParams;
  const [user, ts] = await Promise.all([getUser(), teams()]);
  const rows = view === 'teams' ? [] : await leaderboard(50, team);
  const wars = view === 'teams' ? await fanWars() : [];
  return (
    <>
      <h1 className="display" style={{ fontSize: 52 }}>LEADERBOARD</h1>
      <div className="row wrap-row" style={{ margin: '12px 0 20px' }}>
        <Link href="/leaderboard" className={`pill ${view !== 'teams' && !team ? 'on' : ''}`}>All fans</Link>
        <Link href="/leaderboard?view=teams" className={`pill ${view === 'teams' ? 'on' : ''}`}>Fan Wars (teams)</Link>
        {ts.map((t) => <Link key={t.id} href={`/leaderboard?team=${t.id}`} className={`pill ${team === t.id ? 'on' : ''}`}><span className="dot" style={{ background: t.color, width: 8, height: 8 }} />{t.short} fans</Link>)}
      </div>
      <section className="card scroll-x">
        {view === 'teams' ? (
          <table className="t">
            <thead><tr><th>#</th><th>Team</th><th>Fans</th><th style={{ textAlign: 'right' }}>Fanbase points</th></tr></thead>
            <tbody>{wars.map((w, i) => (
              <tr key={w.id} className={user?.team_id === w.id ? 'me' : ''}><td>{i + 1}</td><td><span className="dot" style={{ background: w.color, marginRight: 8 }} />{w.name}</td><td>{w.fans}</td><td style={{ textAlign: 'right', fontWeight: 800 }}>{w.pts.toLocaleString()}</td></tr>
            ))}</tbody>
          </table>
        ) : rows.length ? (
          <table className="t">
            <thead><tr><th>#</th><th>Fan</th><th>Team</th><th style={{ textAlign: 'right' }}>Points</th></tr></thead>
            <tbody>{rows.map((r, i) => (
              <tr key={r.id} className={user?.id === r.id ? 'me' : ''}>
                <td>{i + 1}</td>
                <td><span className="row"><span className="avatar" style={{ width: 28, height: 28, fontSize: 11 }}>{r.avatar ? <img src={r.avatar} alt="" /> : initials(r.name)}</span>{r.name}{user?.id === r.id ? ' (you)' : ''}</span></td>
                <td>{r.team_short ? <span className="pill" style={{ background: r.team_color, color: '#0E1318' }}>{r.team_short}</span> : <span className="muted xs">—</span>}</td>
                <td style={{ textAlign: 'right', fontWeight: 800 }}>{r.pts.toLocaleString()}</td>
              </tr>
            ))}</tbody>
          </table>
        ) : <Empty>No fans here yet. Be the first.</Empty>}
      </section>
    </>
  );
}
