import { redirect } from 'next/navigation';
import { q } from '@/lib/db';
import { getUser, googleConfigured } from '@/lib/auth';
import { emailConfigured } from '@/lib/email';
import { curatorConfigured, curatorLastSync } from '@/lib/curator';
import { teams, matches, draws } from '@/lib/data';
import { AGENTS } from '@/lib/agents';
import { ago, when } from '@/lib/format';
import { AgentButton, ApprovalButtons, MatchForm, ResultForm, DrawForm, RunDraw, HandleForm, DemoButtons } from '@/components/Admin';

export default async function Admin() {
  const user = await getUser();
  if (!user) redirect('/login?next=/admin');
  if (!user.isAdmin) return <div className="card">Admins only. Add your email to ADMIN_EMAILS.</div>;
  const [runs, lastByAgent, approvals, ts, ms, ds, stats] = await Promise.all([
    q<any>(`SELECT * FROM agent_runs ORDER BY started_at DESC LIMIT 20`),
    q<any>(`SELECT DISTINCT ON (agent) * FROM agent_runs ORDER BY agent, started_at DESC`),
    q<any>(`SELECT * FROM approvals WHERE status = 'pending' ORDER BY created_at DESC LIMIT 50`),
    teams(), matches('all', 60), draws(),
    q<any>(`SELECT (SELECT count(*) FROM users)::int AS users, (SELECT count(*) FROM entries)::int AS entries, (SELECT count(*) FROM handles WHERE status='verified')::int AS handles, (SELECT count(*) FROM feed_items)::int AS items`),
  ]);
  const last = Object.fromEntries(lastByAgent.map((r) => [r.agent, r]));
  const cfg: [string, boolean, string][] = [
    ['Google sign-in', googleConfigured(), 'GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET'],
    ['Email codes', emailConfigured(), 'RESEND_API_KEY / EMAIL_FROM'],
    ['Live scores', !!process.env.CRICAPI_KEY, 'CRICAPI_KEY (cricketdata.org)'],
    ['Claude agents', !!process.env.ANTHROPIC_API_KEY, 'ANTHROPIC_API_KEY'],
    ['X posts', !!process.env.X_BEARER_TOKEN, 'X_BEARER_TOKEN'],
    ['Curator.io wall', curatorConfigured(), 'CURATOR_FEED_ID'],
    ['Curator auto-sources', !!(process.env.CURATOR_API_KEY && process.env.CURATOR_FEED_UUID), 'CURATOR_API_KEY / CURATOR_FEED_UUID'],
    ['Instagram posts', !!(process.env.IG_ACCESS_TOKEN && process.env.IG_BUSINESS_ID), 'IG_ACCESS_TOKEN / IG_BUSINESS_ID'],
    ['Scheduled runs', !!process.env.CRON_SECRET, 'CRON_SECRET'],
  ];
  return (
    <div className="stack" style={{ gap: 22 }}>
      <div className="row wrap-row" style={{ alignItems: 'flex-end' }}>
        <div className="grow"><h1 className="display" style={{ fontSize: 52, lineHeight: 1 }}>OPS CONSOLE</h1><p className="soft" style={{ margin: '6px 0 0' }}>The agents run the hub. This page only shows what needs a human.</p></div>
        <AgentButton name="all" label="Run all agents" primary />
      </div>
      <div className="grid g4">
        {[['Fans', stats[0].users], ['Entries', stats[0].entries], ['Verified handles', stats[0].handles], ['Feed items', stats[0].items]].map(([l, v]) => (
          <div key={l as string} className="card tight"><div className="score">{(v as number).toLocaleString()}</div><div className="small muted">{l}</div></div>
        ))}
      </div>

      <div className="grid g3">
        {Object.entries(AGENTS).map(([k, a]) => {
          const r = last[k];
          return (
            <section key={k} className="card stack">
              <div className="row"><span className="dot" style={{ background: !r ? 'var(--muted)' : r.status === 'ok' ? 'var(--good)' : r.status === 'running' || r.status === 'warn' ? 'var(--gold)' : 'var(--live)' }} />
                <span className="xs muted" style={{ fontWeight: 700 }}>{!r ? 'NEVER RUN' : r.status.toUpperCase()}{r ? ` · ${ago(r.started_at)}` : ''}</span></div>
              <div style={{ fontWeight: 800, fontSize: 17 }}>{a.label} agent</div>
              <div className="small soft">{a.job}</div>
              {r?.summary && <div className="xs muted clamp3" title={r.summary}>{r.summary}</div>}
              <AgentButton name={k} label="Run now" />
            </section>
          );
        })}
      </div>

      <section className="card stack">
        <div className="row"><h2 className="grow">Needs your approval</h2><span className="pill live">{approvals.length}</span></div>
        {approvals.length ? approvals.map((a) => (
          <div key={a.id} className="row wrap-row tile" style={{ padding: 14 }}>
            <span className="pill" style={{ width: 80, justifyContent: 'center' }}>{a.kind.toUpperCase()}</span>
            <div className="grow"><div style={{ fontWeight: 700 }}>{a.title}</div><div className="xs muted">{a.detail}</div></div>
            <ApprovalButtons id={a.id} />
          </div>
        )) : <div className="small muted">All clear.</div>}
      </section>

      <div className="grid g2">
        <section className="card stack"><h2>Add a fixture</h2><div className="small muted">Not needed once the Scores agent has a CRICAPI_KEY. Contests are created automatically.</div><MatchForm teams={ts} /></section>
        <section className="card stack"><h2>Create a prize draw</h2><DrawForm teams={ts} /></section>
      </div>

      <section className="card stack scroll-x">
        <h2>Fixtures &amp; results</h2>
        <table className="t">
          <thead><tr><th>Match</th><th>Start</th><th>Status</th><th>Result</th></tr></thead>
          <tbody>{ms.map((m) => (
            <tr key={m.id}><td><b>{m.a_short} v {m.b_short}</b>{m.is_demo ? <span className="pill dash" style={{ marginLeft: 6 }}>demo</span> : null}</td><td className="small">{when(m.starts_at)}</td><td className="small">{m.status}</td>
              <td>{m.status === 'completed' ? <span className="small">{m.result}</span> : <ResultForm m={m} />}</td></tr>
          ))}</tbody>
        </table>
        {!ms.length && <div className="small muted">No fixtures yet.</div>}
      </section>

      <div className="grid g2">
        <section className="card stack">
          <h2>Draws</h2>
          {ds.map((d) => <div key={d.id} className="row tile"><span className="grow small"><b>{d.title}</b> · {d.entries} entries · {d.status}</span>{d.status === 'open' && <RunDraw id={d.id} />}</div>)}
          {!ds.length && <div className="small muted">No draws yet.</div>}
        </section>
        <section className="card stack"><h2>Add a handle manually</h2><div className="small muted">Paste a profile URL. It is verified immediately.</div><HandleForm teams={ts} /></section>
      </div>

      <div className="grid g2">
        <section className="card stack">
          <h2>Connections</h2>
          {curatorConfigured() && <div className="xs muted">Curator last synced: {(await curatorLastSync()) ? ago((await curatorLastSync())!) : 'not yet'} · <a href="/social">view wall</a></div>}
          {cfg.map(([l, ok, env]) => <div key={l} className="row small"><span className="dot" style={{ background: ok ? 'var(--good)' : 'var(--muted)' }} /><span className="grow">{l}</span><span className="xs muted">{ok ? 'connected' : `set ${env}`}</span></div>)}
        </section>
        <section className="card stack">
          <h2>Demo data</h2><div className="small muted">Adds six sample fixtures and three draws (flagged as demo) so you can test every competition before the real schedule is out.</div>
          <DemoButtons />
        </section>
      </div>

      <section className="card stack">
        <h2>Agent log</h2>
        {runs.map((r) => <div key={r.id} className="row small" style={{ alignItems: 'flex-start' }}><span className="muted xs" style={{ width: 70 }}>{ago(r.started_at)}</span><span style={{ width: 90, fontWeight: 700 }}>{r.agent}</span><span className="grow soft xs">{r.status === 'error' ? '⚠ ' : ''}{r.summary}</span></div>)}
      </section>
    </div>
  );
}
