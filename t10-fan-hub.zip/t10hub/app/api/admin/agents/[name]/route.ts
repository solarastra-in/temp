import { handle, requireAdmin, HttpError } from '@/lib/api';
import { AGENTS, runNamed, runAll, AgentName } from '@/lib/agents';

export const maxDuration = 300;
export const POST = handle(async (_req, { params }) => {
  await requireAdmin();
  const { name } = await params;
  if (name === 'all') return runAll();
  if (!(name in AGENTS)) throw new HttpError(404, 'Unknown agent');
  return runNamed(name as AgentName);
});
