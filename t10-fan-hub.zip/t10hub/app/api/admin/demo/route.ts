import { handle, requireAdmin, HttpError } from '@/lib/api';
import { seedDemo, clearDemo } from '@/lib/demo';

export const POST = handle(async (req) => {
  await requireAdmin();
  const b = await req.json().catch(() => ({}));
  if (b.clear) return clearDemo();
  if (process.env.NODE_ENV === 'production' && process.env.DEMO_MODE !== 'true') throw new HttpError(403, 'Demo data is disabled in production');
  return seedDemo();
});
