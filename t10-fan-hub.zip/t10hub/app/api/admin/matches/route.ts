import { handle, requireAdmin, HttpError } from '@/lib/api';
import { q, id } from '@/lib/db';
import { ensureMatchContests } from '@/lib/game';

export const POST = handle(async (req) => {
  await requireAdmin();
  const b = await req.json();
  if (!b.team_a || !b.team_b || b.team_a === b.team_b) throw new HttpError(400, 'Pick two different teams');
  if (!b.starts_at || isNaN(Date.parse(b.starts_at))) throw new HttpError(400, 'Enter a start time');
  const mid = id('m_');
  await q(`INSERT INTO matches (id, match_no, stage, team_a, team_b, starts_at, venue) VALUES ($1,$2,$3,$4,$5,$6,COALESCE($7,'Zayed Cricket Stadium, Abu Dhabi'))`,
    [mid, b.match_no || null, b.stage || 'League', b.team_a, b.team_b, new Date(b.starts_at).toISOString(), b.venue || null]);
  await ensureMatchContests(mid);
  return { ok: true, id: mid };
});
