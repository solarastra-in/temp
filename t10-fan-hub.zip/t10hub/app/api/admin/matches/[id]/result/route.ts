// Manual result entry (used when no live data feed is connected). "simulate" fills random stats for testing.
import { handle, requireAdmin, HttpError } from '@/lib/api';
import { q, one } from '@/lib/db';
import { settleMatch } from '@/lib/game';

export const POST = handle(async (req, { params }) => {
  await requireAdmin();
  const { id } = await params;
  const b = await req.json();
  const m = await one<any>(`SELECT * FROM matches WHERE id = $1`, [id]);
  if (!m) throw new HttpError(404, 'Match not found');
  if (b.simulate) {
    if (process.env.NODE_ENV === 'production' && process.env.DEMO_MODE !== 'true') throw new HttpError(403, 'Simulation is disabled in production');
    const players = await q<any>(`SELECT id, team_id, name FROM players WHERE team_id IN ($1,$2)`, [m.team_a, m.team_b]);
    const rnd = (n: number) => Math.floor(Math.random() * n);
    const tot: Record<string, number> = { [m.team_a]: 0, [m.team_b]: 0 };
    let top = { name: '', runs: -1 };
    let sixes = 0;
    for (const p of players) {
      const runs = rnd(3) === 0 ? rnd(55) : rnd(12);
      const s6 = Math.floor(runs / 14), s4 = Math.floor((runs - s6 * 6) / 9);
      const w = rnd(4) === 0 ? rnd(3) : 0, c = rnd(5) === 0 ? 1 : 0;
      tot[p.team_id] += runs; sixes += s6;
      if (runs > top.runs) top = { name: p.name, runs };
      await q(`INSERT INTO player_stats (match_id, player_id, runs, balls, fours, sixes, wickets, catches) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT (match_id, player_id) DO UPDATE SET runs=$3, balls=$4, fours=$5, sixes=$6, wickets=$7, catches=$8`,
        [id, p.id, runs, Math.max(1, Math.round(runs / 2)), s4, s6, w, c]);
    }
    const aWins = tot[m.team_a] >= tot[m.team_b];
    b.winner = aWins ? m.team_a : m.team_b;
    b.score_a = `${tot[m.team_a]}/${rnd(8)} (10)`;
    b.score_b = `${tot[m.team_b]}/${rnd(8)} (${aWins ? 10 : 8.4})`;
    b.first_innings = tot[m.team_a];
    b.top_scorer = top.name;
    b.total_sixes = sixes;
    b.result = aWins ? 'Won by runs (simulated)' : 'Won by wickets (simulated)';
  }
  if (!b.winner) throw new HttpError(400, 'Select the winner');
  await q(`UPDATE matches SET status = 'completed', winner = $2, score_a = $3, score_b = $4, first_innings = $5, top_scorer = $6, total_sixes = $7, result = $8, updated_at = now() WHERE id = $1`,
    [id, b.winner, b.score_a || null, b.score_b || null, b.first_innings ?? null, b.top_scorer || null, b.total_sixes ?? null, b.result || null]);
  return settleMatch(id);
});
