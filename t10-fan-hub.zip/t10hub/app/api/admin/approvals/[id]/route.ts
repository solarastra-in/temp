import { handle, requireAdmin, HttpError } from '@/lib/api';
import { q, one, id as newId } from '@/lib/db';

export const POST = handle(async (req, { params }) => {
  const admin = await requireAdmin();
  const { id } = await params;
  const { decision } = await req.json();
  const a = await one<any>(`SELECT * FROM approvals WHERE id = $1`, [id]);
  if (!a || a.status !== 'pending') throw new HttpError(400, 'Already decided');
  const ok = decision === 'approve';
  const p = a.payload || {};
  if (a.kind === 'handle') await q(`UPDATE handles SET status = $2, verified_at = CASE WHEN $2 = 'verified' THEN now() ELSE verified_at END WHERE id = $1`, [p.handleId, ok ? 'verified' : 'rejected']);
  if (a.kind === 'story') await q(`UPDATE feed_items SET status = $2 WHERE id = $1`, [p.feedId, ok ? 'live' : 'hidden']);
  if (a.kind === 'website' && ok) await q(`UPDATE teams SET website = $2 WHERE id = $1`, [p.teamId, p.website]);
  if (a.kind === 'team' && ok) {
    const short = String(p.name).split(/\s+/).map((w: string) => w[0]).join('').slice(0, 3).toUpperCase();
    await q(`INSERT INTO teams (id, name, short, color, sort, note) VALUES ($1,$2,$3,'#8FA3B8',99,'Added from the live feed.') ON CONFLICT DO NOTHING`, [newId('t_'), p.name, short]);
  }
  if (a.kind === 'payout' && ok) await q(`UPDATE draws SET status = 'fulfilled' WHERE id = $1`, [p.drawId]);
  await q(`UPDATE approvals SET status = $2, decided_at = now(), decided_by = $3 WHERE id = $1`, [id, ok ? 'approved' : 'rejected', admin.email]);
  return { ok: true };
});
