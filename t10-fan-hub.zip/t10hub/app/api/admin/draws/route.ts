import { handle, requireAdmin, HttpError } from '@/lib/api';
import { q, id } from '@/lib/db';

export const POST = handle(async (req) => {
  await requireAdmin();
  const b = await req.json();
  if (!b.title || !b.prize || !b.closes_at) throw new HttpError(400, 'Title, prize and closing time are required');
  await q(`INSERT INTO draws (id, title, prize, rule, color, closes_at, team_only) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [id('d_'), b.title, b.prize, b.rule || null, b.color || '#D8F24A', new Date(b.closes_at).toISOString(), b.team_only || null]);
  return { ok: true };
});
