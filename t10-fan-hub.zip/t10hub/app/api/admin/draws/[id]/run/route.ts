import { handle, requireAdmin } from '@/lib/api';
import { runDraw } from '@/lib/game';

export const POST = handle(async (_req, { params }) => {
  await requireAdmin();
  const { id } = await params;
  return runDraw(id);
});
