import { handle, requireAdmin, HttpError } from '@/lib/api';
import { q, id } from '@/lib/db';
import { extractSocialLinks } from '@/lib/agents/util';

export const POST = handle(async (req) => {
  await requireAdmin();
  const b = await req.json();
  const url = String(b.url || '').trim();
  let s = extractSocialLinks(` ${url} `)[0];
  if (!s && /^https?:\/\//.test(url) && b.platform === 'RSS') s = { platform: 'RSS', handle: new URL(url).hostname, url };
  if (!s) throw new HttpError(400, 'Paste a full profile URL (Instagram, X, YouTube, Facebook, TikTok) or choose RSS for a feed URL');
  await q(`INSERT INTO handles (id, team_id, platform, handle, url, status, source, verified_at) VALUES ($1,$2,$3,$4,$5,'verified','admin',now())
    ON CONFLICT (url) DO UPDATE SET status = 'verified', team_id = EXCLUDED.team_id, verified_at = now()`, [id('h_'), b.team_id || null, s.platform, s.handle, s.url]);
  return { ok: true, handle: s };
});
