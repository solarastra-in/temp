import { handle, requireUser } from '@/lib/api';
import { saveFantasy } from '@/lib/game';

export const POST = handle(async (req, { params }) => {
  const u = await requireUser();
  const { matchId } = await params;
  const b = await req.json();
  await saveFantasy(u.id, matchId, b.players || [], b.captain);
  return { ok: true };
});
