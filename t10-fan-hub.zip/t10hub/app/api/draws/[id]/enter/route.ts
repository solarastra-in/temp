import { handle, requireUser, HttpError } from '@/lib/api';
import { q, one } from '@/lib/db';

export const POST = handle(async (_req, { params }) => {
  const u = await requireUser();
  const { id } = await params;
  const d = await one<any>(`SELECT * FROM draws WHERE id = $1`, [id]);
  if (!d || d.status !== 'open' || new Date(d.closes_at).getTime() < Date.now()) throw new HttpError(400, 'This draw is closed');
  if (d.team_only && d.team_only !== u.team_id) throw new HttpError(400, 'This draw is for fans of one team. Pick that team first.');
  await q(`INSERT INTO draw_entries (draw_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [id, u.id]);
  return { ok: true };
});
