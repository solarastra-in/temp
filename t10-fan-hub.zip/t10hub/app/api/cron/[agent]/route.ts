// Scheduled entry point (Vercel Cron, GitHub Actions, or any scheduler).
// Authorise with header "Authorization: Bearer $CRON_SECRET".
import { NextResponse } from 'next/server';
import { AGENTS, runNamed, runAll, AgentName } from '@/lib/agents';

export const maxDuration = 300;
export const dynamic = 'force-dynamic';

export async function GET(req: Request, { params }: { params: Promise<{ agent: string }> }) {
  const secret = process.env.CRON_SECRET;
  if (!secret || req.headers.get('authorization') !== `Bearer ${secret}`) return NextResponse.json({ error: 'unauthorised' }, { status: 401 });
  const { agent } = await params;
  if (agent === 'all') return NextResponse.json(await runAll());
  if (!(agent in AGENTS)) return NextResponse.json({ error: 'unknown agent' }, { status: 404 });
  return NextResponse.json(await runNamed(agent as AgentName));
}
