import { handle, requireUser } from '@/lib/api';
import { q } from '@/lib/db';
import { award } from '@/lib/game';

export const POST = handle(async () => {
  const u = await requireUser();
  const today = new Date().toISOString().slice(0, 10);
  await award(u.id, 2, 'Daily check-in', `checkin:${today}`);
  const rows = await q<any>(`SELECT ref FROM points_ledger WHERE user_id = $1 AND ref LIKE 'checkin:%' ORDER BY ref DESC LIMIT 30`, [u.id]);
  const days = new Set(rows.map((r) => r.ref.slice(8)));
  let streak = 0;
  for (let d = new Date(); days.has(d.toISOString().slice(0, 10)); d.setUTCDate(d.getUTCDate() - 1)) streak++;
  if (streak > 0 && streak % 7 === 0) await award(u.id, 20, `${streak}-day streak bonus`, `streak:${today}`);
  return { ok: true, streak };
});
