import { NextResponse } from 'next/server';
import { z } from 'zod';
import { issueOtp } from '@/lib/auth';
import { sendEmail, otpEmail, emailConfigured } from '@/lib/email';

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const parsed = z.object({ email: z.string().email().max(200) }).safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Enter a valid email address.' }, { status: 400 });
  if (process.env.NODE_ENV === 'production' && !emailConfigured()) {
    return NextResponse.json({ error: 'Email sign-in is not configured yet.' }, { status: 503 });
  }
  const r = await issueOtp(parsed.data.email);
  if (!r.ok) return NextResponse.json({ error: r.error }, { status: 429 });
  const { html, text } = otpEmail(r.code);
  try {
    await sendEmail(parsed.data.email, `Your T10 Fan Hub code: ${r.code}`, html, text);
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ error: 'Could not send the email. Try again shortly.' }, { status: 502 });
  }
  // In local development without an email provider, return the code so the flow can be tested.
  const devCode = !emailConfigured() && process.env.NODE_ENV !== 'production' ? r.code : undefined;
  return NextResponse.json({ ok: true, devCode });
}
