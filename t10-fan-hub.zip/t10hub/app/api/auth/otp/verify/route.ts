import { NextResponse } from 'next/server';
import { z } from 'zod';
import { verifyOtp, upsertUser, createSession } from '@/lib/auth';

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const parsed = z.object({ email: z.string().email(), code: z.string().regex(/^\d{6}$/) }).safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: 'Enter the 6-digit code.' }, { status: 400 });
  const r = await verifyOtp(parsed.data.email, parsed.data.code);
  if (!r.ok) return NextResponse.json({ error: r.error }, { status: 401 });
  const uid = await upsertUser(parsed.data.email, 'email');
  await createSession(uid);
  return NextResponse.json({ ok: true });
}
