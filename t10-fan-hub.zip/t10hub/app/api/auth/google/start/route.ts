import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { randomBytes } from 'node:crypto';
import { appUrl, googleConfigured } from '@/lib/auth';

export async function GET(req: Request) {
  if (!googleConfigured()) return NextResponse.redirect(`${appUrl()}/login?error=google_not_configured`);
  const next = new URL(req.url).searchParams.get('next') || '/';
  const state = randomBytes(16).toString('hex');
  const jar = await cookies();
  jar.set('g_state', JSON.stringify({ state, next: next.startsWith('/') ? next : '/' }), { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: 600 });
  const p = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID!,
    redirect_uri: `${appUrl()}/api/auth/google/callback`,
    response_type: 'code',
    scope: 'openid email profile',
    state,
    prompt: 'select_account',
  });
  return NextResponse.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${p}`);
}
