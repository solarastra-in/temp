import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { appUrl, upsertUser, createSession } from '@/lib/auth';

export async function GET(req: Request) {
  const url = new URL(req.url);
  const jar = await cookies();
  const saved = JSON.parse(jar.get('g_state')?.value || '{}');
  jar.delete('g_state');
  if (!url.searchParams.get('code') || url.searchParams.get('state') !== saved.state) {
    return NextResponse.redirect(`${appUrl()}/login?error=google_state`);
  }
  const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code: url.searchParams.get('code')!,
      client_id: process.env.GOOGLE_CLIENT_ID!,
      client_secret: process.env.GOOGLE_CLIENT_SECRET!,
      redirect_uri: `${appUrl()}/api/auth/google/callback`,
      grant_type: 'authorization_code',
    }),
  });
  if (!tokenRes.ok) return NextResponse.redirect(`${appUrl()}/login?error=google_token`);
  const tok = await tokenRes.json();
  const infoRes = await fetch('https://openidconnect.googleapis.com/v1/userinfo', { headers: { Authorization: `Bearer ${tok.access_token}` } });
  const info = await infoRes.json();
  if (!info.email || info.email_verified === false) return NextResponse.redirect(`${appUrl()}/login?error=google_email`);
  const uid = await upsertUser(info.email, 'google', info.name, info.picture);
  await createSession(uid);
  return NextResponse.redirect(`${appUrl()}${saved.next || '/'}`);
}
