import { NextResponse } from 'next/server';
import { clearSession, appUrl } from '@/lib/auth';

export async function POST() {
  await clearSession();
  return NextResponse.redirect(`${appUrl()}/`, { status: 303 });
}
