import { handle, requireUser } from '@/lib/api';
import { submitEntries } from '@/lib/game';

export const POST = handle(async (req, { params }) => {
  const u = await requireUser();
  const { id } = await params;
  const body = await req.json();
  const results = await submitEntries(u.id, id, body.answers || {});
  return { ok: true, results };
});
