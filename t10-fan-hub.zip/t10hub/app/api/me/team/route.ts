import { handle, requireUser, HttpError } from '@/lib/api';
import { q, one } from '@/lib/db';

export const POST = handle(async (req) => {
  const u = await requireUser();
  const { teamId } = await req.json();
  const t = await one(`SELECT id FROM teams WHERE id = $1`, [teamId]);
  if (!t) throw new HttpError(400, 'Unknown team');
  if (u.team_id === teamId) return { ok: true };
  if (u.team_id && u.team_changes >= 1) throw new HttpError(400, 'You can switch teams only once per season.');
  await q(`UPDATE users SET team_id = $2, team_changes = team_changes + $3 WHERE id = $1`, [u.id, teamId, u.team_id ? 1 : 0]);
  return { ok: true };
});
