import Link from 'next/link';
import { feed } from '@/lib/data';
import { FeedCard, Empty } from '@/components/Cards';

export default async function News({ searchParams }: { searchParams: Promise<{ cat?: string }> }) {
  const { cat = 'league' } = await searchParams;
  const items = await feed({ kind: ['news', 'story'], category: cat === 'all' ? undefined : cat, limit: 45 });
  return (
    <>
      <h1 className="display" style={{ fontSize: 52 }}>NEWS</h1>
      <p className="soft">Headlines from the league&rsquo;s own site and major cricket outlets, gathered by the News agent. Every story links to its source.</p>
      <div className="row wrap-row" style={{ margin: '12px 0 20px' }}>
        {[['league', 'T10 & league'], ['hub', 'Match previews'], ['cricket', 'World cricket'], ['all', 'Everything']].map(([k, l]) => <Link key={k} href={`/news?cat=${k}`} className={`pill ${cat === k ? 'on' : ''}`}>{l}</Link>)}
      </div>
      {items.length ? <div className="grid g3">{items.map((f) => <FeedCard key={f.id} f={f} />)}</div> : <Empty>No headlines here yet.</Empty>}
    </>
  );
}
