import { redirect } from 'next/navigation';
import { getUser, googleConfigured } from '@/lib/auth';
import LoginForm from '@/components/LoginForm';

const ERRORS: Record<string, string> = {
  google_not_configured: 'Google sign-in is not set up yet. Use your email instead.',
  google_state: 'Google sign-in was interrupted. Please try again.',
  google_token: 'Google did not accept the sign-in. Please try again.',
  google_email: 'Your Google account has no verified email.',
};

export default async function Login({ searchParams }: { searchParams: Promise<{ next?: string; error?: string }> }) {
  const sp = await searchParams;
  const next = sp.next && sp.next.startsWith('/') ? sp.next : '/';
  if (await getUser()) redirect(next);
  return (
    <div style={{ maxWidth: 440, margin: '40px auto' }} className="card stack">
      <h1 className="display" style={{ fontSize: 40 }}>SIGN IN TO PLAY</h1>
      <p className="soft small" style={{ margin: 0 }}>Browsing is open to everyone. Sign in to pick your team, enter competitions and win prizes.</p>
      {sp.error && <div className="alert err">{ERRORS[sp.error] || 'Sign-in failed.'}</div>}
      <LoginForm next={next} google={googleConfigured()} />
      <p className="xs muted" style={{ margin: 0 }}>We only use your email to sign you in and to contact prize winners.</p>
    </div>
  );
}
