import Link from 'next/link';
import { q } from '@/lib/db';
import { draws, teamMap } from '@/lib/data';
import { getUser } from '@/lib/auth';
import { when } from '@/lib/format';
import { Empty } from '@/components/Cards';
import DrawEnter from '@/components/DrawEnter';

export default async function Draws() {
  const [ds, user, tm] = await Promise.all([draws(), getUser(), teamMap()]);
  const mine = user ? new Set((await q<any>(`SELECT draw_id FROM draw_entries WHERE user_id = $1`, [user.id])).map((r) => r.draw_id)) : new Set();
  return (
    <>
      <h1 className="display" style={{ fontSize: 52 }}>PRIZE DRAWS</h1>
      <p className="soft">Free entry. Each draw publishes its random seed and a hash of all entrants, so anyone can check the winner was picked fairly.</p>
      {ds.length ? (
        <div className="grid g3" style={{ marginTop: 16 }}>
          {ds.map((d) => (
            <article key={d.id} className="card" style={{ padding: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
              <div style={{ background: d.color, height: 120, display: 'grid', placeItems: 'center' }}><span className="display" style={{ fontSize: 30, color: '#0E1318' }}>{d.prize}</span></div>
              <div className="stack" style={{ padding: 20, flex: 1 }}>
                <div style={{ fontWeight: 800, fontSize: 17 }}>{d.title}</div>
                <div className="small muted">{d.entries.toLocaleString()} entries · closes {when(d.closes_at)}</div>
                {d.rule && <div className="small soft">{d.rule}</div>}
                {d.team_only && <span className="pill" style={{ alignSelf: 'flex-start' }}>{tm[d.team_only]?.name} fans only</span>}
                <span className="grow" />
                {d.status === 'open' ? (
                  user ? <DrawEnter id={d.id} entered={mine.has(d.id)} /> : <Link href="/login?next=/draws" className="btn full">Sign in to enter</Link>
                ) : (
                  <div className="tile stack" style={{ gap: 4 }}>
                    <div className="xs muted">WINNER</div>
                    <div style={{ fontWeight: 800, color: 'var(--lime)', fontSize: 18 }}>{d.winner_user_id === user?.id ? 'You!' : d.winner_name}</div>
                    <div className="xs muted" style={{ fontFamily: 'ui-monospace, monospace', wordBreak: 'break-all' }}>seed {d.seed}<br />entrants sha256 {d.entrants_hash}</div>
                  </div>
                )}
              </div>
            </article>
          ))}
        </div>
      ) : <Empty>No draws are running right now. Check back on matchdays.</Empty>}
      <p className="xs muted" style={{ marginTop: 18 }}>How it&rsquo;s picked: winner = entrant at position sha256(seed + entrants hash) mod number of entries, with entrants sorted by id.</p>
    </>
  );
}
