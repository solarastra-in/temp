import Link from 'next/link';
export default function NotFound() {
  return <div className="card stack" style={{ maxWidth: 520, margin: '40px auto', textAlign: 'center' }}><h1 className="display" style={{ fontSize: 44 }}>NOT FOUND</h1><Link href="/" className="btn">Back to the hub</Link></div>;
}
