import { FANTASY, ENTRY_BONUS } from '@/lib/game';

export default function Rules() {
  return (
    <div style={{ maxWidth: 760 }} className="stack">
      <h1 className="display" style={{ fontSize: 52 }}>RULES &amp; SCORING</h1>
      <div className="card stack soft">
        <p style={{ margin: 0 }}><b>Free to play.</b> No purchase or payment is ever needed to enter any competition or draw. Prizes are provided by the league, teams and sponsors.</p>
        <p style={{ margin: 0 }}><b>Entering:</b> +{ENTRY_BONUS} points for every competition you enter. Welcome bonus: 25 points. Daily check-in: +2, with +20 on every 7-day streak.</p>
        <p style={{ margin: 0 }}><b>Predictions</b> score the points shown on each question when your pick matches the official result. Picks can be changed until the contest locks at the scheduled start.</p>
        <p style={{ margin: 0 }}><b>Fantasy 10:</b> {FANTASY.size} players, {FANTASY.budget} credits, max {FANTASY.maxPerTeam} per team. Run {FANTASY.pts.run}, four +{FANTASY.pts.four}, six +{FANTASY.pts.six}, wicket {FANTASY.pts.wicket}, catch {FANTASY.pts.catch}. Captain scores double.</p>
        <p style={{ margin: 0 }}><b>Fan Wars:</b> points count for the team you backed when you earned them. You can switch team once per season.</p>
        <p style={{ margin: 0 }}><b>Draws:</b> one entry per person. Winners are picked with a published seed and entrant hash, and contacted by email. Fake or duplicate accounts are disqualified.</p>
        <p style={{ margin: 0 }} className="small muted">Results come from the official match data feed. In a dispute, the organiser&rsquo;s decision is final.</p>
      </div>
    </div>
  );
}
