import Link from 'next/link';
import { teams, handles, feed } from '@/lib/data';
import { FeedCard, Empty, TeamBadge } from '@/components/Cards';
import { ago } from '@/lib/format';
import { curatorConfigured, curatorFeedId, curatorContainerId } from '@/lib/curator';
import CuratorWall from '@/components/CuratorWall';

const PLATFORMS = ['All', 'Instagram', 'X', 'YouTube', 'TikTok', 'Facebook', 'Threads', 'Web'];

export default async function Social({ searchParams }: { searchParams: Promise<{ team?: string; platform?: string; view?: string }> }) {
  const sp = await searchParams;
  const team = sp.team || 'all';
  const platform = sp.platform || 'All';
  const wallOn = curatorConfigured();
  const view = wallOn && sp.view !== 'hub' && !sp.team && !sp.platform ? 'wall' : 'hub';
  const [ts, hs, items] = await Promise.all([
    teams(), handles(),
    feed({ kind: ['video', 'post'], teamId: team === 'all' ? undefined : team === 'league' ? null : team, platform: platform === 'All' ? undefined : platform, limit: 30 }),
  ]);
  const league = hs.filter((h) => !h.team_id);
  const link = (t: string, p: string) => `/social?team=${t}&platform=${p}`;
  const lastCheck = hs.reduce((m, h) => (h.verified_at && new Date(h.verified_at) > m ? new Date(h.verified_at) : m), new Date(0));
  return (
    <div className="stack" style={{ gap: 22 }}>
      <div className="row wrap-row" style={{ alignItems: 'flex-end' }}>
        <div className="grow">
          <h1 className="display" style={{ fontSize: 52, lineHeight: 1 }}>EVERY TEAM. EVERY CHANNEL.</h1>
          <p className="soft" style={{ margin: '8px 0 0' }}>Official handles are found and re-checked by the Discovery agent. The Social agent pulls the newest posts and videos.</p>
        </div>
        <div className="row small muted" style={{ gap: 20 }}>
          <div><div style={{ fontSize: 26, fontWeight: 800, color: 'var(--text)' }}>{hs.length}</div>verified handles</div>
          <div><div style={{ fontSize: 26, fontWeight: 800, color: 'var(--text)' }}>{lastCheck.getTime() ? ago(lastCheck) : '—'}</div>last verified</div>
        </div>
      </div>

      {wallOn && (
        <div className="row wrap-row">
          <Link href="/social" className={`pill ${view === 'wall' ? 'on' : ''}`}>Live wall (all teams)</Link>
          <Link href="/social?view=hub" className={`pill ${view === 'hub' ? 'on' : ''}`}>Browse by team &amp; channel</Link>
        </div>
      )}

      {view === 'wall' ? (
        <section className="card stack">
          <div className="row"><h2 className="grow">Live from every team</h2><span className="xs muted">Broadcast via Curator.io · moderated</span></div>
          <CuratorWall feedId={curatorFeedId()} containerId={curatorContainerId()} />
        </section>
      ) : (<>
      <div className="stack" style={{ gap: 10 }}>
        <div className="row wrap-row">
          <Link href={link('all', platform)} className={`pill ${team === 'all' ? 'on' : ''}`}>All teams</Link>
          <Link href={link('league', platform)} className={`pill ${team === 'league' ? 'on' : ''}`}>League</Link>
          {ts.map((t) => <Link key={t.id} href={link(t.id, platform)} className={`pill ${team === t.id ? 'on' : ''}`}><span className="dot" style={{ background: t.color, width: 8, height: 8 }} />{t.name}</Link>)}
        </div>
        <div className="row wrap-row">{PLATFORMS.map((p) => <Link key={p} href={link(team, p)} className={`pill ${platform === p ? 'on' : ''}`}>{p}</Link>)}</div>
      </div>

      {items.length ? <div className="grid g3">{items.map((f) => <FeedCard key={f.id} f={f} />)}</div> : <Empty>Nothing from this channel yet. Posts appear here automatically once the Social agent has run. Instagram, TikTok and Facebook posts need their platform API keys; until then their profile links are below.</Empty>}
      </>)}

      <div className="section-title" style={{ margin: '10px 0 0' }}><h2>Handle directory</h2></div>
      <div className="grid g3">
        <section className="card stack">
          <div className="row"><span className="badge" style={{ background: 'var(--lime)' }}>T10</span><div className="grow" style={{ fontWeight: 800 }}>Abu Dhabi T10 (league)</div></div>
          {league.map((h) => <HandleRow key={h.id} h={h} />)}
        </section>
        {ts.map((t) => {
          const mine = hs.filter((h) => h.team_id === t.id);
          return (
            <section key={t.id} className="card stack">
              <div className="row"><TeamBadge t={t} /><Link href={`/teams/${t.id}`} className="grow" style={{ fontWeight: 800, color: 'var(--text)' }}>{t.name}</Link></div>
              {mine.length ? mine.map((h) => <HandleRow key={h.id} h={h} />) : <div className="small muted">Discovery agent searching…</div>}
            </section>
          );
        })}
      </div>
    </div>
  );
}

function HandleRow({ h }: { h: any }) {
  return (
    <a href={h.url} target="_blank" rel="noopener noreferrer" className="row tile" style={{ color: 'var(--text)' }}>
      <span className="xs muted" style={{ width: 76, fontWeight: 700 }}>{h.platform}</span>
      <span className="grow small" style={{ fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis' }}>{h.handle}</span>
      <span aria-label="verified" style={{ color: 'var(--good)' }}>✓</span>
    </a>
  );
}
