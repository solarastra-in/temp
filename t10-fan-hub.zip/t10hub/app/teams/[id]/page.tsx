import Link from 'next/link';
import { notFound } from 'next/navigation';
import { q, one } from '@/lib/db';
import { feed, matches } from '@/lib/data';
import { getUser } from '@/lib/auth';
import { TeamBadge, FeedCard, MatchCard, Empty } from '@/components/Cards';
import TeamPicker from '@/components/TeamPicker';

export default async function TeamPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const t = await one<any>(`SELECT t.*, (SELECT count(*) FROM users u WHERE u.team_id = t.id)::int AS fans FROM teams t WHERE t.id = $1`, [id]);
  if (!t) notFound();
  const [players, hs, items, ms, user] = await Promise.all([
    q<any>(`SELECT * FROM players WHERE team_id = $1 ORDER BY is_icon DESC, credits DESC, name`, [id]),
    q<any>(`SELECT * FROM handles WHERE team_id = $1 AND status = 'verified' ORDER BY platform`, [id]),
    feed({ teamId: id, limit: 9 }), matches('all', 8, id), getUser(),
  ]);
  return (
    <div className="stack" style={{ gap: 22 }}>
      <section className="card row wrap-row" style={{ gap: 20 }}>
        <TeamBadge t={t} size="lg" />
        <div className="grow stack" style={{ gap: 4 }}>
          <h1 className="display" style={{ fontSize: 44 }}>{t.name.toUpperCase()}</h1>
          <div className="soft small">{t.home} · Icon player: {t.icon_player} · {t.fans} fans on the hub</div>
          {t.note && <div className="xs muted">{t.note}</div>}
        </div>
        {user ? (user.team_id === t.id ? <span className="pill lime">Your team</span> : <TeamPicker teamId={t.id} label={`Back ${t.short}`} changing={!!user.team_id} />)
          : <Link href={`/login?next=/teams/${t.id}`} className="btn">Sign in to back {t.short}</Link>}
      </section>
      <div className="grid g3">
        <section className="card stack">
          <h2>Official channels</h2>
          {hs.length ? hs.map((h) => (
            <a key={h.id} href={h.url} target="_blank" rel="noopener noreferrer" className="row tile" style={{ color: 'var(--text)' }}>
              <span className="xs muted" style={{ width: 76, fontWeight: 700 }}>{h.platform}</span><span className="grow small" style={{ fontWeight: 700 }}>{h.handle}</span><span aria-label="verified" style={{ color: 'var(--good)' }}>✓</span>
            </a>
          )) : <div className="small muted">The Discovery agent is still looking for this team&rsquo;s channels.</div>}
          {t.website && <a href={t.website} target="_blank" rel="noopener noreferrer" className="small">Official website &rarr;</a>}
        </section>
        <section className="card stack span2">
          <h2>Squad</h2>
          <div className="row wrap-row">{players.map((p) => <span key={p.id} className="pill" style={p.is_icon ? { background: t.color, color: '#0E1318' } : undefined}>{p.name}</span>)}</div>
          {players.length <= 1 && <div className="small muted">Full squad after the 2026 draft.</div>}
        </section>
      </div>
      <div className="section-title" style={{ margin: 0 }}><h2>Fixtures</h2></div>
      {ms.length ? <div className="grid g4">{ms.map((m) => <MatchCard key={m.id} m={m} />)}</div> : <Empty>No fixtures yet.</Empty>}
      <div className="section-title" style={{ margin: 0 }}><h2>Latest from {t.name}</h2></div>
      {items.length ? <div className="grid g3">{items.map((f) => <FeedCard key={f.id} f={f} />)}</div> : <Empty>New posts and videos from this team appear here automatically.</Empty>}
    </div>
  );
}
