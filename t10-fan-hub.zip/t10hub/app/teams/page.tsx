import Link from 'next/link';
import { teams, handles } from '@/lib/data';
import { TeamBadge } from '@/components/Cards';

export default async function Teams() {
  const [ts, hs] = await Promise.all([teams(), handles()]);
  return (
    <>
      <h1 className="display" style={{ fontSize: 52 }}>TEAMS</h1>
      <p className="soft">Squads update automatically from match scorecards once the 2026 season starts.</p>
      <div className="grid g3" style={{ marginTop: 16 }}>
        {ts.map((t) => (
          <Link key={t.id} href={`/teams/${t.id}`} className="card stack" style={{ color: 'inherit', textDecoration: 'none' }}>
            <div className="row"><TeamBadge t={t} /><div className="grow"><div style={{ fontWeight: 800, fontSize: 17 }}>{t.name}</div><div className="xs muted">{t.home}</div></div>{t.id === 'aces' && <span className="pill lime">NEW</span>}</div>
            <div className="small soft">Icon player: {t.icon_player}</div>
            <div className="row xs muted"><span>{t.fans} fans</span><span>·</span><span>{hs.filter((h) => h.team_id === t.id).length} verified channels</span></div>
          </Link>
        ))}
      </div>
    </>
  );
}
