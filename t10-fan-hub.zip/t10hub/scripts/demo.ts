import { seedDemo } from '../lib/demo';

(async () => {
  console.log(await seedDemo());
  process.exit(0);
})();
