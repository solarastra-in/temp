// Run agents from the command line: npm run agents [-- discovery|social|news|scores|content|ops|all]
import { runAll, runNamed, AGENTS, AgentName } from '../lib/agents';

(async () => {
  const name = process.argv[2] || 'all';
  const r = name === 'all' ? await runAll() : name in AGENTS ? await runNamed(name as AgentName) : { error: 'unknown agent' };
  console.log(JSON.stringify(r, null, 2));
  process.exit(0);
})();
