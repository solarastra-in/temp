// Creates tables and the base seed (teams, squads, known handles, season + trivia contests).
import { q } from '../lib/db';

(async () => {
  const r = await q(`SELECT count(*)::int AS teams FROM teams`);
  console.log('Database ready:', r[0]);
  process.exit(0);
})();
